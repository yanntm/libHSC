package body relay is

  task body a is
    x : val;
    done : boolean;
  begin
    x := 0; --event[{x=0}];
    null;
    
    loop
      exit when done;

      select
        when (x = 0) =>
          accept get_0; --eventb[{xis=0}]
          null;

      or

        accept set_0 do
          x := 0; --event[{x=0}]
          null;
        end set_0;

      or

        when (x = 1) =>
          accept get_1; --eventb[{xis=1}]
          null;

      or

        accept set_1 do
          x := 1; --event[{x=1}]
          null;
        end set_1;

      or

        when (x = 2) =>
          accept get_2; --eventb[{xis=2}]
          null;

      or

        accept set_2 do
          x := 2; --event[{x=2}]
          null;
        end set_2;

      or

        when (x = 3) =>
          accept get_3; --eventb[{xis=3}]
          null;

      or

        accept set_3 do
          x := 3; --event[{x=3}]
          null;
        end set_3;
      end select;
    end loop;
  end a;


  task body t0 is
    y0 : val;
    done : boolean;
    random : integer;
  begin
    loop
      exit when done;

      case random is
        when 0 =>
          a.get_0;
          y0 := 0; --event[{y0=0}]
          null;

        when 1 =>
          a.get_1;
          y0 := 1; --event[{y0=1}]
          null;

        when 2 =>
          a.get_2;
          y0 := 2; --event[{y0=2}]
          null;

        when 3 =>
          a.get_3;
          y0 := 3; --event[{y0=3}]
          null;

      end case;

      if (y0 = 0) then
        null; --eventb[{y0is=0}]
        null; --eventb[{y0=unknown}]
        null;
        a.set_1;
      else
        null; --eventb[{y0is/=0}]
        null; --eventb[{y0=unknown}]
        null;
      end if;
    end loop;
  end t0;


  task body t1 is
    y1 : val;
    done : boolean;
    random : integer;
  begin
    loop
      exit when done;

      case random is
        when 0 =>
          a.get_0;
          y1 := 0; --event[{y1=0}]
          null;

        when 1 =>
          a.get_1;
          y1 := 1; --event[{y1=1}]
          null;

        when 2 =>
          a.get_2;
          y1 := 2; --event[{y1=2}]
          null;

        when 3 =>
          a.get_3;
          y1 := 3; --event[{y1=3}]
          null;

      end case;

      if (y1 = 1) then
        null; --eventb[{y1is=1}]
        null; --eventb[{y1=unknown}]
        null;
        a.set_2;
      else
        null; --eventb[{y1is/=1}]
        null; --eventb[{y1=unknown}]
        null;
      end if;
    end loop;
  end t1;


  task body t2 is
    y2 : val;
    done : boolean;
    random : integer;
  begin
    loop
      exit when done;

      case random is
        when 0 =>
          a.get_0;
          y2 := 0; --event[{y2=0}]
          null;

        when 1 =>
          a.get_1;
          y2 := 1; --event[{y2=1}]
          null;

        when 2 =>
          a.get_2;
          y2 := 2; --event[{y2=2}]
          null;

        when 3 =>
          a.get_3;
          y2 := 3; --event[{y2=3}]
          null;

      end case;

      if (y2 = 2) then
        null; --eventb[{y2is=2}]
        null; --eventb[{y2=unknown}]
        null;
        a.set_3;
      else
        null; --eventb[{y2is/=2}]
        null; --eventb[{y2=unknown}]
        null;
      end if;
    end loop;
  end t2;


  task body t3 is
    y3 : val;
    done : boolean;
    random : integer;
  begin
    loop
      exit when done;

      case random is
        when 0 =>
          a.get_0;
          y3 := 0; --event[{y3=0}]
          null;

        when 1 =>
          a.get_1;
          y3 := 1; --event[{y3=1}]
          null;

        when 2 =>
          a.get_2;
          y3 := 2; --event[{y3=2}]
          null;

        when 3 =>
          a.get_3;
          y3 := 3; --event[{y3=3}]
          null;

      end case;

      if (y3 = 3) then
        null; --eventb[{y3is=3}]
        null; --eventb[{y3=unknown}]
        null;
        a.set_0;
      else
        null; --eventb[{y3is/=3}]
        null; --eventb[{y3=unknown}]
        null;
      end if;
    end loop;
  end t3;


end relay;

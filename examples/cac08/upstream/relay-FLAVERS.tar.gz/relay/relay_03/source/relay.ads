package relay is
  subtype val is natural range 0..2;

  task a is
    entry set_0;
    entry get_0;
    entry set_1;
    entry get_1;
    entry set_2;
    entry get_2;
  end a;

  task t0;
  task t1;
  task t2;
end relay;

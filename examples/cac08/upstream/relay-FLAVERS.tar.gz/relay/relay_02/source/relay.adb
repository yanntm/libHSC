package body relay is

  task body a is
    x : val;
    done : boolean;
  begin
    x := 0; --event[{x=0}];
    null;
    
    loop
      exit when done;

      select
        when (x = 0) =>
          accept get_0; --eventb[{xis=0}]
          null;

      or

        accept set_0 do
          x := 0; --event[{x=0}]
          null;
        end set_0;

      or

        when (x = 1) =>
          accept get_1; --eventb[{xis=1}]
          null;

      or

        accept set_1 do
          x := 1; --event[{x=1}]
          null;
        end set_1;
      end select;
    end loop;
  end a;


  task body t0 is
    y0 : val;
    done : boolean;
    random : integer;
  begin
    loop
      exit when done;

      case random is
        when 0 =>
          a.get_0;
          y0 := 0; --event[{y0=0}]
          null;

        when 1 =>
          a.get_1;
          y0 := 1; --event[{y0=1}]
          null;

      end case;

      if (y0 = 0) then
        null; --eventb[{y0is=0}]
        null; --eventb[{y0=unknown}]
        null;
        a.set_1;
      else
        null; --eventb[{y0is/=0}]
        null; --eventb[{y0=unknown}]
        null;
      end if;
    end loop;
  end t0;


  task body t1 is
    y1 : val;
    done : boolean;
    random : integer;
  begin
    loop
      exit when done;

      case random is
        when 0 =>
          a.get_0;
          y1 := 0; --event[{y1=0}]
          null;

        when 1 =>
          a.get_1;
          y1 := 1; --event[{y1=1}]
          null;

      end case;

      if (y1 = 1) then
        null; --eventb[{y1is=1}]
        null; --eventb[{y1=unknown}]
        null;
        a.set_0;
      else
        null; --eventb[{y1is/=1}]
        null; --eventb[{y1=unknown}]
        null;
      end if;
    end loop;
  end t1;


end relay;

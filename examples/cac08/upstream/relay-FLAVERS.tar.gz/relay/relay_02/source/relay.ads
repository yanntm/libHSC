package relay is
  subtype val is natural range 0..1;

  task a is
    entry set_0;
    entry get_0;
    entry set_1;
    entry get_1;
  end a;

  task t0;
  task t1;
end relay;

package relay is
  subtype val is natural range 0..6;

  task a is
    entry set_0;
    entry get_0;
    entry set_1;
    entry get_1;
    entry set_2;
    entry get_2;
    entry set_3;
    entry get_3;
    entry set_4;
    entry get_4;
    entry set_5;
    entry get_5;
    entry set_6;
    entry get_6;
  end a;

  task t0;
  task t1;
  task t2;
  task t3;
  task t4;
  task t5;
  task t6;
end relay;

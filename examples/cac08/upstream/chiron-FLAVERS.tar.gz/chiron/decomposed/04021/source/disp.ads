-- Generated on Mon Oct 18 13:59:07 2004
-- Artists:        4
-- Events:         2
-- Configuration:  11 10 11 10

-- The following code is based on Chiron from UCI which is
-- Copyright (c) 1996-98 The Regents of the University of California All
-- Rights Reserved. Permission to use, copy, modify, and distribute this
-- software and its documentation for educational, research any non-profit
-- purposes, without fee, and without a written agreement is hereby
-- granted, provided that the above copyright notice and this paragraph
-- appear in all copies. Permission to incorporate this software into
-- commercial products must be negotiated with University of
-- California. This software program and documentation are copyrighted by
-- The Regents of the University of California. The software program and
-- documentation are supplied "as is", without any accompanying services
-- from The Regents. The Regents do not warrant that the operation of the
-- program will be uninterrupted or error-free. The end-user understands
-- that the program was developed for research purposes and is advised not
-- to rely exclusively on the program for any reason. IN NO EVENT SHALL THE
-- UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
-- SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
-- ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
-- THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
-- DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
-- WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
-- MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
-- PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
-- CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
-- ENHANCEMENTS, OR MODIFICATIONS.

package disp is
  number_of_artists: constant natural := 4;
  number_of_events: constant natural := 2;

  type artist_id_type is (a1, a2, a3, a4);
  type event_kind is (e1, e2
);
  subtype list_size is natural range 0..4;

  subtype array_size is natural range 1..4;

  task dispatcher is
    entry register_event_a1_e1;
    entry unregister_event_a1_e1;
    entry register_event_a2_e1;
    entry unregister_event_a2_e1;
    entry register_event_a3_e1;
    entry unregister_event_a3_e1;
    entry register_event_a4_e1;
    entry unregister_event_a4_e1;
    entry notify_artists_e1;

    entry register_event_a1_e2;
    entry unregister_event_a1_e2;
    entry register_event_a2_e2;
    entry unregister_event_a2_e2;
    entry register_event_a3_e2;
    entry unregister_event_a3_e2;
    entry register_event_a4_e2;
    entry unregister_event_a4_e2;
    entry notify_artists_e2;

  end dispatcher;

  task dispatcher_e1 is
    entry register_event_a1;
    entry unregister_event_a1;
    entry register_event_a2;
    entry unregister_event_a2;
    entry register_event_a3;
    entry unregister_event_a3;
    entry register_event_a4;
    entry unregister_event_a4;
    entry notify_artists;
  end dispatcher_e1;
  task dispatcher_e2 is
    entry register_event_a1;
    entry unregister_event_a1;
    entry register_event_a2;
    entry unregister_event_a2;
    entry register_event_a3;
    entry unregister_event_a3;
    entry register_event_a4;
    entry unregister_event_a4;
    entry notify_artists;
  end dispatcher_e2;

  task artist1 is
    entry start_artist;
    entry terminate_artist;

    entry notify_client_event_e1;
    entry notify_client_event_e2;
  end artist1;

  task artist2 is
    entry start_artist;
    entry terminate_artist;

    entry notify_client_event_e1;
    entry notify_client_event_e2;
  end artist2;

  task artist3 is
    entry start_artist;
    entry terminate_artist;

    entry notify_client_event_e1;
    entry notify_client_event_e2;
  end artist3;

  task artist4 is
    entry start_artist;
    entry terminate_artist;

    entry notify_client_event_e1;
    entry notify_client_event_e2;
  end artist4;

  task adt_wrapper is
    entry start_wrapper;
  end adt_wrapper;

  task artist_manager is
    entry start_manager;
    entry a1_registered;
    entry a2_registered;
    entry a3_registered;
    entry a4_registered;
  end artist_manager;

  task client_init;

end disp;


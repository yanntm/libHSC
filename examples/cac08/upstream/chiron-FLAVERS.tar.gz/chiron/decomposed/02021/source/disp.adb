-- Generated on Mon Oct 18 13:58:46 2004
-- Artists:        2
-- Events:         2
-- Configuration:  11 10

-- The following code is based on Chiron from UCI which is
-- Copyright (c) 1996-98 The Regents of the University of California All
-- Rights Reserved. Permission to use, copy, modify, and distribute this
-- software and its documentation for educational, research any non-profit
-- purposes, without fee, and without a written agreement is hereby
-- granted, provided that the above copyright notice and this paragraph
-- appear in all copies. Permission to incorporate this software into
-- commercial products must be negotiated with University of
-- California. This software program and documentation are copyrighted by
-- The Regents of the University of California. The software program and
-- documentation are supplied "as is", without any accompanying services
-- from The Regents. The Regents do not warrant that the operation of the
-- program will be uninterrupted or error-free. The end-user understands
-- that the program was developed for research purposes and is advised not
-- to rely exclusively on the program for any reason. IN NO EVENT SHALL THE
-- UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
-- SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
-- ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
-- THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
-- DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
-- WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
-- MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
-- PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
-- CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
-- ENHANCEMENTS, OR MODIFICATIONS.

package body disp is

task body dispatcher is
  begin
    loop
      select
          accept register_event_a1_e1 do
            dispatcher_e1.register_event_a1;
          end register_event_a1_e1;

      or

          accept unregister_event_a1_e1 do
            dispatcher_e1.unregister_event_a1;
          end unregister_event_a1_e1;

      or

          accept register_event_a2_e1 do
            dispatcher_e1.register_event_a2;
          end register_event_a2_e1;

      or

          accept unregister_event_a2_e1 do
            dispatcher_e1.unregister_event_a2;
          end unregister_event_a2_e1;

      or

          accept notify_artists_e1 do
            dispatcher_e1.notify_artists;
          end notify_artists_e1;

      or

          accept register_event_a1_e2 do
            dispatcher_e2.register_event_a1;
          end register_event_a1_e2;

      or

          accept unregister_event_a1_e2 do
            dispatcher_e2.unregister_event_a1;
          end unregister_event_a1_e2;

      or

          accept register_event_a2_e2 do
            dispatcher_e2.register_event_a2;
          end register_event_a2_e2;

      or

          accept unregister_event_a2_e2 do
            dispatcher_e2.unregister_event_a2;
          end unregister_event_a2_e2;

      or

          accept notify_artists_e2 do
            dispatcher_e2.notify_artists;
          end notify_artists_e2;

      or

        terminate;
      end select;
    end loop;
  end dispatcher;


  task body dispatcher_e1 is
    e1_list: array(array_size) of artist_id_type;
    e1_size : list_size := 0;
  begin
    -- Initialize the list size
    null;  --event[{e1_size=0}]
    null;

    loop
      select
        accept register_event_a1 do
          case e1_size is
            when 0 =>
              null; --event[{e1_sizeis=0}]
              e1_size := e1_size + 1; --event[{e1_sizeinc}]
              e1_list(1) := a1; --event[{e1_list_1=a1}]
              null;
            when 1 =>
              null; --event[{e1_sizeis=1}]
              if e1_list(1) = a1 then
                null;  --event[{e1_list_1is=a1}]
                -- the artist is already registered for this event
                null;
              else
                null;  --event[{e1_list_1is/=a1}]
                -- the artist not registered for this event
                e1_size := e1_size + 1; --event[{e1_sizeinc}]
                e1_list(2) := a1; --event[{e1_list_2=a1}]
                null;
              end if;
            when 2 =>
              null; --event[{e1_sizeis=2}]
              if e1_list(1) = a1 then
                null;  --event[{e1_list_1is=a1}]
                -- the artist is already registered for this event
                null;
              else
                null;  --event[{e1_list_1is/=a1}]
                if e1_list(2) = a1 then
                  null;  --event[{e1_list_2is=a1}]
                  -- the artist is already registered for this event
                  null;
                else
                  null;  --event[{e1_list_2is/=a1}]
                  -- the artist not registered for this event
                  -- but all positions of the array are taken
                  null; --event[{e1_list_out_of_bounds}]
                  null;
                end if;
              end if;
          end case;
        end register_event_a1;

      or

        accept unregister_event_a1 do
          case e1_size is
            when 0 =>
              null; --event[{e1_sizeis=0}]
              null;
            when 1 =>
              null; --event[{e1_sizeis=1}]
              if e1_list(1) = a1 then
                null;  --event[{e1_list_1is=a1}]
                -- the artist is registered for this event
                -- we need to shift all events after this
                -- one down

                -- The element of the event list in position 1
                -- is no longer needed.  Reset it to unknown.
                null; --event[{e1_list_1=unknown}]

                e1_size := e1_size - 1; --event[{e1_sizedec}]
                null;
              else
                null;  --event[{e1_list_1is/=a1}]
                null;
              end if;
            when 2 =>
              null; --event[{e1_sizeis=2}]
              if e1_list(1) = a1 then
                null;  --event[{e1_list_1is=a1}]
                -- the artist is registered for this event
                -- we need to shift all events after this
                -- one down

                e1_list(1) := e1_list(2);
                -- This case statement does in FLAVERS
                -- what the previous assignment does
                case e1_list(2) is 
                  when a1 =>
                    null; --event[{e1_list_2is=a1}]
                    null; --event[{e1_list_1=a1}]
                    null;
                  when a2 =>
                    null; --event[{e1_list_2is=a2}]
                    null; --event[{e1_list_1=a2}]
                    null;
                end case;

                -- The element of the event list in position 2
                -- is no longer needed.  Reset it to unknown.
                null; --event[{e1_list_2=unknown}]

                e1_size := e1_size - 1; --event[{e1_sizedec}]
                null;
              else
                null;  --event[{e1_list_1is/=a1}]
                null;
                if e1_list(2) = a1 then
                  null;  --event[{e1_list_2is=a1}]
                  -- the artist is registered for this event
                  -- we need to shift all events after this
                  -- one down

                  -- The element of the event list in position 2
                  -- is no longer needed.  Reset it to unknown.
                  null; --event[{e1_list_2=unknown}]

                  e1_size := e1_size - 1; --event[{e1_sizedec}]
                  null;
                else
                  null;  --event[{e1_list_2is/=a1}]
                  null;
                end if;
              end if;
          end case;
        end unregister_event_a1;

      or

        accept register_event_a2 do
          case e1_size is
            when 0 =>
              null; --event[{e1_sizeis=0}]
              e1_size := e1_size + 1; --event[{e1_sizeinc}]
              e1_list(1) := a2; --event[{e1_list_1=a2}]
              null;
            when 1 =>
              null; --event[{e1_sizeis=1}]
              if e1_list(1) = a2 then
                null;  --event[{e1_list_1is=a2}]
                -- the artist is already registered for this event
                null;
              else
                null;  --event[{e1_list_1is/=a2}]
                -- the artist not registered for this event
                e1_size := e1_size + 1; --event[{e1_sizeinc}]
                e1_list(2) := a2; --event[{e1_list_2=a2}]
                null;
              end if;
            when 2 =>
              null; --event[{e1_sizeis=2}]
              if e1_list(1) = a2 then
                null;  --event[{e1_list_1is=a2}]
                -- the artist is already registered for this event
                null;
              else
                null;  --event[{e1_list_1is/=a2}]
                if e1_list(2) = a2 then
                  null;  --event[{e1_list_2is=a2}]
                  -- the artist is already registered for this event
                  null;
                else
                  null;  --event[{e1_list_2is/=a2}]
                  -- the artist not registered for this event
                  -- but all positions of the array are taken
                  null; --event[{e1_list_out_of_bounds}]
                  null;
                end if;
              end if;
          end case;
        end register_event_a2;

      or

        accept unregister_event_a2 do
          case e1_size is
            when 0 =>
              null; --event[{e1_sizeis=0}]
              null;
            when 1 =>
              null; --event[{e1_sizeis=1}]
              if e1_list(1) = a2 then
                null;  --event[{e1_list_1is=a2}]
                -- the artist is registered for this event
                -- we need to shift all events after this
                -- one down

                -- The element of the event list in position 1
                -- is no longer needed.  Reset it to unknown.
                null; --event[{e1_list_1=unknown}]

                e1_size := e1_size - 1; --event[{e1_sizedec}]
                null;
              else
                null;  --event[{e1_list_1is/=a2}]
                null;
              end if;
            when 2 =>
              null; --event[{e1_sizeis=2}]
              if e1_list(1) = a2 then
                null;  --event[{e1_list_1is=a2}]
                -- the artist is registered for this event
                -- we need to shift all events after this
                -- one down

                e1_list(1) := e1_list(2);
                -- This case statement does in FLAVERS
                -- what the previous assignment does
                case e1_list(2) is 
                  when a1 =>
                    null; --event[{e1_list_2is=a1}]
                    null; --event[{e1_list_1=a1}]
                    null;
                  when a2 =>
                    null; --event[{e1_list_2is=a2}]
                    null; --event[{e1_list_1=a2}]
                    null;
                end case;

                -- The element of the event list in position 2
                -- is no longer needed.  Reset it to unknown.
                null; --event[{e1_list_2=unknown}]

                e1_size := e1_size - 1; --event[{e1_sizedec}]
                null;
              else
                null;  --event[{e1_list_1is/=a2}]
                null;
                if e1_list(2) = a2 then
                  null;  --event[{e1_list_2is=a2}]
                  -- the artist is registered for this event
                  -- we need to shift all events after this
                  -- one down

                  -- The element of the event list in position 2
                  -- is no longer needed.  Reset it to unknown.
                  null; --event[{e1_list_2=unknown}]

                  e1_size := e1_size - 1; --event[{e1_sizedec}]
                  null;
                else
                  null;  --event[{e1_list_2is/=a2}]
                  null;
                end if;
              end if;
          end case;
        end unregister_event_a2;

      or

        accept notify_artists do
          case e1_size is
            when 0 =>
              null; --event[{e1_sizeis=0}]
              null;
              null;
            when 1 =>
              null; --event[{e1_sizeis=1}]
              null;
              case e1_list(1) is
                when a1 =>
                  null; --event[{e1_list_1is=a1}]
                  artist1.notify_client_event_e1;
                when a2 =>
                  null; --event[{e1_list_1is=a2}]
                  artist2.notify_client_event_e1;
              end case;

            when 2 =>
              null; --event[{e1_sizeis=2}]
              null;
              case e1_list(1) is
                when a1 =>
                  null; --event[{e1_list_1is=a1}]
                  artist1.notify_client_event_e1;
                when a2 =>
                  null; --event[{e1_list_1is=a2}]
                  artist2.notify_client_event_e1;
              end case;

              case e1_list(2) is
                when a1 =>
                  null; --event[{e1_list_2is=a1}]
                  artist1.notify_client_event_e1;
                when a2 =>
                  null; --event[{e1_list_2is=a2}]
                  artist2.notify_client_event_e1;
              end case;

          end case;
        end notify_artists;

      or

        terminate;
      end select;
    end loop;
  end dispatcher_e1;


  task body dispatcher_e2 is
    e2_list: array(array_size) of artist_id_type;
    e2_size : list_size := 0;
  begin
    -- Initialize the list size
    null;  --event[{e2_size=0}]
    null;

    loop
      select
        accept register_event_a1 do
          case e2_size is
            when 0 =>
              null; --event[{e2_sizeis=0}]
              e2_size := e2_size + 1; --event[{e2_sizeinc}]
              e2_list(1) := a1; --event[{e2_list_1=a1}]
              null;
            when 1 =>
              null; --event[{e2_sizeis=1}]
              if e2_list(1) = a1 then
                null;  --event[{e2_list_1is=a1}]
                -- the artist is already registered for this event
                null;
              else
                null;  --event[{e2_list_1is/=a1}]
                -- the artist not registered for this event
                e2_size := e2_size + 1; --event[{e2_sizeinc}]
                e2_list(2) := a1; --event[{e2_list_2=a1}]
                null;
              end if;
            when 2 =>
              null; --event[{e2_sizeis=2}]
              if e2_list(1) = a1 then
                null;  --event[{e2_list_1is=a1}]
                -- the artist is already registered for this event
                null;
              else
                null;  --event[{e2_list_1is/=a1}]
                if e2_list(2) = a1 then
                  null;  --event[{e2_list_2is=a1}]
                  -- the artist is already registered for this event
                  null;
                else
                  null;  --event[{e2_list_2is/=a1}]
                  -- the artist not registered for this event
                  -- but all positions of the array are taken
                  null; --event[{e2_list_out_of_bounds}]
                  null;
                end if;
              end if;
          end case;
        end register_event_a1;

      or

        accept unregister_event_a1 do
          case e2_size is
            when 0 =>
              null; --event[{e2_sizeis=0}]
              null;
            when 1 =>
              null; --event[{e2_sizeis=1}]
              if e2_list(1) = a1 then
                null;  --event[{e2_list_1is=a1}]
                -- the artist is registered for this event
                -- we need to shift all events after this
                -- one down

                -- The element of the event list in position 1
                -- is no longer needed.  Reset it to unknown.
                null; --event[{e2_list_1=unknown}]

                e2_size := e2_size - 1; --event[{e2_sizedec}]
                null;
              else
                null;  --event[{e2_list_1is/=a1}]
                null;
              end if;
            when 2 =>
              null; --event[{e2_sizeis=2}]
              if e2_list(1) = a1 then
                null;  --event[{e2_list_1is=a1}]
                -- the artist is registered for this event
                -- we need to shift all events after this
                -- one down

                e2_list(1) := e2_list(2);
                -- This case statement does in FLAVERS
                -- what the previous assignment does
                case e2_list(2) is 
                  when a1 =>
                    null; --event[{e2_list_2is=a1}]
                    null; --event[{e2_list_1=a1}]
                    null;
                  when a2 =>
                    null; --event[{e2_list_2is=a2}]
                    null; --event[{e2_list_1=a2}]
                    null;
                end case;

                -- The element of the event list in position 2
                -- is no longer needed.  Reset it to unknown.
                null; --event[{e2_list_2=unknown}]

                e2_size := e2_size - 1; --event[{e2_sizedec}]
                null;
              else
                null;  --event[{e2_list_1is/=a1}]
                null;
                if e2_list(2) = a1 then
                  null;  --event[{e2_list_2is=a1}]
                  -- the artist is registered for this event
                  -- we need to shift all events after this
                  -- one down

                  -- The element of the event list in position 2
                  -- is no longer needed.  Reset it to unknown.
                  null; --event[{e2_list_2=unknown}]

                  e2_size := e2_size - 1; --event[{e2_sizedec}]
                  null;
                else
                  null;  --event[{e2_list_2is/=a1}]
                  null;
                end if;
              end if;
          end case;
        end unregister_event_a1;

      or

        accept register_event_a2 do
          case e2_size is
            when 0 =>
              null; --event[{e2_sizeis=0}]
              e2_size := e2_size + 1; --event[{e2_sizeinc}]
              e2_list(1) := a2; --event[{e2_list_1=a2}]
              null;
            when 1 =>
              null; --event[{e2_sizeis=1}]
              if e2_list(1) = a2 then
                null;  --event[{e2_list_1is=a2}]
                -- the artist is already registered for this event
                null;
              else
                null;  --event[{e2_list_1is/=a2}]
                -- the artist not registered for this event
                e2_size := e2_size + 1; --event[{e2_sizeinc}]
                e2_list(2) := a2; --event[{e2_list_2=a2}]
                null;
              end if;
            when 2 =>
              null; --event[{e2_sizeis=2}]
              if e2_list(1) = a2 then
                null;  --event[{e2_list_1is=a2}]
                -- the artist is already registered for this event
                null;
              else
                null;  --event[{e2_list_1is/=a2}]
                if e2_list(2) = a2 then
                  null;  --event[{e2_list_2is=a2}]
                  -- the artist is already registered for this event
                  null;
                else
                  null;  --event[{e2_list_2is/=a2}]
                  -- the artist not registered for this event
                  -- but all positions of the array are taken
                  null; --event[{e2_list_out_of_bounds}]
                  null;
                end if;
              end if;
          end case;
        end register_event_a2;

      or

        accept unregister_event_a2 do
          case e2_size is
            when 0 =>
              null; --event[{e2_sizeis=0}]
              null;
            when 1 =>
              null; --event[{e2_sizeis=1}]
              if e2_list(1) = a2 then
                null;  --event[{e2_list_1is=a2}]
                -- the artist is registered for this event
                -- we need to shift all events after this
                -- one down

                -- The element of the event list in position 1
                -- is no longer needed.  Reset it to unknown.
                null; --event[{e2_list_1=unknown}]

                e2_size := e2_size - 1; --event[{e2_sizedec}]
                null;
              else
                null;  --event[{e2_list_1is/=a2}]
                null;
              end if;
            when 2 =>
              null; --event[{e2_sizeis=2}]
              if e2_list(1) = a2 then
                null;  --event[{e2_list_1is=a2}]
                -- the artist is registered for this event
                -- we need to shift all events after this
                -- one down

                e2_list(1) := e2_list(2);
                -- This case statement does in FLAVERS
                -- what the previous assignment does
                case e2_list(2) is 
                  when a1 =>
                    null; --event[{e2_list_2is=a1}]
                    null; --event[{e2_list_1=a1}]
                    null;
                  when a2 =>
                    null; --event[{e2_list_2is=a2}]
                    null; --event[{e2_list_1=a2}]
                    null;
                end case;

                -- The element of the event list in position 2
                -- is no longer needed.  Reset it to unknown.
                null; --event[{e2_list_2=unknown}]

                e2_size := e2_size - 1; --event[{e2_sizedec}]
                null;
              else
                null;  --event[{e2_list_1is/=a2}]
                null;
                if e2_list(2) = a2 then
                  null;  --event[{e2_list_2is=a2}]
                  -- the artist is registered for this event
                  -- we need to shift all events after this
                  -- one down

                  -- The element of the event list in position 2
                  -- is no longer needed.  Reset it to unknown.
                  null; --event[{e2_list_2=unknown}]

                  e2_size := e2_size - 1; --event[{e2_sizedec}]
                  null;
                else
                  null;  --event[{e2_list_2is/=a2}]
                  null;
                end if;
              end if;
          end case;
        end unregister_event_a2;

      or

        accept notify_artists do
          case e2_size is
            when 0 =>
              null; --event[{e2_sizeis=0}]
              null;
              null;
            when 1 =>
              null; --event[{e2_sizeis=1}]
              null;
              case e2_list(1) is
                when a1 =>
                  null; --event[{e2_list_1is=a1}]
                  artist1.notify_client_event_e2;
                when a2 =>
                  null; --event[{e2_list_1is=a2}]
                  artist2.notify_client_event_e2;
              end case;

            when 2 =>
              null; --event[{e2_sizeis=2}]
              null;
              case e2_list(1) is
                when a1 =>
                  null; --event[{e2_list_1is=a1}]
                  artist1.notify_client_event_e2;
                when a2 =>
                  null; --event[{e2_list_1is=a2}]
                  artist2.notify_client_event_e2;
              end case;

              case e2_list(2) is
                when a1 =>
                  null; --event[{e2_list_2is=a1}]
                  artist1.notify_client_event_e2;
                when a2 =>
                  null; --event[{e2_list_2is=a2}]
                  artist2.notify_client_event_e2;
              end case;

          end case;
        end notify_artists;

      or

        terminate;
      end select;
    end loop;
  end dispatcher_e2;





  task body artist1 is
    notify_event: event_kind;
  begin
    accept start_artist;
    dispatcher.register_event_a1_e1; --event[{registered}]
    dispatcher.register_event_a1_e2; --event[{registered}]
    null;
    artist_manager.a1_registered;

    loop
      select
        accept notify_client_event_e1 do
          notify_event := e1;
        end notify_client_event_e1;
      or
        accept notify_client_event_e2 do
          notify_event := e2;
        end notify_client_event_e2;
      or
        accept terminate_artist do
          dispatcher.unregister_event_a1_e1; --event[{unregistered}]
          dispatcher.unregister_event_a1_e2; --event[{unregistered}]
          null;
        end terminate_artist;
        exit;
      end select;
    end loop;
  end artist1;



  task body artist2 is
    notify_event: event_kind;
  begin
    accept start_artist;
    dispatcher.register_event_a2_e1; --event[{registered}]
    null;
    artist_manager.a2_registered;

    loop
      select
        accept notify_client_event_e1 do
          notify_event := e1;
        end notify_client_event_e1;
      or
        accept notify_client_event_e2 do
          notify_event := e2;
        end notify_client_event_e2;
      or
        accept terminate_artist do
          dispatcher.unregister_event_a2_e1; --event[{unregistered}]
          null;
        end terminate_artist;
        exit;
      end select;
    end loop;
  end artist2;



  task body adt_wrapper is
    done : boolean;
    random : integer;
  begin
    accept start_wrapper;
    loop
      exit when done;

      case random is
        when 0 => 
          dispatcher.notify_artists_e1;

        when 1 => 
          dispatcher.notify_artists_e2;

      end case;
    end loop;
  end adt_wrapper;



  task body artist_manager is
  begin
    accept start_manager do
      artist1.start_artist;
      artist2.start_artist;
      accept a1_registered;
      accept a2_registered;
    end start_manager;

    artist1.terminate_artist;
    artist2.terminate_artist;
  end artist_manager;



  task body client_init is
  begin
    artist_manager.start_manager;
    adt_wrapper.start_wrapper;
  end client_init;

end disp;

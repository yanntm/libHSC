--
-- This is a generalization of the smokers problem.  There is one 
-- supplier task and n assembler tasks.  To assemble an item, an 
-- assembler needs n pieces; however, each assembler only has access 
-- to one of the n pieces.  There is a table onto which the supplier
-- puts down n-1 pieces.  The assembler with access to the piece
-- not on the table takes the n-1 pieces off the table, assembles
-- the item, and notifies the supplier that an item has been assembled.
--
-- See Abraham Silberschartz and Peter B. Galvin, "Operating System 
-- Concepts", Fourth Edition, Addison-Wesley Publishing Company,
-- page 212, 1994.
--
-- Generated on Fri Aug 19 09:18:11 2005
-- Assemblers:  58

package smokers is

  task supplier is
    entry done_assembling;
  end supplier;


  task table is
    entry table_lock;
    entry table_unlock;

    entry put_piece_1;
    entry take_piece_1;
    entry available_piece_1;
    entry unavailable_piece_1;

    entry put_piece_2;
    entry take_piece_2;
    entry available_piece_2;
    entry unavailable_piece_2;

    entry put_piece_3;
    entry take_piece_3;
    entry available_piece_3;
    entry unavailable_piece_3;

    entry put_piece_4;
    entry take_piece_4;
    entry available_piece_4;
    entry unavailable_piece_4;

    entry put_piece_5;
    entry take_piece_5;
    entry available_piece_5;
    entry unavailable_piece_5;

    entry put_piece_6;
    entry take_piece_6;
    entry available_piece_6;
    entry unavailable_piece_6;

    entry put_piece_7;
    entry take_piece_7;
    entry available_piece_7;
    entry unavailable_piece_7;

    entry put_piece_8;
    entry take_piece_8;
    entry available_piece_8;
    entry unavailable_piece_8;

    entry put_piece_9;
    entry take_piece_9;
    entry available_piece_9;
    entry unavailable_piece_9;

    entry put_piece_10;
    entry take_piece_10;
    entry available_piece_10;
    entry unavailable_piece_10;

    entry put_piece_11;
    entry take_piece_11;
    entry available_piece_11;
    entry unavailable_piece_11;

    entry put_piece_12;
    entry take_piece_12;
    entry available_piece_12;
    entry unavailable_piece_12;

    entry put_piece_13;
    entry take_piece_13;
    entry available_piece_13;
    entry unavailable_piece_13;

    entry put_piece_14;
    entry take_piece_14;
    entry available_piece_14;
    entry unavailable_piece_14;

    entry put_piece_15;
    entry take_piece_15;
    entry available_piece_15;
    entry unavailable_piece_15;

    entry put_piece_16;
    entry take_piece_16;
    entry available_piece_16;
    entry unavailable_piece_16;

    entry put_piece_17;
    entry take_piece_17;
    entry available_piece_17;
    entry unavailable_piece_17;

    entry put_piece_18;
    entry take_piece_18;
    entry available_piece_18;
    entry unavailable_piece_18;

    entry put_piece_19;
    entry take_piece_19;
    entry available_piece_19;
    entry unavailable_piece_19;

    entry put_piece_20;
    entry take_piece_20;
    entry available_piece_20;
    entry unavailable_piece_20;

    entry put_piece_21;
    entry take_piece_21;
    entry available_piece_21;
    entry unavailable_piece_21;

    entry put_piece_22;
    entry take_piece_22;
    entry available_piece_22;
    entry unavailable_piece_22;

    entry put_piece_23;
    entry take_piece_23;
    entry available_piece_23;
    entry unavailable_piece_23;

    entry put_piece_24;
    entry take_piece_24;
    entry available_piece_24;
    entry unavailable_piece_24;

    entry put_piece_25;
    entry take_piece_25;
    entry available_piece_25;
    entry unavailable_piece_25;

    entry put_piece_26;
    entry take_piece_26;
    entry available_piece_26;
    entry unavailable_piece_26;

    entry put_piece_27;
    entry take_piece_27;
    entry available_piece_27;
    entry unavailable_piece_27;

    entry put_piece_28;
    entry take_piece_28;
    entry available_piece_28;
    entry unavailable_piece_28;

    entry put_piece_29;
    entry take_piece_29;
    entry available_piece_29;
    entry unavailable_piece_29;

    entry put_piece_30;
    entry take_piece_30;
    entry available_piece_30;
    entry unavailable_piece_30;

    entry put_piece_31;
    entry take_piece_31;
    entry available_piece_31;
    entry unavailable_piece_31;

    entry put_piece_32;
    entry take_piece_32;
    entry available_piece_32;
    entry unavailable_piece_32;

    entry put_piece_33;
    entry take_piece_33;
    entry available_piece_33;
    entry unavailable_piece_33;

    entry put_piece_34;
    entry take_piece_34;
    entry available_piece_34;
    entry unavailable_piece_34;

    entry put_piece_35;
    entry take_piece_35;
    entry available_piece_35;
    entry unavailable_piece_35;

    entry put_piece_36;
    entry take_piece_36;
    entry available_piece_36;
    entry unavailable_piece_36;

    entry put_piece_37;
    entry take_piece_37;
    entry available_piece_37;
    entry unavailable_piece_37;

    entry put_piece_38;
    entry take_piece_38;
    entry available_piece_38;
    entry unavailable_piece_38;

    entry put_piece_39;
    entry take_piece_39;
    entry available_piece_39;
    entry unavailable_piece_39;

    entry put_piece_40;
    entry take_piece_40;
    entry available_piece_40;
    entry unavailable_piece_40;

    entry put_piece_41;
    entry take_piece_41;
    entry available_piece_41;
    entry unavailable_piece_41;

    entry put_piece_42;
    entry take_piece_42;
    entry available_piece_42;
    entry unavailable_piece_42;

    entry put_piece_43;
    entry take_piece_43;
    entry available_piece_43;
    entry unavailable_piece_43;

    entry put_piece_44;
    entry take_piece_44;
    entry available_piece_44;
    entry unavailable_piece_44;

    entry put_piece_45;
    entry take_piece_45;
    entry available_piece_45;
    entry unavailable_piece_45;

    entry put_piece_46;
    entry take_piece_46;
    entry available_piece_46;
    entry unavailable_piece_46;

    entry put_piece_47;
    entry take_piece_47;
    entry available_piece_47;
    entry unavailable_piece_47;

    entry put_piece_48;
    entry take_piece_48;
    entry available_piece_48;
    entry unavailable_piece_48;

    entry put_piece_49;
    entry take_piece_49;
    entry available_piece_49;
    entry unavailable_piece_49;

    entry put_piece_50;
    entry take_piece_50;
    entry available_piece_50;
    entry unavailable_piece_50;

    entry put_piece_51;
    entry take_piece_51;
    entry available_piece_51;
    entry unavailable_piece_51;

    entry put_piece_52;
    entry take_piece_52;
    entry available_piece_52;
    entry unavailable_piece_52;

    entry put_piece_53;
    entry take_piece_53;
    entry available_piece_53;
    entry unavailable_piece_53;

    entry put_piece_54;
    entry take_piece_54;
    entry available_piece_54;
    entry unavailable_piece_54;

    entry put_piece_55;
    entry take_piece_55;
    entry available_piece_55;
    entry unavailable_piece_55;

    entry put_piece_56;
    entry take_piece_56;
    entry available_piece_56;
    entry unavailable_piece_56;

    entry put_piece_57;
    entry take_piece_57;
    entry available_piece_57;
    entry unavailable_piece_57;

    entry put_piece_58;
    entry take_piece_58;
    entry available_piece_58;
    entry unavailable_piece_58;
  end table;


  task assembler_1;
  task assembler_2;
  task assembler_3;
  task assembler_4;
  task assembler_5;
  task assembler_6;
  task assembler_7;
  task assembler_8;
  task assembler_9;
  task assembler_10;
  task assembler_11;
  task assembler_12;
  task assembler_13;
  task assembler_14;
  task assembler_15;
  task assembler_16;
  task assembler_17;
  task assembler_18;
  task assembler_19;
  task assembler_20;
  task assembler_21;
  task assembler_22;
  task assembler_23;
  task assembler_24;
  task assembler_25;
  task assembler_26;
  task assembler_27;
  task assembler_28;
  task assembler_29;
  task assembler_30;
  task assembler_31;
  task assembler_32;
  task assembler_33;
  task assembler_34;
  task assembler_35;
  task assembler_36;
  task assembler_37;
  task assembler_38;
  task assembler_39;
  task assembler_40;
  task assembler_41;
  task assembler_42;
  task assembler_43;
  task assembler_44;
  task assembler_45;
  task assembler_46;
  task assembler_47;
  task assembler_48;
  task assembler_49;
  task assembler_50;
  task assembler_51;
  task assembler_52;
  task assembler_53;
  task assembler_54;
  task assembler_55;
  task assembler_56;
  task assembler_57;
  task assembler_58;

end smokers;

--
-- This is a generalization of the smokers problem.  There is one 
-- supplier task and n assembler tasks.  To assemble an item, an 
-- assembler needs n pieces; however, each assembler only has access 
-- to one of the n pieces.  There is a table onto which the supplier
-- puts down n-1 pieces.  The assembler with access to the piece
-- not on the table takes the n-1 pieces off the table, assembles
-- the item, and notifies the supplier that an item has been assembled.
--
-- See Abraham Silberschartz and Peter B. Galvin, "Operating System 
-- Concepts", Fourth Edition, Addison-Wesley Publishing Company,
-- page 212, 1994.
--
-- Generated on Tue Jul 25 10:09:40 2006
-- Assemblers:  20

package smokers is

  task supplier is
    entry done_assembling;
  end supplier;


  task table is
    entry table_lock;
    entry table_unlock;

    entry put_piece_1;
    entry take_piece_1;
    entry available_piece_1;
    entry unavailable_piece_1;

    entry put_piece_2;
    entry take_piece_2;
    entry available_piece_2;
    entry unavailable_piece_2;

    entry put_piece_3;
    entry take_piece_3;
    entry available_piece_3;
    entry unavailable_piece_3;

    entry put_piece_4;
    entry take_piece_4;
    entry available_piece_4;
    entry unavailable_piece_4;

    entry put_piece_5;
    entry take_piece_5;
    entry available_piece_5;
    entry unavailable_piece_5;

    entry put_piece_6;
    entry take_piece_6;
    entry available_piece_6;
    entry unavailable_piece_6;

    entry put_piece_7;
    entry take_piece_7;
    entry available_piece_7;
    entry unavailable_piece_7;

    entry put_piece_8;
    entry take_piece_8;
    entry available_piece_8;
    entry unavailable_piece_8;

    entry put_piece_9;
    entry take_piece_9;
    entry available_piece_9;
    entry unavailable_piece_9;

    entry put_piece_10;
    entry take_piece_10;
    entry available_piece_10;
    entry unavailable_piece_10;

    entry put_piece_11;
    entry take_piece_11;
    entry available_piece_11;
    entry unavailable_piece_11;

    entry put_piece_12;
    entry take_piece_12;
    entry available_piece_12;
    entry unavailable_piece_12;

    entry put_piece_13;
    entry take_piece_13;
    entry available_piece_13;
    entry unavailable_piece_13;

    entry put_piece_14;
    entry take_piece_14;
    entry available_piece_14;
    entry unavailable_piece_14;

    entry put_piece_15;
    entry take_piece_15;
    entry available_piece_15;
    entry unavailable_piece_15;

    entry put_piece_16;
    entry take_piece_16;
    entry available_piece_16;
    entry unavailable_piece_16;

    entry put_piece_17;
    entry take_piece_17;
    entry available_piece_17;
    entry unavailable_piece_17;

    entry put_piece_18;
    entry take_piece_18;
    entry available_piece_18;
    entry unavailable_piece_18;

    entry put_piece_19;
    entry take_piece_19;
    entry available_piece_19;
    entry unavailable_piece_19;

    entry put_piece_20;
    entry take_piece_20;
    entry available_piece_20;
    entry unavailable_piece_20;
  end table;


  task assembler_1;
  task assembler_2;
  task assembler_3;
  task assembler_4;
  task assembler_5;
  task assembler_6;
  task assembler_7;
  task assembler_8;
  task assembler_9;
  task assembler_10;
  task assembler_11;
  task assembler_12;
  task assembler_13;
  task assembler_14;
  task assembler_15;
  task assembler_16;
  task assembler_17;
  task assembler_18;
  task assembler_19;
  task assembler_20;

end smokers;

--
-- This is a generalization of the smokers problem.  There is one 
-- supplier task and n assembler tasks.  To assemble an item, an 
-- assembler needs n pieces; however, each assembler only has access 
-- to one of the n pieces.  There is a table onto which the supplier
-- puts down n-1 pieces.  The assembler with access to the piece
-- not on the table takes the n-1 pieces off the table, assembles
-- the item, and notifies the supplier that an item has been assembled.
--
-- See Abraham Silberschartz and Peter B. Galvin, "Operating System 
-- Concepts", Fourth Edition, Addison-Wesley Publishing Company,
-- page 212, 1994.
--
-- Generated on Tue Jul 25 10:09:29 2006
-- Assemblers:  10

package body smokers is

  task body supplier is
    done : boolean;
    switch : integer;
  begin
    loop
      exit when done;
      table.table_lock;
      case switch is
        when 1 =>
          table.put_piece_2;
          table.put_piece_3;
          table.put_piece_4;
          table.put_piece_5;
          table.put_piece_6;
          table.put_piece_7;
          table.put_piece_8;
          table.put_piece_9;
          table.put_piece_10;
        when 2 =>
          table.put_piece_1;
          table.put_piece_3;
          table.put_piece_4;
          table.put_piece_5;
          table.put_piece_6;
          table.put_piece_7;
          table.put_piece_8;
          table.put_piece_9;
          table.put_piece_10;
        when 3 =>
          table.put_piece_1;
          table.put_piece_2;
          table.put_piece_4;
          table.put_piece_5;
          table.put_piece_6;
          table.put_piece_7;
          table.put_piece_8;
          table.put_piece_9;
          table.put_piece_10;
        when 4 =>
          table.put_piece_1;
          table.put_piece_2;
          table.put_piece_3;
          table.put_piece_5;
          table.put_piece_6;
          table.put_piece_7;
          table.put_piece_8;
          table.put_piece_9;
          table.put_piece_10;
        when 5 =>
          table.put_piece_1;
          table.put_piece_2;
          table.put_piece_3;
          table.put_piece_4;
          table.put_piece_6;
          table.put_piece_7;
          table.put_piece_8;
          table.put_piece_9;
          table.put_piece_10;
        when 6 =>
          table.put_piece_1;
          table.put_piece_2;
          table.put_piece_3;
          table.put_piece_4;
          table.put_piece_5;
          table.put_piece_7;
          table.put_piece_8;
          table.put_piece_9;
          table.put_piece_10;
        when 7 =>
          table.put_piece_1;
          table.put_piece_2;
          table.put_piece_3;
          table.put_piece_4;
          table.put_piece_5;
          table.put_piece_6;
          table.put_piece_8;
          table.put_piece_9;
          table.put_piece_10;
        when 8 =>
          table.put_piece_1;
          table.put_piece_2;
          table.put_piece_3;
          table.put_piece_4;
          table.put_piece_5;
          table.put_piece_6;
          table.put_piece_7;
          table.put_piece_9;
          table.put_piece_10;
        when 9 =>
          table.put_piece_1;
          table.put_piece_2;
          table.put_piece_3;
          table.put_piece_4;
          table.put_piece_5;
          table.put_piece_6;
          table.put_piece_7;
          table.put_piece_8;
          table.put_piece_10;
        when 10 =>
          table.put_piece_1;
          table.put_piece_2;
          table.put_piece_3;
          table.put_piece_4;
          table.put_piece_5;
          table.put_piece_6;
          table.put_piece_7;
          table.put_piece_8;
          table.put_piece_9;
      end case;

      null; --event[{put_pieces}]
      null;

      table.table_unlock;

      accept done_assembling;
    end loop;
  end supplier;

  task body table is
    piece_1 : boolean;
    piece_2 : boolean;
    piece_3 : boolean;
    piece_4 : boolean;
    piece_5 : boolean;
    piece_6 : boolean;
    piece_7 : boolean;
    piece_8 : boolean;
    piece_9 : boolean;
    piece_10 : boolean;
    done : boolean;
  begin
    -- Initially no pieces are available
    piece_1 := false;  --event[{piece_1=f}]
    piece_2 := false;  --event[{piece_2=f}]
    piece_3 := false;  --event[{piece_3=f}]
    piece_4 := false;  --event[{piece_4=f}]
    piece_5 := false;  --event[{piece_5=f}]
    piece_6 := false;  --event[{piece_6=f}]
    piece_7 := false;  --event[{piece_7=f}]
    piece_8 := false;  --event[{piece_8=f}]
    piece_9 := false;  --event[{piece_9=f}]
    piece_10 := false;  --event[{piece_10=f}]
    null;

    loop
      exit when done;

      accept table_lock;

      loop
        select
          accept put_piece_1 do
            piece_1 := true;  --event[{piece_1=t}, {put_piece}]
            null;
          end put_piece_1;
        or
          when (piece_1) =>
            accept take_piece_1;  --eventb[{piece_1is=t}, {take_piece}]
            piece_1 := false;  --event[{piece_1=f}]
            null;
        or
          when (piece_1) =>
            accept available_piece_1; --eventb[{piece_1is=t}]
            null;
        or
          when (not piece_1) =>
            accept unavailable_piece_1; --eventb[{piece_1is=f}]
            null;
        or
          accept put_piece_2 do
            piece_2 := true;  --event[{piece_2=t}, {put_piece}]
            null;
          end put_piece_2;
        or
          when (piece_2) =>
            accept take_piece_2;  --eventb[{piece_2is=t}, {take_piece}]
            piece_2 := false;  --event[{piece_2=f}]
            null;
        or
          when (piece_2) =>
            accept available_piece_2; --eventb[{piece_2is=t}]
            null;
        or
          when (not piece_2) =>
            accept unavailable_piece_2; --eventb[{piece_2is=f}]
            null;
        or
          accept put_piece_3 do
            piece_3 := true;  --event[{piece_3=t}, {put_piece}]
            null;
          end put_piece_3;
        or
          when (piece_3) =>
            accept take_piece_3;  --eventb[{piece_3is=t}, {take_piece}]
            piece_3 := false;  --event[{piece_3=f}]
            null;
        or
          when (piece_3) =>
            accept available_piece_3; --eventb[{piece_3is=t}]
            null;
        or
          when (not piece_3) =>
            accept unavailable_piece_3; --eventb[{piece_3is=f}]
            null;
        or
          accept put_piece_4 do
            piece_4 := true;  --event[{piece_4=t}, {put_piece}]
            null;
          end put_piece_4;
        or
          when (piece_4) =>
            accept take_piece_4;  --eventb[{piece_4is=t}, {take_piece}]
            piece_4 := false;  --event[{piece_4=f}]
            null;
        or
          when (piece_4) =>
            accept available_piece_4; --eventb[{piece_4is=t}]
            null;
        or
          when (not piece_4) =>
            accept unavailable_piece_4; --eventb[{piece_4is=f}]
            null;
        or
          accept put_piece_5 do
            piece_5 := true;  --event[{piece_5=t}, {put_piece}]
            null;
          end put_piece_5;
        or
          when (piece_5) =>
            accept take_piece_5;  --eventb[{piece_5is=t}, {take_piece}]
            piece_5 := false;  --event[{piece_5=f}]
            null;
        or
          when (piece_5) =>
            accept available_piece_5; --eventb[{piece_5is=t}]
            null;
        or
          when (not piece_5) =>
            accept unavailable_piece_5; --eventb[{piece_5is=f}]
            null;
        or
          accept put_piece_6 do
            piece_6 := true;  --event[{piece_6=t}, {put_piece}]
            null;
          end put_piece_6;
        or
          when (piece_6) =>
            accept take_piece_6;  --eventb[{piece_6is=t}, {take_piece}]
            piece_6 := false;  --event[{piece_6=f}]
            null;
        or
          when (piece_6) =>
            accept available_piece_6; --eventb[{piece_6is=t}]
            null;
        or
          when (not piece_6) =>
            accept unavailable_piece_6; --eventb[{piece_6is=f}]
            null;
        or
          accept put_piece_7 do
            piece_7 := true;  --event[{piece_7=t}, {put_piece}]
            null;
          end put_piece_7;
        or
          when (piece_7) =>
            accept take_piece_7;  --eventb[{piece_7is=t}, {take_piece}]
            piece_7 := false;  --event[{piece_7=f}]
            null;
        or
          when (piece_7) =>
            accept available_piece_7; --eventb[{piece_7is=t}]
            null;
        or
          when (not piece_7) =>
            accept unavailable_piece_7; --eventb[{piece_7is=f}]
            null;
        or
          accept put_piece_8 do
            piece_8 := true;  --event[{piece_8=t}, {put_piece}]
            null;
          end put_piece_8;
        or
          when (piece_8) =>
            accept take_piece_8;  --eventb[{piece_8is=t}, {take_piece}]
            piece_8 := false;  --event[{piece_8=f}]
            null;
        or
          when (piece_8) =>
            accept available_piece_8; --eventb[{piece_8is=t}]
            null;
        or
          when (not piece_8) =>
            accept unavailable_piece_8; --eventb[{piece_8is=f}]
            null;
        or
          accept put_piece_9 do
            piece_9 := true;  --event[{piece_9=t}, {put_piece}]
            null;
          end put_piece_9;
        or
          when (piece_9) =>
            accept take_piece_9;  --eventb[{piece_9is=t}, {take_piece}]
            piece_9 := false;  --event[{piece_9=f}]
            null;
        or
          when (piece_9) =>
            accept available_piece_9; --eventb[{piece_9is=t}]
            null;
        or
          when (not piece_9) =>
            accept unavailable_piece_9; --eventb[{piece_9is=f}]
            null;
        or
          accept put_piece_10 do
            piece_10 := true;  --event[{piece_10=t}, {put_piece}]
            null;
          end put_piece_10;
        or
          when (piece_10) =>
            accept take_piece_10;  --eventb[{piece_10is=t}, {take_piece}]
            piece_10 := false;  --event[{piece_10=f}]
            null;
        or
          when (piece_10) =>
            accept available_piece_10; --eventb[{piece_10is=t}]
            null;
        or
          when (not piece_10) =>
            accept unavailable_piece_10; --eventb[{piece_10is=f}]
            null;
        or
          accept table_unlock;
            exit;
        end select;
      end loop;
    end loop;
  end table;


  task body assembler_1 is
    done : boolean;
  begin
    loop
      exit when done;

      table.table_lock;

      select
        table.available_piece_2;  --event[{assembler_1_take_piece_2}]

        select
          table.available_piece_3;  --event[{assembler_1_take_piece_3}]

          select
            table.available_piece_4;  --event[{assembler_1_take_piece_4}]

            select
              table.available_piece_5;  --event[{assembler_1_take_piece_5}]

              select
                table.available_piece_6;  --event[{assembler_1_take_piece_6}]

                select
                  table.available_piece_7;  --event[{assembler_1_take_piece_7}]

                  select
                    table.available_piece_8;  --event[{assembler_1_take_piece_8}]

                    select
                      table.available_piece_9;  --event[{assembler_1_take_piece_9}]

                      select
                        table.available_piece_10;  --event[{assembler_1_take_piece_10}]

                        table.take_piece_2;
                        table.take_piece_3;
                        table.take_piece_4;
                        table.take_piece_5;
                        table.take_piece_6;
                        table.take_piece_7;
                        table.take_piece_8;
                        table.take_piece_9;
                        table.take_piece_10;
                        table.table_unlock;

                        null; --event[{start_item_assembling}]
                        null; --event[{start_item_assembling_1}]
                        null; --event[{stop_item_assembling_1}]
                        null; --event[{stop_item_assembling}]
                        null;

                        supplier.done_assembling;
                      else
                        table.unavailable_piece_10;
                        table.table_unlock;
                      end select;
                    else
                      table.unavailable_piece_9;
                      table.table_unlock;
                    end select;
                  else
                    table.unavailable_piece_8;
                    table.table_unlock;
                  end select;
                else
                  table.unavailable_piece_7;
                  table.table_unlock;
                end select;
              else
                table.unavailable_piece_6;
                table.table_unlock;
              end select;
            else
              table.unavailable_piece_5;
              table.table_unlock;
            end select;
          else
            table.unavailable_piece_4;
            table.table_unlock;
          end select;
        else
          table.unavailable_piece_3;
          table.table_unlock;
        end select;
      else
        table.unavailable_piece_2;
        table.table_unlock;
      end select;

    end loop;
  end assembler_1;


  task body assembler_2 is
    done : boolean;
  begin
    loop
      exit when done;

      table.table_lock;

      select
        table.available_piece_1;  --event[{assembler_2_take_piece_1}]

        select
          table.available_piece_3;  --event[{assembler_2_take_piece_3}]

          select
            table.available_piece_4;  --event[{assembler_2_take_piece_4}]

            select
              table.available_piece_5;  --event[{assembler_2_take_piece_5}]

              select
                table.available_piece_6;  --event[{assembler_2_take_piece_6}]

                select
                  table.available_piece_7;  --event[{assembler_2_take_piece_7}]

                  select
                    table.available_piece_8;  --event[{assembler_2_take_piece_8}]

                    select
                      table.available_piece_9;  --event[{assembler_2_take_piece_9}]

                      select
                        table.available_piece_10;  --event[{assembler_2_take_piece_10}]

                        table.take_piece_1;
                        table.take_piece_3;
                        table.take_piece_4;
                        table.take_piece_5;
                        table.take_piece_6;
                        table.take_piece_7;
                        table.take_piece_8;
                        table.take_piece_9;
                        table.take_piece_10;
                        table.table_unlock;

                        null; --event[{start_item_assembling}]
                        null; --event[{start_item_assembling_2}]
                        null; --event[{stop_item_assembling_2}]
                        null; --event[{stop_item_assembling}]
                        null;

                        supplier.done_assembling;
                      else
                        table.unavailable_piece_10;
                        table.table_unlock;
                      end select;
                    else
                      table.unavailable_piece_9;
                      table.table_unlock;
                    end select;
                  else
                    table.unavailable_piece_8;
                    table.table_unlock;
                  end select;
                else
                  table.unavailable_piece_7;
                  table.table_unlock;
                end select;
              else
                table.unavailable_piece_6;
                table.table_unlock;
              end select;
            else
              table.unavailable_piece_5;
              table.table_unlock;
            end select;
          else
            table.unavailable_piece_4;
            table.table_unlock;
          end select;
        else
          table.unavailable_piece_3;
          table.table_unlock;
        end select;
      else
        table.unavailable_piece_1;
        table.table_unlock;
      end select;

    end loop;
  end assembler_2;


  task body assembler_3 is
    done : boolean;
  begin
    loop
      exit when done;

      table.table_lock;

      select
        table.available_piece_1;  --event[{assembler_3_take_piece_1}]

        select
          table.available_piece_2;  --event[{assembler_3_take_piece_2}]

          select
            table.available_piece_4;  --event[{assembler_3_take_piece_4}]

            select
              table.available_piece_5;  --event[{assembler_3_take_piece_5}]

              select
                table.available_piece_6;  --event[{assembler_3_take_piece_6}]

                select
                  table.available_piece_7;  --event[{assembler_3_take_piece_7}]

                  select
                    table.available_piece_8;  --event[{assembler_3_take_piece_8}]

                    select
                      table.available_piece_9;  --event[{assembler_3_take_piece_9}]

                      select
                        table.available_piece_10;  --event[{assembler_3_take_piece_10}]

                        table.take_piece_1;
                        table.take_piece_2;
                        table.take_piece_4;
                        table.take_piece_5;
                        table.take_piece_6;
                        table.take_piece_7;
                        table.take_piece_8;
                        table.take_piece_9;
                        table.take_piece_10;
                        table.table_unlock;

                        null; --event[{start_item_assembling}]
                        null; --event[{start_item_assembling_3}]
                        null; --event[{stop_item_assembling_3}]
                        null; --event[{stop_item_assembling}]
                        null;

                        supplier.done_assembling;
                      else
                        table.unavailable_piece_10;
                        table.table_unlock;
                      end select;
                    else
                      table.unavailable_piece_9;
                      table.table_unlock;
                    end select;
                  else
                    table.unavailable_piece_8;
                    table.table_unlock;
                  end select;
                else
                  table.unavailable_piece_7;
                  table.table_unlock;
                end select;
              else
                table.unavailable_piece_6;
                table.table_unlock;
              end select;
            else
              table.unavailable_piece_5;
              table.table_unlock;
            end select;
          else
            table.unavailable_piece_4;
            table.table_unlock;
          end select;
        else
          table.unavailable_piece_2;
          table.table_unlock;
        end select;
      else
        table.unavailable_piece_1;
        table.table_unlock;
      end select;

    end loop;
  end assembler_3;


  task body assembler_4 is
    done : boolean;
  begin
    loop
      exit when done;

      table.table_lock;

      select
        table.available_piece_1;  --event[{assembler_4_take_piece_1}]

        select
          table.available_piece_2;  --event[{assembler_4_take_piece_2}]

          select
            table.available_piece_3;  --event[{assembler_4_take_piece_3}]

            select
              table.available_piece_5;  --event[{assembler_4_take_piece_5}]

              select
                table.available_piece_6;  --event[{assembler_4_take_piece_6}]

                select
                  table.available_piece_7;  --event[{assembler_4_take_piece_7}]

                  select
                    table.available_piece_8;  --event[{assembler_4_take_piece_8}]

                    select
                      table.available_piece_9;  --event[{assembler_4_take_piece_9}]

                      select
                        table.available_piece_10;  --event[{assembler_4_take_piece_10}]

                        table.take_piece_1;
                        table.take_piece_2;
                        table.take_piece_3;
                        table.take_piece_5;
                        table.take_piece_6;
                        table.take_piece_7;
                        table.take_piece_8;
                        table.take_piece_9;
                        table.take_piece_10;
                        table.table_unlock;

                        null; --event[{start_item_assembling}]
                        null; --event[{start_item_assembling_4}]
                        null; --event[{stop_item_assembling_4}]
                        null; --event[{stop_item_assembling}]
                        null;

                        supplier.done_assembling;
                      else
                        table.unavailable_piece_10;
                        table.table_unlock;
                      end select;
                    else
                      table.unavailable_piece_9;
                      table.table_unlock;
                    end select;
                  else
                    table.unavailable_piece_8;
                    table.table_unlock;
                  end select;
                else
                  table.unavailable_piece_7;
                  table.table_unlock;
                end select;
              else
                table.unavailable_piece_6;
                table.table_unlock;
              end select;
            else
              table.unavailable_piece_5;
              table.table_unlock;
            end select;
          else
            table.unavailable_piece_3;
            table.table_unlock;
          end select;
        else
          table.unavailable_piece_2;
          table.table_unlock;
        end select;
      else
        table.unavailable_piece_1;
        table.table_unlock;
      end select;

    end loop;
  end assembler_4;


  task body assembler_5 is
    done : boolean;
  begin
    loop
      exit when done;

      table.table_lock;

      select
        table.available_piece_1;  --event[{assembler_5_take_piece_1}]

        select
          table.available_piece_2;  --event[{assembler_5_take_piece_2}]

          select
            table.available_piece_3;  --event[{assembler_5_take_piece_3}]

            select
              table.available_piece_4;  --event[{assembler_5_take_piece_4}]

              select
                table.available_piece_6;  --event[{assembler_5_take_piece_6}]

                select
                  table.available_piece_7;  --event[{assembler_5_take_piece_7}]

                  select
                    table.available_piece_8;  --event[{assembler_5_take_piece_8}]

                    select
                      table.available_piece_9;  --event[{assembler_5_take_piece_9}]

                      select
                        table.available_piece_10;  --event[{assembler_5_take_piece_10}]

                        table.take_piece_1;
                        table.take_piece_2;
                        table.take_piece_3;
                        table.take_piece_4;
                        table.take_piece_6;
                        table.take_piece_7;
                        table.take_piece_8;
                        table.take_piece_9;
                        table.take_piece_10;
                        table.table_unlock;

                        null; --event[{start_item_assembling}]
                        null; --event[{start_item_assembling_5}]
                        null; --event[{stop_item_assembling_5}]
                        null; --event[{stop_item_assembling}]
                        null;

                        supplier.done_assembling;
                      else
                        table.unavailable_piece_10;
                        table.table_unlock;
                      end select;
                    else
                      table.unavailable_piece_9;
                      table.table_unlock;
                    end select;
                  else
                    table.unavailable_piece_8;
                    table.table_unlock;
                  end select;
                else
                  table.unavailable_piece_7;
                  table.table_unlock;
                end select;
              else
                table.unavailable_piece_6;
                table.table_unlock;
              end select;
            else
              table.unavailable_piece_4;
              table.table_unlock;
            end select;
          else
            table.unavailable_piece_3;
            table.table_unlock;
          end select;
        else
          table.unavailable_piece_2;
          table.table_unlock;
        end select;
      else
        table.unavailable_piece_1;
        table.table_unlock;
      end select;

    end loop;
  end assembler_5;


  task body assembler_6 is
    done : boolean;
  begin
    loop
      exit when done;

      table.table_lock;

      select
        table.available_piece_1;  --event[{assembler_6_take_piece_1}]

        select
          table.available_piece_2;  --event[{assembler_6_take_piece_2}]

          select
            table.available_piece_3;  --event[{assembler_6_take_piece_3}]

            select
              table.available_piece_4;  --event[{assembler_6_take_piece_4}]

              select
                table.available_piece_5;  --event[{assembler_6_take_piece_5}]

                select
                  table.available_piece_7;  --event[{assembler_6_take_piece_7}]

                  select
                    table.available_piece_8;  --event[{assembler_6_take_piece_8}]

                    select
                      table.available_piece_9;  --event[{assembler_6_take_piece_9}]

                      select
                        table.available_piece_10;  --event[{assembler_6_take_piece_10}]

                        table.take_piece_1;
                        table.take_piece_2;
                        table.take_piece_3;
                        table.take_piece_4;
                        table.take_piece_5;
                        table.take_piece_7;
                        table.take_piece_8;
                        table.take_piece_9;
                        table.take_piece_10;
                        table.table_unlock;

                        null; --event[{start_item_assembling}]
                        null; --event[{start_item_assembling_6}]
                        null; --event[{stop_item_assembling_6}]
                        null; --event[{stop_item_assembling}]
                        null;

                        supplier.done_assembling;
                      else
                        table.unavailable_piece_10;
                        table.table_unlock;
                      end select;
                    else
                      table.unavailable_piece_9;
                      table.table_unlock;
                    end select;
                  else
                    table.unavailable_piece_8;
                    table.table_unlock;
                  end select;
                else
                  table.unavailable_piece_7;
                  table.table_unlock;
                end select;
              else
                table.unavailable_piece_5;
                table.table_unlock;
              end select;
            else
              table.unavailable_piece_4;
              table.table_unlock;
            end select;
          else
            table.unavailable_piece_3;
            table.table_unlock;
          end select;
        else
          table.unavailable_piece_2;
          table.table_unlock;
        end select;
      else
        table.unavailable_piece_1;
        table.table_unlock;
      end select;

    end loop;
  end assembler_6;


  task body assembler_7 is
    done : boolean;
  begin
    loop
      exit when done;

      table.table_lock;

      select
        table.available_piece_1;  --event[{assembler_7_take_piece_1}]

        select
          table.available_piece_2;  --event[{assembler_7_take_piece_2}]

          select
            table.available_piece_3;  --event[{assembler_7_take_piece_3}]

            select
              table.available_piece_4;  --event[{assembler_7_take_piece_4}]

              select
                table.available_piece_5;  --event[{assembler_7_take_piece_5}]

                select
                  table.available_piece_6;  --event[{assembler_7_take_piece_6}]

                  select
                    table.available_piece_8;  --event[{assembler_7_take_piece_8}]

                    select
                      table.available_piece_9;  --event[{assembler_7_take_piece_9}]

                      select
                        table.available_piece_10;  --event[{assembler_7_take_piece_10}]

                        table.take_piece_1;
                        table.take_piece_2;
                        table.take_piece_3;
                        table.take_piece_4;
                        table.take_piece_5;
                        table.take_piece_6;
                        table.take_piece_8;
                        table.take_piece_9;
                        table.take_piece_10;
                        table.table_unlock;

                        null; --event[{start_item_assembling}]
                        null; --event[{start_item_assembling_7}]
                        null; --event[{stop_item_assembling_7}]
                        null; --event[{stop_item_assembling}]
                        null;

                        supplier.done_assembling;
                      else
                        table.unavailable_piece_10;
                        table.table_unlock;
                      end select;
                    else
                      table.unavailable_piece_9;
                      table.table_unlock;
                    end select;
                  else
                    table.unavailable_piece_8;
                    table.table_unlock;
                  end select;
                else
                  table.unavailable_piece_6;
                  table.table_unlock;
                end select;
              else
                table.unavailable_piece_5;
                table.table_unlock;
              end select;
            else
              table.unavailable_piece_4;
              table.table_unlock;
            end select;
          else
            table.unavailable_piece_3;
            table.table_unlock;
          end select;
        else
          table.unavailable_piece_2;
          table.table_unlock;
        end select;
      else
        table.unavailable_piece_1;
        table.table_unlock;
      end select;

    end loop;
  end assembler_7;


  task body assembler_8 is
    done : boolean;
  begin
    loop
      exit when done;

      table.table_lock;

      select
        table.available_piece_1;  --event[{assembler_8_take_piece_1}]

        select
          table.available_piece_2;  --event[{assembler_8_take_piece_2}]

          select
            table.available_piece_3;  --event[{assembler_8_take_piece_3}]

            select
              table.available_piece_4;  --event[{assembler_8_take_piece_4}]

              select
                table.available_piece_5;  --event[{assembler_8_take_piece_5}]

                select
                  table.available_piece_6;  --event[{assembler_8_take_piece_6}]

                  select
                    table.available_piece_7;  --event[{assembler_8_take_piece_7}]

                    select
                      table.available_piece_9;  --event[{assembler_8_take_piece_9}]

                      select
                        table.available_piece_10;  --event[{assembler_8_take_piece_10}]

                        table.take_piece_1;
                        table.take_piece_2;
                        table.take_piece_3;
                        table.take_piece_4;
                        table.take_piece_5;
                        table.take_piece_6;
                        table.take_piece_7;
                        table.take_piece_9;
                        table.take_piece_10;
                        table.table_unlock;

                        null; --event[{start_item_assembling}]
                        null; --event[{start_item_assembling_8}]
                        null; --event[{stop_item_assembling_8}]
                        null; --event[{stop_item_assembling}]
                        null;

                        supplier.done_assembling;
                      else
                        table.unavailable_piece_10;
                        table.table_unlock;
                      end select;
                    else
                      table.unavailable_piece_9;
                      table.table_unlock;
                    end select;
                  else
                    table.unavailable_piece_7;
                    table.table_unlock;
                  end select;
                else
                  table.unavailable_piece_6;
                  table.table_unlock;
                end select;
              else
                table.unavailable_piece_5;
                table.table_unlock;
              end select;
            else
              table.unavailable_piece_4;
              table.table_unlock;
            end select;
          else
            table.unavailable_piece_3;
            table.table_unlock;
          end select;
        else
          table.unavailable_piece_2;
          table.table_unlock;
        end select;
      else
        table.unavailable_piece_1;
        table.table_unlock;
      end select;

    end loop;
  end assembler_8;


  task body assembler_9 is
    done : boolean;
  begin
    loop
      exit when done;

      table.table_lock;

      select
        table.available_piece_1;  --event[{assembler_9_take_piece_1}]

        select
          table.available_piece_2;  --event[{assembler_9_take_piece_2}]

          select
            table.available_piece_3;  --event[{assembler_9_take_piece_3}]

            select
              table.available_piece_4;  --event[{assembler_9_take_piece_4}]

              select
                table.available_piece_5;  --event[{assembler_9_take_piece_5}]

                select
                  table.available_piece_6;  --event[{assembler_9_take_piece_6}]

                  select
                    table.available_piece_7;  --event[{assembler_9_take_piece_7}]

                    select
                      table.available_piece_8;  --event[{assembler_9_take_piece_8}]

                      select
                        table.available_piece_10;  --event[{assembler_9_take_piece_10}]

                        table.take_piece_1;
                        table.take_piece_2;
                        table.take_piece_3;
                        table.take_piece_4;
                        table.take_piece_5;
                        table.take_piece_6;
                        table.take_piece_7;
                        table.take_piece_8;
                        table.take_piece_10;
                        table.table_unlock;

                        null; --event[{start_item_assembling}]
                        null; --event[{start_item_assembling_9}]
                        null; --event[{stop_item_assembling_9}]
                        null; --event[{stop_item_assembling}]
                        null;

                        supplier.done_assembling;
                      else
                        table.unavailable_piece_10;
                        table.table_unlock;
                      end select;
                    else
                      table.unavailable_piece_8;
                      table.table_unlock;
                    end select;
                  else
                    table.unavailable_piece_7;
                    table.table_unlock;
                  end select;
                else
                  table.unavailable_piece_6;
                  table.table_unlock;
                end select;
              else
                table.unavailable_piece_5;
                table.table_unlock;
              end select;
            else
              table.unavailable_piece_4;
              table.table_unlock;
            end select;
          else
            table.unavailable_piece_3;
            table.table_unlock;
          end select;
        else
          table.unavailable_piece_2;
          table.table_unlock;
        end select;
      else
        table.unavailable_piece_1;
        table.table_unlock;
      end select;

    end loop;
  end assembler_9;


  task body assembler_10 is
    done : boolean;
  begin
    loop
      exit when done;

      table.table_lock;

      select
        table.available_piece_1;  --event[{assembler_10_take_piece_1}]

        select
          table.available_piece_2;  --event[{assembler_10_take_piece_2}]

          select
            table.available_piece_3;  --event[{assembler_10_take_piece_3}]

            select
              table.available_piece_4;  --event[{assembler_10_take_piece_4}]

              select
                table.available_piece_5;  --event[{assembler_10_take_piece_5}]

                select
                  table.available_piece_6;  --event[{assembler_10_take_piece_6}]

                  select
                    table.available_piece_7;  --event[{assembler_10_take_piece_7}]

                    select
                      table.available_piece_8;  --event[{assembler_10_take_piece_8}]

                      select
                        table.available_piece_9;  --event[{assembler_10_take_piece_9}]

                        table.take_piece_1;
                        table.take_piece_2;
                        table.take_piece_3;
                        table.take_piece_4;
                        table.take_piece_5;
                        table.take_piece_6;
                        table.take_piece_7;
                        table.take_piece_8;
                        table.take_piece_9;
                        table.table_unlock;

                        null; --event[{start_item_assembling}]
                        null; --event[{start_item_assembling_10}]
                        null; --event[{stop_item_assembling_10}]
                        null; --event[{stop_item_assembling}]
                        null;

                        supplier.done_assembling;
                      else
                        table.unavailable_piece_9;
                        table.table_unlock;
                      end select;
                    else
                      table.unavailable_piece_8;
                      table.table_unlock;
                    end select;
                  else
                    table.unavailable_piece_7;
                    table.table_unlock;
                  end select;
                else
                  table.unavailable_piece_6;
                  table.table_unlock;
                end select;
              else
                table.unavailable_piece_5;
                table.table_unlock;
              end select;
            else
              table.unavailable_piece_4;
              table.table_unlock;
            end select;
          else
            table.unavailable_piece_3;
            table.table_unlock;
          end select;
        else
          table.unavailable_piece_2;
          table.table_unlock;
        end select;
      else
        table.unavailable_piece_1;
        table.table_unlock;
      end select;

    end loop;
  end assembler_10;


end smokers;

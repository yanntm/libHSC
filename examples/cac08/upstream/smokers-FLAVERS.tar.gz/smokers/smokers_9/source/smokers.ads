--
-- This is a generalization of the smokers problem.  There is one 
-- supplier task and n assembler tasks.  To assemble an item, an 
-- assembler needs n pieces; however, each assembler only has access 
-- to one of the n pieces.  There is a table onto which the supplier
-- puts down n-1 pieces.  The assembler with access to the piece
-- not on the table takes the n-1 pieces off the table, assembles
-- the item, and notifies the supplier that an item has been assembled.
--
-- See Abraham Silberschartz and Peter B. Galvin, "Operating System 
-- Concepts", Fourth Edition, Addison-Wesley Publishing Company,
-- page 212, 1994.
--
-- Generated on Sun Jul 30 13:23:18 2006
-- Assemblers:  9

package smokers is

  task supplier is
    entry done_assembling;
  end supplier;


  task table is
    entry table_lock;
    entry table_unlock;

    entry put_piece_1;
    entry take_piece_1;
    entry available_piece_1;
    entry unavailable_piece_1;

    entry put_piece_2;
    entry take_piece_2;
    entry available_piece_2;
    entry unavailable_piece_2;

    entry put_piece_3;
    entry take_piece_3;
    entry available_piece_3;
    entry unavailable_piece_3;

    entry put_piece_4;
    entry take_piece_4;
    entry available_piece_4;
    entry unavailable_piece_4;

    entry put_piece_5;
    entry take_piece_5;
    entry available_piece_5;
    entry unavailable_piece_5;

    entry put_piece_6;
    entry take_piece_6;
    entry available_piece_6;
    entry unavailable_piece_6;

    entry put_piece_7;
    entry take_piece_7;
    entry available_piece_7;
    entry unavailable_piece_7;

    entry put_piece_8;
    entry take_piece_8;
    entry available_piece_8;
    entry unavailable_piece_8;

    entry put_piece_9;
    entry take_piece_9;
    entry available_piece_9;
    entry unavailable_piece_9;
  end table;


  task assembler_1;
  task assembler_2;
  task assembler_3;
  task assembler_4;
  task assembler_5;
  task assembler_6;
  task assembler_7;
  task assembler_8;
  task assembler_9;

end smokers;

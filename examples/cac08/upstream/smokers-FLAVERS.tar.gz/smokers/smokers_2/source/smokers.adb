--
-- This is a generalization of the smokers problem.  There is one 
-- supplier task and n assembler tasks.  To assemble an item, an 
-- assembler needs n pieces; however, each assembler only has access 
-- to one of the n pieces.  There is a table onto which the supplier
-- puts down n-1 pieces.  The assembler with access to the piece
-- not on the table takes the n-1 pieces off the table, assembles
-- the item, and notifiers the supplier that an item has been assembled.
--
-- Generated on Wed Jan 28 14:12:17 2004
-- Assemblers:  2

package body smokers is

  task body supplier is
    done : boolean;
    switch : integer;
  begin
    loop
      exit when done;
      table.table_lock;
      case switch is
        when 1 =>
          table.put_piece_2;
        when 2 =>
          table.put_piece_1;
      end case;

      null; --event[{put_pieces}]
      null;

      table.table_unlock;

      accept done_assembling;
    end loop;
  end supplier;

  task body table is
    piece_1 : boolean;
    piece_2 : boolean;
    done : boolean;
  begin
    -- Initially no pieces are available
    piece_1 := false;  --event[{piece_1=f}]
    piece_2 := false;  --event[{piece_2=f}]
    null;

    loop
      exit when done;

      accept table_lock;

      loop
        select
          accept put_piece_1 do
            piece_1 := true;  --event[{piece_1=t}, {put_piece}]
            null;
          end put_piece_1;
        or
          when (piece_1) =>
            accept take_piece_1;  --eventb[{piece_1is=t}, {take_piece}]
            piece_1 := false;  --event[{piece_1=f}]
            null;
        or
          when (piece_1) =>
            accept available_piece_1; --eventb[{piece_1is=t}]
            null;
        or
          when (not piece_1) =>
            accept unavailable_piece_1; --eventb[{piece_1is=f}]
            null;
        or
          accept put_piece_2 do
            piece_2 := true;  --event[{piece_2=t}, {put_piece}]
            null;
          end put_piece_2;
        or
          when (piece_2) =>
            accept take_piece_2;  --eventb[{piece_2is=t}, {take_piece}]
            piece_2 := false;  --event[{piece_2=f}]
            null;
        or
          when (piece_2) =>
            accept available_piece_2; --eventb[{piece_2is=t}]
            null;
        or
          when (not piece_2) =>
            accept unavailable_piece_2; --eventb[{piece_2is=f}]
            null;
        or
          accept table_unlock;
            exit;
        end select;
      end loop;
    end loop;
  end table;


  task body assembler_1 is
    done : boolean;
  begin
    loop
      exit when done;

      table.table_lock;

      select
        table.available_piece_2;  --event[{assembler_1_take_piece_2}]

        table.take_piece_2;
        table.table_unlock;

        null; --event[{start_item_assembling}]
        null; --event[{start_item_assembling_1}]
        null; --event[{stop_item_assembling_1}]
        null; --event[{stop_item_assembling}]
        null;

        supplier.done_assembling;
      else
        table.unavailable_piece_2;
      end select;

    end loop;
  end assembler_1;


  task body assembler_2 is
    done : boolean;
  begin
    loop
      exit when done;

      table.table_lock;

      select
        table.available_piece_1;  --event[{assembler_2_take_piece_1}]

        table.take_piece_1;
        table.table_unlock;

        null; --event[{start_item_assembling}]
        null; --event[{start_item_assembling_2}]
        null; --event[{stop_item_assembling_2}]
        null; --event[{stop_item_assembling}]
        null;

        supplier.done_assembling;
      else
        table.unavailable_piece_1;
      end select;

    end loop;
  end assembler_2;


end smokers;

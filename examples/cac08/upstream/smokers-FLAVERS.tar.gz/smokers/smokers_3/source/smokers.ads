--
-- This is a generalization of the smokers problem.  There is one 
-- supplier task and n assembler tasks.  To assemble an item, an 
-- assembler needs n pieces; however, each assembler only has access 
-- to one of the n pieces.  There is a table onto which the supplier
-- puts down n-1 pieces.  The assembler with access to the piece
-- not on the table takes the n-1 pieces off the table, assembles
-- the item, and notifies the supplier that an item has been assembled.
--
-- See Abraham Silberschartz and Peter B. Galvin, "Operating System 
-- Concepts", Fourth Edition, Addison-Wesley Publishing Company,
-- page 212, 1994.
--
-- Generated on Wed Jan 19 15:53:57 2005
-- Assemblers:  3

package smokers is

  task supplier is
    entry done_assembling;
  end supplier;


  task table is
    entry table_lock;
    entry table_unlock;

    entry put_piece_1;
    entry take_piece_1;
    entry available_piece_1;
    entry unavailable_piece_1;

    entry put_piece_2;
    entry take_piece_2;
    entry available_piece_2;
    entry unavailable_piece_2;

    entry put_piece_3;
    entry take_piece_3;
    entry available_piece_3;
    entry unavailable_piece_3;
  end table;


  task assembler_1;
  task assembler_2;
  task assembler_3;

end smokers;

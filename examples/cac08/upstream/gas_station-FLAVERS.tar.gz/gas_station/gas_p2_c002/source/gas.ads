-- Generated on Tue Oct 12 13:58:56 2004
-- Pumps:     2
-- Customers: 2

procedure gas;


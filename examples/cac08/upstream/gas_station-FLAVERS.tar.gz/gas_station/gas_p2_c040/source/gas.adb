-- Generated on Mon Jul 24 22:24:14 2006
-- Pumps:     2
-- Customers: 040

procedure gas is

N : constant natural := 040;  -- number of customers
type cust_range is range 0 .. N;
type pump_range is range 1 .. 2;

task operator is
  entry prepay_1_pump_1;
  entry charge_1_pump_1;
  entry prepay_2_pump_1;
  entry charge_2_pump_1;
  entry prepay_3_pump_1;
  entry charge_3_pump_1;
  entry prepay_4_pump_1;
  entry charge_4_pump_1;
  entry prepay_5_pump_1;
  entry charge_5_pump_1;
  entry prepay_6_pump_1;
  entry charge_6_pump_1;
  entry prepay_7_pump_1;
  entry charge_7_pump_1;
  entry prepay_8_pump_1;
  entry charge_8_pump_1;
  entry prepay_9_pump_1;
  entry charge_9_pump_1;
  entry prepay_10_pump_1;
  entry charge_10_pump_1;
  entry prepay_11_pump_1;
  entry charge_11_pump_1;
  entry prepay_12_pump_1;
  entry charge_12_pump_1;
  entry prepay_13_pump_1;
  entry charge_13_pump_1;
  entry prepay_14_pump_1;
  entry charge_14_pump_1;
  entry prepay_15_pump_1;
  entry charge_15_pump_1;
  entry prepay_16_pump_1;
  entry charge_16_pump_1;
  entry prepay_17_pump_1;
  entry charge_17_pump_1;
  entry prepay_18_pump_1;
  entry charge_18_pump_1;
  entry prepay_19_pump_1;
  entry charge_19_pump_1;
  entry prepay_20_pump_1;
  entry charge_20_pump_1;
  entry prepay_21_pump_1;
  entry charge_21_pump_1;
  entry prepay_22_pump_1;
  entry charge_22_pump_1;
  entry prepay_23_pump_1;
  entry charge_23_pump_1;
  entry prepay_24_pump_1;
  entry charge_24_pump_1;
  entry prepay_25_pump_1;
  entry charge_25_pump_1;
  entry prepay_26_pump_1;
  entry charge_26_pump_1;
  entry prepay_27_pump_1;
  entry charge_27_pump_1;
  entry prepay_28_pump_1;
  entry charge_28_pump_1;
  entry prepay_29_pump_1;
  entry charge_29_pump_1;
  entry prepay_30_pump_1;
  entry charge_30_pump_1;
  entry prepay_31_pump_1;
  entry charge_31_pump_1;
  entry prepay_32_pump_1;
  entry charge_32_pump_1;
  entry prepay_33_pump_1;
  entry charge_33_pump_1;
  entry prepay_34_pump_1;
  entry charge_34_pump_1;
  entry prepay_35_pump_1;
  entry charge_35_pump_1;
  entry prepay_36_pump_1;
  entry charge_36_pump_1;
  entry prepay_37_pump_1;
  entry charge_37_pump_1;
  entry prepay_38_pump_1;
  entry charge_38_pump_1;
  entry prepay_39_pump_1;
  entry charge_39_pump_1;
  entry prepay_40_pump_1;
  entry charge_40_pump_1;
  entry prepay_1_pump_2;
  entry charge_1_pump_2;
  entry prepay_2_pump_2;
  entry charge_2_pump_2;
  entry prepay_3_pump_2;
  entry charge_3_pump_2;
  entry prepay_4_pump_2;
  entry charge_4_pump_2;
  entry prepay_5_pump_2;
  entry charge_5_pump_2;
  entry prepay_6_pump_2;
  entry charge_6_pump_2;
  entry prepay_7_pump_2;
  entry charge_7_pump_2;
  entry prepay_8_pump_2;
  entry charge_8_pump_2;
  entry prepay_9_pump_2;
  entry charge_9_pump_2;
  entry prepay_10_pump_2;
  entry charge_10_pump_2;
  entry prepay_11_pump_2;
  entry charge_11_pump_2;
  entry prepay_12_pump_2;
  entry charge_12_pump_2;
  entry prepay_13_pump_2;
  entry charge_13_pump_2;
  entry prepay_14_pump_2;
  entry charge_14_pump_2;
  entry prepay_15_pump_2;
  entry charge_15_pump_2;
  entry prepay_16_pump_2;
  entry charge_16_pump_2;
  entry prepay_17_pump_2;
  entry charge_17_pump_2;
  entry prepay_18_pump_2;
  entry charge_18_pump_2;
  entry prepay_19_pump_2;
  entry charge_19_pump_2;
  entry prepay_20_pump_2;
  entry charge_20_pump_2;
  entry prepay_21_pump_2;
  entry charge_21_pump_2;
  entry prepay_22_pump_2;
  entry charge_22_pump_2;
  entry prepay_23_pump_2;
  entry charge_23_pump_2;
  entry prepay_24_pump_2;
  entry charge_24_pump_2;
  entry prepay_25_pump_2;
  entry charge_25_pump_2;
  entry prepay_26_pump_2;
  entry charge_26_pump_2;
  entry prepay_27_pump_2;
  entry charge_27_pump_2;
  entry prepay_28_pump_2;
  entry charge_28_pump_2;
  entry prepay_29_pump_2;
  entry charge_29_pump_2;
  entry prepay_30_pump_2;
  entry charge_30_pump_2;
  entry prepay_31_pump_2;
  entry charge_31_pump_2;
  entry prepay_32_pump_2;
  entry charge_32_pump_2;
  entry prepay_33_pump_2;
  entry charge_33_pump_2;
  entry prepay_34_pump_2;
  entry charge_34_pump_2;
  entry prepay_35_pump_2;
  entry charge_35_pump_2;
  entry prepay_36_pump_2;
  entry charge_36_pump_2;
  entry prepay_37_pump_2;
  entry charge_37_pump_2;
  entry prepay_38_pump_2;
  entry charge_38_pump_2;
  entry prepay_39_pump_2;
  entry charge_39_pump_2;
  entry prepay_40_pump_2;
  entry charge_40_pump_2;
end operator;


task pump_1 is
  entry activate;
  entry start_pumping;
  entry stop_pumping_1;
  entry stop_pumping_2;
  entry stop_pumping_3;
  entry stop_pumping_4;
  entry stop_pumping_5;
  entry stop_pumping_6;
  entry stop_pumping_7;
  entry stop_pumping_8;
  entry stop_pumping_9;
  entry stop_pumping_10;
  entry stop_pumping_11;
  entry stop_pumping_12;
  entry stop_pumping_13;
  entry stop_pumping_14;
  entry stop_pumping_15;
  entry stop_pumping_16;
  entry stop_pumping_17;
  entry stop_pumping_18;
  entry stop_pumping_19;
  entry stop_pumping_20;
  entry stop_pumping_21;
  entry stop_pumping_22;
  entry stop_pumping_23;
  entry stop_pumping_24;
  entry stop_pumping_25;
  entry stop_pumping_26;
  entry stop_pumping_27;
  entry stop_pumping_28;
  entry stop_pumping_29;
  entry stop_pumping_30;
  entry stop_pumping_31;
  entry stop_pumping_32;
  entry stop_pumping_33;
  entry stop_pumping_34;
  entry stop_pumping_35;
  entry stop_pumping_36;
  entry stop_pumping_37;
  entry stop_pumping_38;
  entry stop_pumping_39;
  entry stop_pumping_40;
end pump_1;


task pump_2 is
  entry activate;
  entry start_pumping;
  entry stop_pumping_1;
  entry stop_pumping_2;
  entry stop_pumping_3;
  entry stop_pumping_4;
  entry stop_pumping_5;
  entry stop_pumping_6;
  entry stop_pumping_7;
  entry stop_pumping_8;
  entry stop_pumping_9;
  entry stop_pumping_10;
  entry stop_pumping_11;
  entry stop_pumping_12;
  entry stop_pumping_13;
  entry stop_pumping_14;
  entry stop_pumping_15;
  entry stop_pumping_16;
  entry stop_pumping_17;
  entry stop_pumping_18;
  entry stop_pumping_19;
  entry stop_pumping_20;
  entry stop_pumping_21;
  entry stop_pumping_22;
  entry stop_pumping_23;
  entry stop_pumping_24;
  entry stop_pumping_25;
  entry stop_pumping_26;
  entry stop_pumping_27;
  entry stop_pumping_28;
  entry stop_pumping_29;
  entry stop_pumping_30;
  entry stop_pumping_31;
  entry stop_pumping_32;
  entry stop_pumping_33;
  entry stop_pumping_34;
  entry stop_pumping_35;
  entry stop_pumping_36;
  entry stop_pumping_37;
  entry stop_pumping_38;
  entry stop_pumping_39;
  entry stop_pumping_40;
end pump_2;


task customer_1 is
  entry change;
end customer_1;


task customer_2 is
  entry change;
end customer_2;


task customer_3 is
  entry change;
end customer_3;


task customer_4 is
  entry change;
end customer_4;


task customer_5 is
  entry change;
end customer_5;


task customer_6 is
  entry change;
end customer_6;


task customer_7 is
  entry change;
end customer_7;


task customer_8 is
  entry change;
end customer_8;


task customer_9 is
  entry change;
end customer_9;


task customer_10 is
  entry change;
end customer_10;


task customer_11 is
  entry change;
end customer_11;


task customer_12 is
  entry change;
end customer_12;


task customer_13 is
  entry change;
end customer_13;


task customer_14 is
  entry change;
end customer_14;


task customer_15 is
  entry change;
end customer_15;


task customer_16 is
  entry change;
end customer_16;


task customer_17 is
  entry change;
end customer_17;


task customer_18 is
  entry change;
end customer_18;


task customer_19 is
  entry change;
end customer_19;


task customer_20 is
  entry change;
end customer_20;


task customer_21 is
  entry change;
end customer_21;


task customer_22 is
  entry change;
end customer_22;


task customer_23 is
  entry change;
end customer_23;


task customer_24 is
  entry change;
end customer_24;


task customer_25 is
  entry change;
end customer_25;


task customer_26 is
  entry change;
end customer_26;


task customer_27 is
  entry change;
end customer_27;


task customer_28 is
  entry change;
end customer_28;


task customer_29 is
  entry change;
end customer_29;


task customer_30 is
  entry change;
end customer_30;


task customer_31 is
  entry change;
end customer_31;


task customer_32 is
  entry change;
end customer_32;


task customer_33 is
  entry change;
end customer_33;


task customer_34 is
  entry change;
end customer_34;


task customer_35 is
  entry change;
end customer_35;


task customer_36 is
  entry change;
end customer_36;


task customer_37 is
  entry change;
end customer_37;


task customer_38 is
  entry change;
end customer_38;


task customer_39 is
  entry change;
end customer_39;


task customer_40 is
  entry change;
end customer_40;


task body operator is
  Pump_1_ActiveCustomers : cust_range;
  Pump_2_ActiveCustomers : cust_range;
  done : boolean;
begin
  Pump_1_ActiveCustomers := 0; --event[{p1ac=0}]
  Pump_2_ActiveCustomers := 0; --event[{p2ac=0}]
  null;
  loop
  -- if there are no active customers, we can exit
    if ((Pump_1_ActiveCustomers = 0) and
        (Pump_2_ActiveCustomers = 0)) then
      null; --eventb[{p1acis=0}]
      null; --eventb[{p2acis=0}]
      null;
      exit when done;
    end if;

    select
      accept prepay_1_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_1_pump_1;

    or

      accept charge_1_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_1.change; --eventb[{cust_1_pump_1_change}]
      null;

    or

      accept prepay_2_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_2_pump_1;

    or

      accept charge_2_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_2.change; --eventb[{cust_2_pump_1_change}]
      null;

    or

      accept prepay_3_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_3_pump_1;

    or

      accept charge_3_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_3.change; --eventb[{cust_3_pump_1_change}]
      null;

    or

      accept prepay_4_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_4_pump_1;

    or

      accept charge_4_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_4.change; --eventb[{cust_4_pump_1_change}]
      null;

    or

      accept prepay_5_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_5_pump_1;

    or

      accept charge_5_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_5.change; --eventb[{cust_5_pump_1_change}]
      null;

    or

      accept prepay_6_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_6_pump_1;

    or

      accept charge_6_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_6.change; --eventb[{cust_6_pump_1_change}]
      null;

    or

      accept prepay_7_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_7_pump_1;

    or

      accept charge_7_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_7.change; --eventb[{cust_7_pump_1_change}]
      null;

    or

      accept prepay_8_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_8_pump_1;

    or

      accept charge_8_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_8.change; --eventb[{cust_8_pump_1_change}]
      null;

    or

      accept prepay_9_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_9_pump_1;

    or

      accept charge_9_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_9.change; --eventb[{cust_9_pump_1_change}]
      null;

    or

      accept prepay_10_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_10_pump_1;

    or

      accept charge_10_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_10.change; --eventb[{cust_10_pump_1_change}]
      null;

    or

      accept prepay_11_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_11_pump_1;

    or

      accept charge_11_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_11.change; --eventb[{cust_11_pump_1_change}]
      null;

    or

      accept prepay_12_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_12_pump_1;

    or

      accept charge_12_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_12.change; --eventb[{cust_12_pump_1_change}]
      null;

    or

      accept prepay_13_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_13_pump_1;

    or

      accept charge_13_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_13.change; --eventb[{cust_13_pump_1_change}]
      null;

    or

      accept prepay_14_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_14_pump_1;

    or

      accept charge_14_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_14.change; --eventb[{cust_14_pump_1_change}]
      null;

    or

      accept prepay_15_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_15_pump_1;

    or

      accept charge_15_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_15.change; --eventb[{cust_15_pump_1_change}]
      null;

    or

      accept prepay_16_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_16_pump_1;

    or

      accept charge_16_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_16.change; --eventb[{cust_16_pump_1_change}]
      null;

    or

      accept prepay_17_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_17_pump_1;

    or

      accept charge_17_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_17.change; --eventb[{cust_17_pump_1_change}]
      null;

    or

      accept prepay_18_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_18_pump_1;

    or

      accept charge_18_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_18.change; --eventb[{cust_18_pump_1_change}]
      null;

    or

      accept prepay_19_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_19_pump_1;

    or

      accept charge_19_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_19.change; --eventb[{cust_19_pump_1_change}]
      null;

    or

      accept prepay_20_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_20_pump_1;

    or

      accept charge_20_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_20.change; --eventb[{cust_20_pump_1_change}]
      null;

    or

      accept prepay_21_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_21_pump_1;

    or

      accept charge_21_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_21.change; --eventb[{cust_21_pump_1_change}]
      null;

    or

      accept prepay_22_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_22_pump_1;

    or

      accept charge_22_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_22.change; --eventb[{cust_22_pump_1_change}]
      null;

    or

      accept prepay_23_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_23_pump_1;

    or

      accept charge_23_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_23.change; --eventb[{cust_23_pump_1_change}]
      null;

    or

      accept prepay_24_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_24_pump_1;

    or

      accept charge_24_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_24.change; --eventb[{cust_24_pump_1_change}]
      null;

    or

      accept prepay_25_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_25_pump_1;

    or

      accept charge_25_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_25.change; --eventb[{cust_25_pump_1_change}]
      null;

    or

      accept prepay_26_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_26_pump_1;

    or

      accept charge_26_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_26.change; --eventb[{cust_26_pump_1_change}]
      null;

    or

      accept prepay_27_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_27_pump_1;

    or

      accept charge_27_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_27.change; --eventb[{cust_27_pump_1_change}]
      null;

    or

      accept prepay_28_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_28_pump_1;

    or

      accept charge_28_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_28.change; --eventb[{cust_28_pump_1_change}]
      null;

    or

      accept prepay_29_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_29_pump_1;

    or

      accept charge_29_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_29.change; --eventb[{cust_29_pump_1_change}]
      null;

    or

      accept prepay_30_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_30_pump_1;

    or

      accept charge_30_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_30.change; --eventb[{cust_30_pump_1_change}]
      null;

    or

      accept prepay_31_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_31_pump_1;

    or

      accept charge_31_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_31.change; --eventb[{cust_31_pump_1_change}]
      null;

    or

      accept prepay_32_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_32_pump_1;

    or

      accept charge_32_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_32.change; --eventb[{cust_32_pump_1_change}]
      null;

    or

      accept prepay_33_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_33_pump_1;

    or

      accept charge_33_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_33.change; --eventb[{cust_33_pump_1_change}]
      null;

    or

      accept prepay_34_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_34_pump_1;

    or

      accept charge_34_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_34.change; --eventb[{cust_34_pump_1_change}]
      null;

    or

      accept prepay_35_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_35_pump_1;

    or

      accept charge_35_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_35.change; --eventb[{cust_35_pump_1_change}]
      null;

    or

      accept prepay_36_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_36_pump_1;

    or

      accept charge_36_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_36.change; --eventb[{cust_36_pump_1_change}]
      null;

    or

      accept prepay_37_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_37_pump_1;

    or

      accept charge_37_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_37.change; --eventb[{cust_37_pump_1_change}]
      null;

    or

      accept prepay_38_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_38_pump_1;

    or

      accept charge_38_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_38.change; --eventb[{cust_38_pump_1_change}]
      null;

    or

      accept prepay_39_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_39_pump_1;

    or

      accept charge_39_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_39.change; --eventb[{cust_39_pump_1_change}]
      null;

    or

      accept prepay_40_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_40_pump_1;

    or

      accept charge_40_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_40.change; --eventb[{cust_40_pump_1_change}]
      null;

    or

      accept prepay_1_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_1_pump_2;

    or

      accept charge_1_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_1.change; --eventb[{cust_1_pump_2_change}]
      null;

    or

      accept prepay_2_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_2_pump_2;

    or

      accept charge_2_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_2.change; --eventb[{cust_2_pump_2_change}]
      null;

    or

      accept prepay_3_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_3_pump_2;

    or

      accept charge_3_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_3.change; --eventb[{cust_3_pump_2_change}]
      null;

    or

      accept prepay_4_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_4_pump_2;

    or

      accept charge_4_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_4.change; --eventb[{cust_4_pump_2_change}]
      null;

    or

      accept prepay_5_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_5_pump_2;

    or

      accept charge_5_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_5.change; --eventb[{cust_5_pump_2_change}]
      null;

    or

      accept prepay_6_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_6_pump_2;

    or

      accept charge_6_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_6.change; --eventb[{cust_6_pump_2_change}]
      null;

    or

      accept prepay_7_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_7_pump_2;

    or

      accept charge_7_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_7.change; --eventb[{cust_7_pump_2_change}]
      null;

    or

      accept prepay_8_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_8_pump_2;

    or

      accept charge_8_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_8.change; --eventb[{cust_8_pump_2_change}]
      null;

    or

      accept prepay_9_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_9_pump_2;

    or

      accept charge_9_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_9.change; --eventb[{cust_9_pump_2_change}]
      null;

    or

      accept prepay_10_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_10_pump_2;

    or

      accept charge_10_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_10.change; --eventb[{cust_10_pump_2_change}]
      null;

    or

      accept prepay_11_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_11_pump_2;

    or

      accept charge_11_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_11.change; --eventb[{cust_11_pump_2_change}]
      null;

    or

      accept prepay_12_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_12_pump_2;

    or

      accept charge_12_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_12.change; --eventb[{cust_12_pump_2_change}]
      null;

    or

      accept prepay_13_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_13_pump_2;

    or

      accept charge_13_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_13.change; --eventb[{cust_13_pump_2_change}]
      null;

    or

      accept prepay_14_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_14_pump_2;

    or

      accept charge_14_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_14.change; --eventb[{cust_14_pump_2_change}]
      null;

    or

      accept prepay_15_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_15_pump_2;

    or

      accept charge_15_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_15.change; --eventb[{cust_15_pump_2_change}]
      null;

    or

      accept prepay_16_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_16_pump_2;

    or

      accept charge_16_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_16.change; --eventb[{cust_16_pump_2_change}]
      null;

    or

      accept prepay_17_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_17_pump_2;

    or

      accept charge_17_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_17.change; --eventb[{cust_17_pump_2_change}]
      null;

    or

      accept prepay_18_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_18_pump_2;

    or

      accept charge_18_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_18.change; --eventb[{cust_18_pump_2_change}]
      null;

    or

      accept prepay_19_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_19_pump_2;

    or

      accept charge_19_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_19.change; --eventb[{cust_19_pump_2_change}]
      null;

    or

      accept prepay_20_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_20_pump_2;

    or

      accept charge_20_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_20.change; --eventb[{cust_20_pump_2_change}]
      null;

    or

      accept prepay_21_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_21_pump_2;

    or

      accept charge_21_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_21.change; --eventb[{cust_21_pump_2_change}]
      null;

    or

      accept prepay_22_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_22_pump_2;

    or

      accept charge_22_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_22.change; --eventb[{cust_22_pump_2_change}]
      null;

    or

      accept prepay_23_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_23_pump_2;

    or

      accept charge_23_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_23.change; --eventb[{cust_23_pump_2_change}]
      null;

    or

      accept prepay_24_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_24_pump_2;

    or

      accept charge_24_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_24.change; --eventb[{cust_24_pump_2_change}]
      null;

    or

      accept prepay_25_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_25_pump_2;

    or

      accept charge_25_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_25.change; --eventb[{cust_25_pump_2_change}]
      null;

    or

      accept prepay_26_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_26_pump_2;

    or

      accept charge_26_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_26.change; --eventb[{cust_26_pump_2_change}]
      null;

    or

      accept prepay_27_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_27_pump_2;

    or

      accept charge_27_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_27.change; --eventb[{cust_27_pump_2_change}]
      null;

    or

      accept prepay_28_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_28_pump_2;

    or

      accept charge_28_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_28.change; --eventb[{cust_28_pump_2_change}]
      null;

    or

      accept prepay_29_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_29_pump_2;

    or

      accept charge_29_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_29.change; --eventb[{cust_29_pump_2_change}]
      null;

    or

      accept prepay_30_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_30_pump_2;

    or

      accept charge_30_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_30.change; --eventb[{cust_30_pump_2_change}]
      null;

    or

      accept prepay_31_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_31_pump_2;

    or

      accept charge_31_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_31.change; --eventb[{cust_31_pump_2_change}]
      null;

    or

      accept prepay_32_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_32_pump_2;

    or

      accept charge_32_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_32.change; --eventb[{cust_32_pump_2_change}]
      null;

    or

      accept prepay_33_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_33_pump_2;

    or

      accept charge_33_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_33.change; --eventb[{cust_33_pump_2_change}]
      null;

    or

      accept prepay_34_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_34_pump_2;

    or

      accept charge_34_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_34.change; --eventb[{cust_34_pump_2_change}]
      null;

    or

      accept prepay_35_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_35_pump_2;

    or

      accept charge_35_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_35.change; --eventb[{cust_35_pump_2_change}]
      null;

    or

      accept prepay_36_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_36_pump_2;

    or

      accept charge_36_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_36.change; --eventb[{cust_36_pump_2_change}]
      null;

    or

      accept prepay_37_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_37_pump_2;

    or

      accept charge_37_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_37.change; --eventb[{cust_37_pump_2_change}]
      null;

    or

      accept prepay_38_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_38_pump_2;

    or

      accept charge_38_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_38.change; --eventb[{cust_38_pump_2_change}]
      null;

    or

      accept prepay_39_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_39_pump_2;

    or

      accept charge_39_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_39.change; --eventb[{cust_39_pump_2_change}]
      null;

    or

      accept prepay_40_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_40_pump_2;

    or

      accept charge_40_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_40.change; --eventb[{cust_40_pump_2_change}]
      null;
    end select;
  end loop;
end operator;


task body pump_1 is
  done : boolean;
begin
  loop
    exit when done;
    accept activate;
    accept start_pumping; --event[{pump_1_start}]
    null;

    select
      accept stop_pumping_1 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_1_pump_1;
      end stop_pumping_1;
    or
      accept stop_pumping_2 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_2_pump_1;
      end stop_pumping_2;
    or
      accept stop_pumping_3 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_3_pump_1;
      end stop_pumping_3;
    or
      accept stop_pumping_4 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_4_pump_1;
      end stop_pumping_4;
    or
      accept stop_pumping_5 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_5_pump_1;
      end stop_pumping_5;
    or
      accept stop_pumping_6 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_6_pump_1;
      end stop_pumping_6;
    or
      accept stop_pumping_7 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_7_pump_1;
      end stop_pumping_7;
    or
      accept stop_pumping_8 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_8_pump_1;
      end stop_pumping_8;
    or
      accept stop_pumping_9 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_9_pump_1;
      end stop_pumping_9;
    or
      accept stop_pumping_10 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_10_pump_1;
      end stop_pumping_10;
    or
      accept stop_pumping_11 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_11_pump_1;
      end stop_pumping_11;
    or
      accept stop_pumping_12 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_12_pump_1;
      end stop_pumping_12;
    or
      accept stop_pumping_13 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_13_pump_1;
      end stop_pumping_13;
    or
      accept stop_pumping_14 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_14_pump_1;
      end stop_pumping_14;
    or
      accept stop_pumping_15 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_15_pump_1;
      end stop_pumping_15;
    or
      accept stop_pumping_16 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_16_pump_1;
      end stop_pumping_16;
    or
      accept stop_pumping_17 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_17_pump_1;
      end stop_pumping_17;
    or
      accept stop_pumping_18 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_18_pump_1;
      end stop_pumping_18;
    or
      accept stop_pumping_19 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_19_pump_1;
      end stop_pumping_19;
    or
      accept stop_pumping_20 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_20_pump_1;
      end stop_pumping_20;
    or
      accept stop_pumping_21 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_21_pump_1;
      end stop_pumping_21;
    or
      accept stop_pumping_22 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_22_pump_1;
      end stop_pumping_22;
    or
      accept stop_pumping_23 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_23_pump_1;
      end stop_pumping_23;
    or
      accept stop_pumping_24 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_24_pump_1;
      end stop_pumping_24;
    or
      accept stop_pumping_25 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_25_pump_1;
      end stop_pumping_25;
    or
      accept stop_pumping_26 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_26_pump_1;
      end stop_pumping_26;
    or
      accept stop_pumping_27 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_27_pump_1;
      end stop_pumping_27;
    or
      accept stop_pumping_28 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_28_pump_1;
      end stop_pumping_28;
    or
      accept stop_pumping_29 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_29_pump_1;
      end stop_pumping_29;
    or
      accept stop_pumping_30 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_30_pump_1;
      end stop_pumping_30;
    or
      accept stop_pumping_31 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_31_pump_1;
      end stop_pumping_31;
    or
      accept stop_pumping_32 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_32_pump_1;
      end stop_pumping_32;
    or
      accept stop_pumping_33 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_33_pump_1;
      end stop_pumping_33;
    or
      accept stop_pumping_34 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_34_pump_1;
      end stop_pumping_34;
    or
      accept stop_pumping_35 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_35_pump_1;
      end stop_pumping_35;
    or
      accept stop_pumping_36 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_36_pump_1;
      end stop_pumping_36;
    or
      accept stop_pumping_37 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_37_pump_1;
      end stop_pumping_37;
    or
      accept stop_pumping_38 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_38_pump_1;
      end stop_pumping_38;
    or
      accept stop_pumping_39 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_39_pump_1;
      end stop_pumping_39;
    or
      accept stop_pumping_40 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_40_pump_1;
      end stop_pumping_40;
    end select;
  end loop;
end pump_1;


task body pump_2 is
  done : boolean;
begin
  loop
    exit when done;
    accept activate;
    accept start_pumping; --event[{pump_2_start}]
    null;

    select
      accept stop_pumping_1 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_1_pump_2;
      end stop_pumping_1;
    or
      accept stop_pumping_2 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_2_pump_2;
      end stop_pumping_2;
    or
      accept stop_pumping_3 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_3_pump_2;
      end stop_pumping_3;
    or
      accept stop_pumping_4 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_4_pump_2;
      end stop_pumping_4;
    or
      accept stop_pumping_5 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_5_pump_2;
      end stop_pumping_5;
    or
      accept stop_pumping_6 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_6_pump_2;
      end stop_pumping_6;
    or
      accept stop_pumping_7 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_7_pump_2;
      end stop_pumping_7;
    or
      accept stop_pumping_8 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_8_pump_2;
      end stop_pumping_8;
    or
      accept stop_pumping_9 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_9_pump_2;
      end stop_pumping_9;
    or
      accept stop_pumping_10 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_10_pump_2;
      end stop_pumping_10;
    or
      accept stop_pumping_11 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_11_pump_2;
      end stop_pumping_11;
    or
      accept stop_pumping_12 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_12_pump_2;
      end stop_pumping_12;
    or
      accept stop_pumping_13 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_13_pump_2;
      end stop_pumping_13;
    or
      accept stop_pumping_14 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_14_pump_2;
      end stop_pumping_14;
    or
      accept stop_pumping_15 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_15_pump_2;
      end stop_pumping_15;
    or
      accept stop_pumping_16 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_16_pump_2;
      end stop_pumping_16;
    or
      accept stop_pumping_17 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_17_pump_2;
      end stop_pumping_17;
    or
      accept stop_pumping_18 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_18_pump_2;
      end stop_pumping_18;
    or
      accept stop_pumping_19 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_19_pump_2;
      end stop_pumping_19;
    or
      accept stop_pumping_20 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_20_pump_2;
      end stop_pumping_20;
    or
      accept stop_pumping_21 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_21_pump_2;
      end stop_pumping_21;
    or
      accept stop_pumping_22 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_22_pump_2;
      end stop_pumping_22;
    or
      accept stop_pumping_23 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_23_pump_2;
      end stop_pumping_23;
    or
      accept stop_pumping_24 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_24_pump_2;
      end stop_pumping_24;
    or
      accept stop_pumping_25 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_25_pump_2;
      end stop_pumping_25;
    or
      accept stop_pumping_26 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_26_pump_2;
      end stop_pumping_26;
    or
      accept stop_pumping_27 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_27_pump_2;
      end stop_pumping_27;
    or
      accept stop_pumping_28 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_28_pump_2;
      end stop_pumping_28;
    or
      accept stop_pumping_29 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_29_pump_2;
      end stop_pumping_29;
    or
      accept stop_pumping_30 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_30_pump_2;
      end stop_pumping_30;
    or
      accept stop_pumping_31 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_31_pump_2;
      end stop_pumping_31;
    or
      accept stop_pumping_32 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_32_pump_2;
      end stop_pumping_32;
    or
      accept stop_pumping_33 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_33_pump_2;
      end stop_pumping_33;
    or
      accept stop_pumping_34 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_34_pump_2;
      end stop_pumping_34;
    or
      accept stop_pumping_35 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_35_pump_2;
      end stop_pumping_35;
    or
      accept stop_pumping_36 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_36_pump_2;
      end stop_pumping_36;
    or
      accept stop_pumping_37 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_37_pump_2;
      end stop_pumping_37;
    or
      accept stop_pumping_38 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_38_pump_2;
      end stop_pumping_38;
    or
      accept stop_pumping_39 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_39_pump_2;
      end stop_pumping_39;
    or
      accept stop_pumping_40 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_40_pump_2;
      end stop_pumping_40;
    end select;
  end loop;
end pump_2;


task body customer_1 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_1_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_1_start_pump_1},{cust_1_start_pump}]
        gas.pump_1.stop_pumping_1; --eventb[{cust_1_stop_pump_1},{cust_1_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_1_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_1_start_pump_2},{cust_1_start_pump}]
        gas.pump_2.stop_pumping_1; --eventb[{cust_1_stop_pump_2},{cust_1_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_1;


task body customer_2 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_2_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_2_start_pump_1},{cust_2_start_pump}]
        gas.pump_1.stop_pumping_2; --eventb[{cust_2_stop_pump_1},{cust_2_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_2_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_2_start_pump_2},{cust_2_start_pump}]
        gas.pump_2.stop_pumping_2; --eventb[{cust_2_stop_pump_2},{cust_2_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_2;


task body customer_3 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_3_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_3_start_pump_1},{cust_3_start_pump}]
        gas.pump_1.stop_pumping_3; --eventb[{cust_3_stop_pump_1},{cust_3_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_3_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_3_start_pump_2},{cust_3_start_pump}]
        gas.pump_2.stop_pumping_3; --eventb[{cust_3_stop_pump_2},{cust_3_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_3;


task body customer_4 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_4_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_4_start_pump_1},{cust_4_start_pump}]
        gas.pump_1.stop_pumping_4; --eventb[{cust_4_stop_pump_1},{cust_4_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_4_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_4_start_pump_2},{cust_4_start_pump}]
        gas.pump_2.stop_pumping_4; --eventb[{cust_4_stop_pump_2},{cust_4_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_4;


task body customer_5 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_5_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_5_start_pump_1},{cust_5_start_pump}]
        gas.pump_1.stop_pumping_5; --eventb[{cust_5_stop_pump_1},{cust_5_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_5_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_5_start_pump_2},{cust_5_start_pump}]
        gas.pump_2.stop_pumping_5; --eventb[{cust_5_stop_pump_2},{cust_5_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_5;


task body customer_6 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_6_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_6_start_pump_1},{cust_6_start_pump}]
        gas.pump_1.stop_pumping_6; --eventb[{cust_6_stop_pump_1},{cust_6_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_6_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_6_start_pump_2},{cust_6_start_pump}]
        gas.pump_2.stop_pumping_6; --eventb[{cust_6_stop_pump_2},{cust_6_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_6;


task body customer_7 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_7_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_7_start_pump_1},{cust_7_start_pump}]
        gas.pump_1.stop_pumping_7; --eventb[{cust_7_stop_pump_1},{cust_7_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_7_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_7_start_pump_2},{cust_7_start_pump}]
        gas.pump_2.stop_pumping_7; --eventb[{cust_7_stop_pump_2},{cust_7_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_7;


task body customer_8 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_8_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_8_start_pump_1},{cust_8_start_pump}]
        gas.pump_1.stop_pumping_8; --eventb[{cust_8_stop_pump_1},{cust_8_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_8_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_8_start_pump_2},{cust_8_start_pump}]
        gas.pump_2.stop_pumping_8; --eventb[{cust_8_stop_pump_2},{cust_8_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_8;


task body customer_9 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_9_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_9_start_pump_1},{cust_9_start_pump}]
        gas.pump_1.stop_pumping_9; --eventb[{cust_9_stop_pump_1},{cust_9_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_9_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_9_start_pump_2},{cust_9_start_pump}]
        gas.pump_2.stop_pumping_9; --eventb[{cust_9_stop_pump_2},{cust_9_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_9;


task body customer_10 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_10_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_10_start_pump_1},{cust_10_start_pump}]
        gas.pump_1.stop_pumping_10; --eventb[{cust_10_stop_pump_1},{cust_10_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_10_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_10_start_pump_2},{cust_10_start_pump}]
        gas.pump_2.stop_pumping_10; --eventb[{cust_10_stop_pump_2},{cust_10_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_10;


task body customer_11 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_11_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_11_start_pump_1},{cust_11_start_pump}]
        gas.pump_1.stop_pumping_11; --eventb[{cust_11_stop_pump_1},{cust_11_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_11_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_11_start_pump_2},{cust_11_start_pump}]
        gas.pump_2.stop_pumping_11; --eventb[{cust_11_stop_pump_2},{cust_11_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_11;


task body customer_12 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_12_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_12_start_pump_1},{cust_12_start_pump}]
        gas.pump_1.stop_pumping_12; --eventb[{cust_12_stop_pump_1},{cust_12_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_12_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_12_start_pump_2},{cust_12_start_pump}]
        gas.pump_2.stop_pumping_12; --eventb[{cust_12_stop_pump_2},{cust_12_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_12;


task body customer_13 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_13_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_13_start_pump_1},{cust_13_start_pump}]
        gas.pump_1.stop_pumping_13; --eventb[{cust_13_stop_pump_1},{cust_13_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_13_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_13_start_pump_2},{cust_13_start_pump}]
        gas.pump_2.stop_pumping_13; --eventb[{cust_13_stop_pump_2},{cust_13_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_13;


task body customer_14 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_14_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_14_start_pump_1},{cust_14_start_pump}]
        gas.pump_1.stop_pumping_14; --eventb[{cust_14_stop_pump_1},{cust_14_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_14_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_14_start_pump_2},{cust_14_start_pump}]
        gas.pump_2.stop_pumping_14; --eventb[{cust_14_stop_pump_2},{cust_14_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_14;


task body customer_15 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_15_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_15_start_pump_1},{cust_15_start_pump}]
        gas.pump_1.stop_pumping_15; --eventb[{cust_15_stop_pump_1},{cust_15_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_15_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_15_start_pump_2},{cust_15_start_pump}]
        gas.pump_2.stop_pumping_15; --eventb[{cust_15_stop_pump_2},{cust_15_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_15;


task body customer_16 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_16_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_16_start_pump_1},{cust_16_start_pump}]
        gas.pump_1.stop_pumping_16; --eventb[{cust_16_stop_pump_1},{cust_16_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_16_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_16_start_pump_2},{cust_16_start_pump}]
        gas.pump_2.stop_pumping_16; --eventb[{cust_16_stop_pump_2},{cust_16_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_16;


task body customer_17 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_17_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_17_start_pump_1},{cust_17_start_pump}]
        gas.pump_1.stop_pumping_17; --eventb[{cust_17_stop_pump_1},{cust_17_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_17_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_17_start_pump_2},{cust_17_start_pump}]
        gas.pump_2.stop_pumping_17; --eventb[{cust_17_stop_pump_2},{cust_17_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_17;


task body customer_18 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_18_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_18_start_pump_1},{cust_18_start_pump}]
        gas.pump_1.stop_pumping_18; --eventb[{cust_18_stop_pump_1},{cust_18_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_18_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_18_start_pump_2},{cust_18_start_pump}]
        gas.pump_2.stop_pumping_18; --eventb[{cust_18_stop_pump_2},{cust_18_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_18;


task body customer_19 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_19_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_19_start_pump_1},{cust_19_start_pump}]
        gas.pump_1.stop_pumping_19; --eventb[{cust_19_stop_pump_1},{cust_19_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_19_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_19_start_pump_2},{cust_19_start_pump}]
        gas.pump_2.stop_pumping_19; --eventb[{cust_19_stop_pump_2},{cust_19_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_19;


task body customer_20 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_20_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_20_start_pump_1},{cust_20_start_pump}]
        gas.pump_1.stop_pumping_20; --eventb[{cust_20_stop_pump_1},{cust_20_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_20_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_20_start_pump_2},{cust_20_start_pump}]
        gas.pump_2.stop_pumping_20; --eventb[{cust_20_stop_pump_2},{cust_20_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_20;


task body customer_21 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_21_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_21_start_pump_1},{cust_21_start_pump}]
        gas.pump_1.stop_pumping_21; --eventb[{cust_21_stop_pump_1},{cust_21_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_21_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_21_start_pump_2},{cust_21_start_pump}]
        gas.pump_2.stop_pumping_21; --eventb[{cust_21_stop_pump_2},{cust_21_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_21;


task body customer_22 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_22_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_22_start_pump_1},{cust_22_start_pump}]
        gas.pump_1.stop_pumping_22; --eventb[{cust_22_stop_pump_1},{cust_22_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_22_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_22_start_pump_2},{cust_22_start_pump}]
        gas.pump_2.stop_pumping_22; --eventb[{cust_22_stop_pump_2},{cust_22_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_22;


task body customer_23 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_23_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_23_start_pump_1},{cust_23_start_pump}]
        gas.pump_1.stop_pumping_23; --eventb[{cust_23_stop_pump_1},{cust_23_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_23_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_23_start_pump_2},{cust_23_start_pump}]
        gas.pump_2.stop_pumping_23; --eventb[{cust_23_stop_pump_2},{cust_23_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_23;


task body customer_24 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_24_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_24_start_pump_1},{cust_24_start_pump}]
        gas.pump_1.stop_pumping_24; --eventb[{cust_24_stop_pump_1},{cust_24_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_24_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_24_start_pump_2},{cust_24_start_pump}]
        gas.pump_2.stop_pumping_24; --eventb[{cust_24_stop_pump_2},{cust_24_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_24;


task body customer_25 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_25_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_25_start_pump_1},{cust_25_start_pump}]
        gas.pump_1.stop_pumping_25; --eventb[{cust_25_stop_pump_1},{cust_25_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_25_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_25_start_pump_2},{cust_25_start_pump}]
        gas.pump_2.stop_pumping_25; --eventb[{cust_25_stop_pump_2},{cust_25_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_25;


task body customer_26 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_26_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_26_start_pump_1},{cust_26_start_pump}]
        gas.pump_1.stop_pumping_26; --eventb[{cust_26_stop_pump_1},{cust_26_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_26_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_26_start_pump_2},{cust_26_start_pump}]
        gas.pump_2.stop_pumping_26; --eventb[{cust_26_stop_pump_2},{cust_26_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_26;


task body customer_27 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_27_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_27_start_pump_1},{cust_27_start_pump}]
        gas.pump_1.stop_pumping_27; --eventb[{cust_27_stop_pump_1},{cust_27_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_27_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_27_start_pump_2},{cust_27_start_pump}]
        gas.pump_2.stop_pumping_27; --eventb[{cust_27_stop_pump_2},{cust_27_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_27;


task body customer_28 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_28_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_28_start_pump_1},{cust_28_start_pump}]
        gas.pump_1.stop_pumping_28; --eventb[{cust_28_stop_pump_1},{cust_28_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_28_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_28_start_pump_2},{cust_28_start_pump}]
        gas.pump_2.stop_pumping_28; --eventb[{cust_28_stop_pump_2},{cust_28_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_28;


task body customer_29 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_29_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_29_start_pump_1},{cust_29_start_pump}]
        gas.pump_1.stop_pumping_29; --eventb[{cust_29_stop_pump_1},{cust_29_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_29_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_29_start_pump_2},{cust_29_start_pump}]
        gas.pump_2.stop_pumping_29; --eventb[{cust_29_stop_pump_2},{cust_29_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_29;


task body customer_30 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_30_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_30_start_pump_1},{cust_30_start_pump}]
        gas.pump_1.stop_pumping_30; --eventb[{cust_30_stop_pump_1},{cust_30_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_30_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_30_start_pump_2},{cust_30_start_pump}]
        gas.pump_2.stop_pumping_30; --eventb[{cust_30_stop_pump_2},{cust_30_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_30;


task body customer_31 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_31_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_31_start_pump_1},{cust_31_start_pump}]
        gas.pump_1.stop_pumping_31; --eventb[{cust_31_stop_pump_1},{cust_31_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_31_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_31_start_pump_2},{cust_31_start_pump}]
        gas.pump_2.stop_pumping_31; --eventb[{cust_31_stop_pump_2},{cust_31_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_31;


task body customer_32 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_32_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_32_start_pump_1},{cust_32_start_pump}]
        gas.pump_1.stop_pumping_32; --eventb[{cust_32_stop_pump_1},{cust_32_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_32_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_32_start_pump_2},{cust_32_start_pump}]
        gas.pump_2.stop_pumping_32; --eventb[{cust_32_stop_pump_2},{cust_32_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_32;


task body customer_33 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_33_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_33_start_pump_1},{cust_33_start_pump}]
        gas.pump_1.stop_pumping_33; --eventb[{cust_33_stop_pump_1},{cust_33_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_33_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_33_start_pump_2},{cust_33_start_pump}]
        gas.pump_2.stop_pumping_33; --eventb[{cust_33_stop_pump_2},{cust_33_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_33;


task body customer_34 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_34_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_34_start_pump_1},{cust_34_start_pump}]
        gas.pump_1.stop_pumping_34; --eventb[{cust_34_stop_pump_1},{cust_34_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_34_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_34_start_pump_2},{cust_34_start_pump}]
        gas.pump_2.stop_pumping_34; --eventb[{cust_34_stop_pump_2},{cust_34_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_34;


task body customer_35 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_35_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_35_start_pump_1},{cust_35_start_pump}]
        gas.pump_1.stop_pumping_35; --eventb[{cust_35_stop_pump_1},{cust_35_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_35_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_35_start_pump_2},{cust_35_start_pump}]
        gas.pump_2.stop_pumping_35; --eventb[{cust_35_stop_pump_2},{cust_35_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_35;


task body customer_36 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_36_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_36_start_pump_1},{cust_36_start_pump}]
        gas.pump_1.stop_pumping_36; --eventb[{cust_36_stop_pump_1},{cust_36_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_36_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_36_start_pump_2},{cust_36_start_pump}]
        gas.pump_2.stop_pumping_36; --eventb[{cust_36_stop_pump_2},{cust_36_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_36;


task body customer_37 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_37_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_37_start_pump_1},{cust_37_start_pump}]
        gas.pump_1.stop_pumping_37; --eventb[{cust_37_stop_pump_1},{cust_37_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_37_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_37_start_pump_2},{cust_37_start_pump}]
        gas.pump_2.stop_pumping_37; --eventb[{cust_37_stop_pump_2},{cust_37_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_37;


task body customer_38 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_38_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_38_start_pump_1},{cust_38_start_pump}]
        gas.pump_1.stop_pumping_38; --eventb[{cust_38_stop_pump_1},{cust_38_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_38_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_38_start_pump_2},{cust_38_start_pump}]
        gas.pump_2.stop_pumping_38; --eventb[{cust_38_stop_pump_2},{cust_38_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_38;


task body customer_39 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_39_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_39_start_pump_1},{cust_39_start_pump}]
        gas.pump_1.stop_pumping_39; --eventb[{cust_39_stop_pump_1},{cust_39_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_39_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_39_start_pump_2},{cust_39_start_pump}]
        gas.pump_2.stop_pumping_39; --eventb[{cust_39_stop_pump_2},{cust_39_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_39;


task body customer_40 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_40_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_40_start_pump_1},{cust_40_start_pump}]
        gas.pump_1.stop_pumping_40; --eventb[{cust_40_stop_pump_1},{cust_40_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_40_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_40_start_pump_2},{cust_40_start_pump}]
        gas.pump_2.stop_pumping_40; --eventb[{cust_40_stop_pump_2},{cust_40_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_40;


begin
  null;
end gas;

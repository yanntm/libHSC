-- Generated on Sun Jul 30 13:28:32 2006
-- Pumps:     2
-- Customers: 9

procedure gas is

N : constant natural := 9;  -- number of customers
type cust_range is range 0 .. N;
type pump_range is range 1 .. 2;

task operator is
  entry prepay_1_pump_1;
  entry charge_1_pump_1;
  entry prepay_2_pump_1;
  entry charge_2_pump_1;
  entry prepay_3_pump_1;
  entry charge_3_pump_1;
  entry prepay_4_pump_1;
  entry charge_4_pump_1;
  entry prepay_5_pump_1;
  entry charge_5_pump_1;
  entry prepay_6_pump_1;
  entry charge_6_pump_1;
  entry prepay_7_pump_1;
  entry charge_7_pump_1;
  entry prepay_8_pump_1;
  entry charge_8_pump_1;
  entry prepay_9_pump_1;
  entry charge_9_pump_1;
  entry prepay_1_pump_2;
  entry charge_1_pump_2;
  entry prepay_2_pump_2;
  entry charge_2_pump_2;
  entry prepay_3_pump_2;
  entry charge_3_pump_2;
  entry prepay_4_pump_2;
  entry charge_4_pump_2;
  entry prepay_5_pump_2;
  entry charge_5_pump_2;
  entry prepay_6_pump_2;
  entry charge_6_pump_2;
  entry prepay_7_pump_2;
  entry charge_7_pump_2;
  entry prepay_8_pump_2;
  entry charge_8_pump_2;
  entry prepay_9_pump_2;
  entry charge_9_pump_2;
end operator;


task pump_1 is
  entry activate;
  entry start_pumping;
  entry stop_pumping_1;
  entry stop_pumping_2;
  entry stop_pumping_3;
  entry stop_pumping_4;
  entry stop_pumping_5;
  entry stop_pumping_6;
  entry stop_pumping_7;
  entry stop_pumping_8;
  entry stop_pumping_9;
end pump_1;


task pump_2 is
  entry activate;
  entry start_pumping;
  entry stop_pumping_1;
  entry stop_pumping_2;
  entry stop_pumping_3;
  entry stop_pumping_4;
  entry stop_pumping_5;
  entry stop_pumping_6;
  entry stop_pumping_7;
  entry stop_pumping_8;
  entry stop_pumping_9;
end pump_2;


task customer_1 is
  entry change;
end customer_1;


task customer_2 is
  entry change;
end customer_2;


task customer_3 is
  entry change;
end customer_3;


task customer_4 is
  entry change;
end customer_4;


task customer_5 is
  entry change;
end customer_5;


task customer_6 is
  entry change;
end customer_6;


task customer_7 is
  entry change;
end customer_7;


task customer_8 is
  entry change;
end customer_8;


task customer_9 is
  entry change;
end customer_9;


task body operator is
  Pump_1_ActiveCustomers : cust_range;
  Pump_2_ActiveCustomers : cust_range;
  done : boolean;
begin
  Pump_1_ActiveCustomers := 0; --event[{p1ac=0}]
  Pump_2_ActiveCustomers := 0; --event[{p2ac=0}]
  null;
  loop
  -- if there are no active customers, we can exit
    if ((Pump_1_ActiveCustomers = 0) and
        (Pump_2_ActiveCustomers = 0)) then
      null; --eventb[{p1acis=0}]
      null; --eventb[{p2acis=0}]
      null;
      exit when done;
    end if;

    select
      accept prepay_1_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_1_pump_1;

    or

      accept charge_1_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_1.change; --eventb[{cust_1_pump_1_change}]
      null;

    or

      accept prepay_2_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_2_pump_1;

    or

      accept charge_2_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_2.change; --eventb[{cust_2_pump_1_change}]
      null;

    or

      accept prepay_3_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_3_pump_1;

    or

      accept charge_3_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_3.change; --eventb[{cust_3_pump_1_change}]
      null;

    or

      accept prepay_4_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_4_pump_1;

    or

      accept charge_4_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_4.change; --eventb[{cust_4_pump_1_change}]
      null;

    or

      accept prepay_5_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_5_pump_1;

    or

      accept charge_5_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_5.change; --eventb[{cust_5_pump_1_change}]
      null;

    or

      accept prepay_6_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_6_pump_1;

    or

      accept charge_6_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_6.change; --eventb[{cust_6_pump_1_change}]
      null;

    or

      accept prepay_7_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_7_pump_1;

    or

      accept charge_7_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_7.change; --eventb[{cust_7_pump_1_change}]
      null;

    or

      accept prepay_8_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_8_pump_1;

    or

      accept charge_8_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_8.change; --eventb[{cust_8_pump_1_change}]
      null;

    or

      accept prepay_9_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_9_pump_1;

    or

      accept charge_9_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_9.change; --eventb[{cust_9_pump_1_change}]
      null;

    or

      accept prepay_1_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_1_pump_2;

    or

      accept charge_1_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_1.change; --eventb[{cust_1_pump_2_change}]
      null;

    or

      accept prepay_2_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_2_pump_2;

    or

      accept charge_2_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_2.change; --eventb[{cust_2_pump_2_change}]
      null;

    or

      accept prepay_3_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_3_pump_2;

    or

      accept charge_3_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_3.change; --eventb[{cust_3_pump_2_change}]
      null;

    or

      accept prepay_4_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_4_pump_2;

    or

      accept charge_4_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_4.change; --eventb[{cust_4_pump_2_change}]
      null;

    or

      accept prepay_5_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_5_pump_2;

    or

      accept charge_5_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_5.change; --eventb[{cust_5_pump_2_change}]
      null;

    or

      accept prepay_6_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_6_pump_2;

    or

      accept charge_6_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_6.change; --eventb[{cust_6_pump_2_change}]
      null;

    or

      accept prepay_7_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_7_pump_2;

    or

      accept charge_7_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_7.change; --eventb[{cust_7_pump_2_change}]
      null;

    or

      accept prepay_8_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_8_pump_2;

    or

      accept charge_8_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_8.change; --eventb[{cust_8_pump_2_change}]
      null;

    or

      accept prepay_9_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_9_pump_2;

    or

      accept charge_9_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_9.change; --eventb[{cust_9_pump_2_change}]
      null;
    end select;
  end loop;
end operator;


task body pump_1 is
  done : boolean;
begin
  loop
    exit when done;
    accept activate;
    accept start_pumping; --event[{pump_1_start}]
    null;

    select
      accept stop_pumping_1 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_1_pump_1;
      end stop_pumping_1;
    or
      accept stop_pumping_2 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_2_pump_1;
      end stop_pumping_2;
    or
      accept stop_pumping_3 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_3_pump_1;
      end stop_pumping_3;
    or
      accept stop_pumping_4 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_4_pump_1;
      end stop_pumping_4;
    or
      accept stop_pumping_5 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_5_pump_1;
      end stop_pumping_5;
    or
      accept stop_pumping_6 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_6_pump_1;
      end stop_pumping_6;
    or
      accept stop_pumping_7 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_7_pump_1;
      end stop_pumping_7;
    or
      accept stop_pumping_8 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_8_pump_1;
      end stop_pumping_8;
    or
      accept stop_pumping_9 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_9_pump_1;
      end stop_pumping_9;
    end select;
  end loop;
end pump_1;


task body pump_2 is
  done : boolean;
begin
  loop
    exit when done;
    accept activate;
    accept start_pumping; --event[{pump_2_start}]
    null;

    select
      accept stop_pumping_1 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_1_pump_2;
      end stop_pumping_1;
    or
      accept stop_pumping_2 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_2_pump_2;
      end stop_pumping_2;
    or
      accept stop_pumping_3 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_3_pump_2;
      end stop_pumping_3;
    or
      accept stop_pumping_4 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_4_pump_2;
      end stop_pumping_4;
    or
      accept stop_pumping_5 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_5_pump_2;
      end stop_pumping_5;
    or
      accept stop_pumping_6 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_6_pump_2;
      end stop_pumping_6;
    or
      accept stop_pumping_7 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_7_pump_2;
      end stop_pumping_7;
    or
      accept stop_pumping_8 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_8_pump_2;
      end stop_pumping_8;
    or
      accept stop_pumping_9 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_9_pump_2;
      end stop_pumping_9;
    end select;
  end loop;
end pump_2;


task body customer_1 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_1_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_1_start_pump_1},{cust_1_start_pump}]
        gas.pump_1.stop_pumping_1; --eventb[{cust_1_stop_pump_1},{cust_1_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_1_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_1_start_pump_2},{cust_1_start_pump}]
        gas.pump_2.stop_pumping_1; --eventb[{cust_1_stop_pump_2},{cust_1_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_1;


task body customer_2 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_2_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_2_start_pump_1},{cust_2_start_pump}]
        gas.pump_1.stop_pumping_2; --eventb[{cust_2_stop_pump_1},{cust_2_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_2_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_2_start_pump_2},{cust_2_start_pump}]
        gas.pump_2.stop_pumping_2; --eventb[{cust_2_stop_pump_2},{cust_2_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_2;


task body customer_3 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_3_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_3_start_pump_1},{cust_3_start_pump}]
        gas.pump_1.stop_pumping_3; --eventb[{cust_3_stop_pump_1},{cust_3_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_3_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_3_start_pump_2},{cust_3_start_pump}]
        gas.pump_2.stop_pumping_3; --eventb[{cust_3_stop_pump_2},{cust_3_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_3;


task body customer_4 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_4_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_4_start_pump_1},{cust_4_start_pump}]
        gas.pump_1.stop_pumping_4; --eventb[{cust_4_stop_pump_1},{cust_4_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_4_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_4_start_pump_2},{cust_4_start_pump}]
        gas.pump_2.stop_pumping_4; --eventb[{cust_4_stop_pump_2},{cust_4_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_4;


task body customer_5 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_5_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_5_start_pump_1},{cust_5_start_pump}]
        gas.pump_1.stop_pumping_5; --eventb[{cust_5_stop_pump_1},{cust_5_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_5_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_5_start_pump_2},{cust_5_start_pump}]
        gas.pump_2.stop_pumping_5; --eventb[{cust_5_stop_pump_2},{cust_5_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_5;


task body customer_6 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_6_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_6_start_pump_1},{cust_6_start_pump}]
        gas.pump_1.stop_pumping_6; --eventb[{cust_6_stop_pump_1},{cust_6_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_6_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_6_start_pump_2},{cust_6_start_pump}]
        gas.pump_2.stop_pumping_6; --eventb[{cust_6_stop_pump_2},{cust_6_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_6;


task body customer_7 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_7_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_7_start_pump_1},{cust_7_start_pump}]
        gas.pump_1.stop_pumping_7; --eventb[{cust_7_stop_pump_1},{cust_7_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_7_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_7_start_pump_2},{cust_7_start_pump}]
        gas.pump_2.stop_pumping_7; --eventb[{cust_7_stop_pump_2},{cust_7_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_7;


task body customer_8 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_8_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_8_start_pump_1},{cust_8_start_pump}]
        gas.pump_1.stop_pumping_8; --eventb[{cust_8_stop_pump_1},{cust_8_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_8_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_8_start_pump_2},{cust_8_start_pump}]
        gas.pump_2.stop_pumping_8; --eventb[{cust_8_stop_pump_2},{cust_8_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_8;


task body customer_9 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_9_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_9_start_pump_1},{cust_9_start_pump}]
        gas.pump_1.stop_pumping_9; --eventb[{cust_9_stop_pump_1},{cust_9_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_9_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_9_start_pump_2},{cust_9_start_pump}]
        gas.pump_2.stop_pumping_9; --eventb[{cust_9_stop_pump_2},{cust_9_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_9;


begin
  null;
end gas;

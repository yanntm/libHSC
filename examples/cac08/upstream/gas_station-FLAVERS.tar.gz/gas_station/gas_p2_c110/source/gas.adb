-- Generated on Mon Jul 24 22:24:15 2006
-- Pumps:     2
-- Customers: 110

procedure gas is

N : constant natural := 110;  -- number of customers
type cust_range is range 0 .. N;
type pump_range is range 1 .. 2;

task operator is
  entry prepay_1_pump_1;
  entry charge_1_pump_1;
  entry prepay_2_pump_1;
  entry charge_2_pump_1;
  entry prepay_3_pump_1;
  entry charge_3_pump_1;
  entry prepay_4_pump_1;
  entry charge_4_pump_1;
  entry prepay_5_pump_1;
  entry charge_5_pump_1;
  entry prepay_6_pump_1;
  entry charge_6_pump_1;
  entry prepay_7_pump_1;
  entry charge_7_pump_1;
  entry prepay_8_pump_1;
  entry charge_8_pump_1;
  entry prepay_9_pump_1;
  entry charge_9_pump_1;
  entry prepay_10_pump_1;
  entry charge_10_pump_1;
  entry prepay_11_pump_1;
  entry charge_11_pump_1;
  entry prepay_12_pump_1;
  entry charge_12_pump_1;
  entry prepay_13_pump_1;
  entry charge_13_pump_1;
  entry prepay_14_pump_1;
  entry charge_14_pump_1;
  entry prepay_15_pump_1;
  entry charge_15_pump_1;
  entry prepay_16_pump_1;
  entry charge_16_pump_1;
  entry prepay_17_pump_1;
  entry charge_17_pump_1;
  entry prepay_18_pump_1;
  entry charge_18_pump_1;
  entry prepay_19_pump_1;
  entry charge_19_pump_1;
  entry prepay_20_pump_1;
  entry charge_20_pump_1;
  entry prepay_21_pump_1;
  entry charge_21_pump_1;
  entry prepay_22_pump_1;
  entry charge_22_pump_1;
  entry prepay_23_pump_1;
  entry charge_23_pump_1;
  entry prepay_24_pump_1;
  entry charge_24_pump_1;
  entry prepay_25_pump_1;
  entry charge_25_pump_1;
  entry prepay_26_pump_1;
  entry charge_26_pump_1;
  entry prepay_27_pump_1;
  entry charge_27_pump_1;
  entry prepay_28_pump_1;
  entry charge_28_pump_1;
  entry prepay_29_pump_1;
  entry charge_29_pump_1;
  entry prepay_30_pump_1;
  entry charge_30_pump_1;
  entry prepay_31_pump_1;
  entry charge_31_pump_1;
  entry prepay_32_pump_1;
  entry charge_32_pump_1;
  entry prepay_33_pump_1;
  entry charge_33_pump_1;
  entry prepay_34_pump_1;
  entry charge_34_pump_1;
  entry prepay_35_pump_1;
  entry charge_35_pump_1;
  entry prepay_36_pump_1;
  entry charge_36_pump_1;
  entry prepay_37_pump_1;
  entry charge_37_pump_1;
  entry prepay_38_pump_1;
  entry charge_38_pump_1;
  entry prepay_39_pump_1;
  entry charge_39_pump_1;
  entry prepay_40_pump_1;
  entry charge_40_pump_1;
  entry prepay_41_pump_1;
  entry charge_41_pump_1;
  entry prepay_42_pump_1;
  entry charge_42_pump_1;
  entry prepay_43_pump_1;
  entry charge_43_pump_1;
  entry prepay_44_pump_1;
  entry charge_44_pump_1;
  entry prepay_45_pump_1;
  entry charge_45_pump_1;
  entry prepay_46_pump_1;
  entry charge_46_pump_1;
  entry prepay_47_pump_1;
  entry charge_47_pump_1;
  entry prepay_48_pump_1;
  entry charge_48_pump_1;
  entry prepay_49_pump_1;
  entry charge_49_pump_1;
  entry prepay_50_pump_1;
  entry charge_50_pump_1;
  entry prepay_51_pump_1;
  entry charge_51_pump_1;
  entry prepay_52_pump_1;
  entry charge_52_pump_1;
  entry prepay_53_pump_1;
  entry charge_53_pump_1;
  entry prepay_54_pump_1;
  entry charge_54_pump_1;
  entry prepay_55_pump_1;
  entry charge_55_pump_1;
  entry prepay_56_pump_1;
  entry charge_56_pump_1;
  entry prepay_57_pump_1;
  entry charge_57_pump_1;
  entry prepay_58_pump_1;
  entry charge_58_pump_1;
  entry prepay_59_pump_1;
  entry charge_59_pump_1;
  entry prepay_60_pump_1;
  entry charge_60_pump_1;
  entry prepay_61_pump_1;
  entry charge_61_pump_1;
  entry prepay_62_pump_1;
  entry charge_62_pump_1;
  entry prepay_63_pump_1;
  entry charge_63_pump_1;
  entry prepay_64_pump_1;
  entry charge_64_pump_1;
  entry prepay_65_pump_1;
  entry charge_65_pump_1;
  entry prepay_66_pump_1;
  entry charge_66_pump_1;
  entry prepay_67_pump_1;
  entry charge_67_pump_1;
  entry prepay_68_pump_1;
  entry charge_68_pump_1;
  entry prepay_69_pump_1;
  entry charge_69_pump_1;
  entry prepay_70_pump_1;
  entry charge_70_pump_1;
  entry prepay_71_pump_1;
  entry charge_71_pump_1;
  entry prepay_72_pump_1;
  entry charge_72_pump_1;
  entry prepay_73_pump_1;
  entry charge_73_pump_1;
  entry prepay_74_pump_1;
  entry charge_74_pump_1;
  entry prepay_75_pump_1;
  entry charge_75_pump_1;
  entry prepay_76_pump_1;
  entry charge_76_pump_1;
  entry prepay_77_pump_1;
  entry charge_77_pump_1;
  entry prepay_78_pump_1;
  entry charge_78_pump_1;
  entry prepay_79_pump_1;
  entry charge_79_pump_1;
  entry prepay_80_pump_1;
  entry charge_80_pump_1;
  entry prepay_81_pump_1;
  entry charge_81_pump_1;
  entry prepay_82_pump_1;
  entry charge_82_pump_1;
  entry prepay_83_pump_1;
  entry charge_83_pump_1;
  entry prepay_84_pump_1;
  entry charge_84_pump_1;
  entry prepay_85_pump_1;
  entry charge_85_pump_1;
  entry prepay_86_pump_1;
  entry charge_86_pump_1;
  entry prepay_87_pump_1;
  entry charge_87_pump_1;
  entry prepay_88_pump_1;
  entry charge_88_pump_1;
  entry prepay_89_pump_1;
  entry charge_89_pump_1;
  entry prepay_90_pump_1;
  entry charge_90_pump_1;
  entry prepay_91_pump_1;
  entry charge_91_pump_1;
  entry prepay_92_pump_1;
  entry charge_92_pump_1;
  entry prepay_93_pump_1;
  entry charge_93_pump_1;
  entry prepay_94_pump_1;
  entry charge_94_pump_1;
  entry prepay_95_pump_1;
  entry charge_95_pump_1;
  entry prepay_96_pump_1;
  entry charge_96_pump_1;
  entry prepay_97_pump_1;
  entry charge_97_pump_1;
  entry prepay_98_pump_1;
  entry charge_98_pump_1;
  entry prepay_99_pump_1;
  entry charge_99_pump_1;
  entry prepay_100_pump_1;
  entry charge_100_pump_1;
  entry prepay_101_pump_1;
  entry charge_101_pump_1;
  entry prepay_102_pump_1;
  entry charge_102_pump_1;
  entry prepay_103_pump_1;
  entry charge_103_pump_1;
  entry prepay_104_pump_1;
  entry charge_104_pump_1;
  entry prepay_105_pump_1;
  entry charge_105_pump_1;
  entry prepay_106_pump_1;
  entry charge_106_pump_1;
  entry prepay_107_pump_1;
  entry charge_107_pump_1;
  entry prepay_108_pump_1;
  entry charge_108_pump_1;
  entry prepay_109_pump_1;
  entry charge_109_pump_1;
  entry prepay_110_pump_1;
  entry charge_110_pump_1;
  entry prepay_1_pump_2;
  entry charge_1_pump_2;
  entry prepay_2_pump_2;
  entry charge_2_pump_2;
  entry prepay_3_pump_2;
  entry charge_3_pump_2;
  entry prepay_4_pump_2;
  entry charge_4_pump_2;
  entry prepay_5_pump_2;
  entry charge_5_pump_2;
  entry prepay_6_pump_2;
  entry charge_6_pump_2;
  entry prepay_7_pump_2;
  entry charge_7_pump_2;
  entry prepay_8_pump_2;
  entry charge_8_pump_2;
  entry prepay_9_pump_2;
  entry charge_9_pump_2;
  entry prepay_10_pump_2;
  entry charge_10_pump_2;
  entry prepay_11_pump_2;
  entry charge_11_pump_2;
  entry prepay_12_pump_2;
  entry charge_12_pump_2;
  entry prepay_13_pump_2;
  entry charge_13_pump_2;
  entry prepay_14_pump_2;
  entry charge_14_pump_2;
  entry prepay_15_pump_2;
  entry charge_15_pump_2;
  entry prepay_16_pump_2;
  entry charge_16_pump_2;
  entry prepay_17_pump_2;
  entry charge_17_pump_2;
  entry prepay_18_pump_2;
  entry charge_18_pump_2;
  entry prepay_19_pump_2;
  entry charge_19_pump_2;
  entry prepay_20_pump_2;
  entry charge_20_pump_2;
  entry prepay_21_pump_2;
  entry charge_21_pump_2;
  entry prepay_22_pump_2;
  entry charge_22_pump_2;
  entry prepay_23_pump_2;
  entry charge_23_pump_2;
  entry prepay_24_pump_2;
  entry charge_24_pump_2;
  entry prepay_25_pump_2;
  entry charge_25_pump_2;
  entry prepay_26_pump_2;
  entry charge_26_pump_2;
  entry prepay_27_pump_2;
  entry charge_27_pump_2;
  entry prepay_28_pump_2;
  entry charge_28_pump_2;
  entry prepay_29_pump_2;
  entry charge_29_pump_2;
  entry prepay_30_pump_2;
  entry charge_30_pump_2;
  entry prepay_31_pump_2;
  entry charge_31_pump_2;
  entry prepay_32_pump_2;
  entry charge_32_pump_2;
  entry prepay_33_pump_2;
  entry charge_33_pump_2;
  entry prepay_34_pump_2;
  entry charge_34_pump_2;
  entry prepay_35_pump_2;
  entry charge_35_pump_2;
  entry prepay_36_pump_2;
  entry charge_36_pump_2;
  entry prepay_37_pump_2;
  entry charge_37_pump_2;
  entry prepay_38_pump_2;
  entry charge_38_pump_2;
  entry prepay_39_pump_2;
  entry charge_39_pump_2;
  entry prepay_40_pump_2;
  entry charge_40_pump_2;
  entry prepay_41_pump_2;
  entry charge_41_pump_2;
  entry prepay_42_pump_2;
  entry charge_42_pump_2;
  entry prepay_43_pump_2;
  entry charge_43_pump_2;
  entry prepay_44_pump_2;
  entry charge_44_pump_2;
  entry prepay_45_pump_2;
  entry charge_45_pump_2;
  entry prepay_46_pump_2;
  entry charge_46_pump_2;
  entry prepay_47_pump_2;
  entry charge_47_pump_2;
  entry prepay_48_pump_2;
  entry charge_48_pump_2;
  entry prepay_49_pump_2;
  entry charge_49_pump_2;
  entry prepay_50_pump_2;
  entry charge_50_pump_2;
  entry prepay_51_pump_2;
  entry charge_51_pump_2;
  entry prepay_52_pump_2;
  entry charge_52_pump_2;
  entry prepay_53_pump_2;
  entry charge_53_pump_2;
  entry prepay_54_pump_2;
  entry charge_54_pump_2;
  entry prepay_55_pump_2;
  entry charge_55_pump_2;
  entry prepay_56_pump_2;
  entry charge_56_pump_2;
  entry prepay_57_pump_2;
  entry charge_57_pump_2;
  entry prepay_58_pump_2;
  entry charge_58_pump_2;
  entry prepay_59_pump_2;
  entry charge_59_pump_2;
  entry prepay_60_pump_2;
  entry charge_60_pump_2;
  entry prepay_61_pump_2;
  entry charge_61_pump_2;
  entry prepay_62_pump_2;
  entry charge_62_pump_2;
  entry prepay_63_pump_2;
  entry charge_63_pump_2;
  entry prepay_64_pump_2;
  entry charge_64_pump_2;
  entry prepay_65_pump_2;
  entry charge_65_pump_2;
  entry prepay_66_pump_2;
  entry charge_66_pump_2;
  entry prepay_67_pump_2;
  entry charge_67_pump_2;
  entry prepay_68_pump_2;
  entry charge_68_pump_2;
  entry prepay_69_pump_2;
  entry charge_69_pump_2;
  entry prepay_70_pump_2;
  entry charge_70_pump_2;
  entry prepay_71_pump_2;
  entry charge_71_pump_2;
  entry prepay_72_pump_2;
  entry charge_72_pump_2;
  entry prepay_73_pump_2;
  entry charge_73_pump_2;
  entry prepay_74_pump_2;
  entry charge_74_pump_2;
  entry prepay_75_pump_2;
  entry charge_75_pump_2;
  entry prepay_76_pump_2;
  entry charge_76_pump_2;
  entry prepay_77_pump_2;
  entry charge_77_pump_2;
  entry prepay_78_pump_2;
  entry charge_78_pump_2;
  entry prepay_79_pump_2;
  entry charge_79_pump_2;
  entry prepay_80_pump_2;
  entry charge_80_pump_2;
  entry prepay_81_pump_2;
  entry charge_81_pump_2;
  entry prepay_82_pump_2;
  entry charge_82_pump_2;
  entry prepay_83_pump_2;
  entry charge_83_pump_2;
  entry prepay_84_pump_2;
  entry charge_84_pump_2;
  entry prepay_85_pump_2;
  entry charge_85_pump_2;
  entry prepay_86_pump_2;
  entry charge_86_pump_2;
  entry prepay_87_pump_2;
  entry charge_87_pump_2;
  entry prepay_88_pump_2;
  entry charge_88_pump_2;
  entry prepay_89_pump_2;
  entry charge_89_pump_2;
  entry prepay_90_pump_2;
  entry charge_90_pump_2;
  entry prepay_91_pump_2;
  entry charge_91_pump_2;
  entry prepay_92_pump_2;
  entry charge_92_pump_2;
  entry prepay_93_pump_2;
  entry charge_93_pump_2;
  entry prepay_94_pump_2;
  entry charge_94_pump_2;
  entry prepay_95_pump_2;
  entry charge_95_pump_2;
  entry prepay_96_pump_2;
  entry charge_96_pump_2;
  entry prepay_97_pump_2;
  entry charge_97_pump_2;
  entry prepay_98_pump_2;
  entry charge_98_pump_2;
  entry prepay_99_pump_2;
  entry charge_99_pump_2;
  entry prepay_100_pump_2;
  entry charge_100_pump_2;
  entry prepay_101_pump_2;
  entry charge_101_pump_2;
  entry prepay_102_pump_2;
  entry charge_102_pump_2;
  entry prepay_103_pump_2;
  entry charge_103_pump_2;
  entry prepay_104_pump_2;
  entry charge_104_pump_2;
  entry prepay_105_pump_2;
  entry charge_105_pump_2;
  entry prepay_106_pump_2;
  entry charge_106_pump_2;
  entry prepay_107_pump_2;
  entry charge_107_pump_2;
  entry prepay_108_pump_2;
  entry charge_108_pump_2;
  entry prepay_109_pump_2;
  entry charge_109_pump_2;
  entry prepay_110_pump_2;
  entry charge_110_pump_2;
end operator;


task pump_1 is
  entry activate;
  entry start_pumping;
  entry stop_pumping_1;
  entry stop_pumping_2;
  entry stop_pumping_3;
  entry stop_pumping_4;
  entry stop_pumping_5;
  entry stop_pumping_6;
  entry stop_pumping_7;
  entry stop_pumping_8;
  entry stop_pumping_9;
  entry stop_pumping_10;
  entry stop_pumping_11;
  entry stop_pumping_12;
  entry stop_pumping_13;
  entry stop_pumping_14;
  entry stop_pumping_15;
  entry stop_pumping_16;
  entry stop_pumping_17;
  entry stop_pumping_18;
  entry stop_pumping_19;
  entry stop_pumping_20;
  entry stop_pumping_21;
  entry stop_pumping_22;
  entry stop_pumping_23;
  entry stop_pumping_24;
  entry stop_pumping_25;
  entry stop_pumping_26;
  entry stop_pumping_27;
  entry stop_pumping_28;
  entry stop_pumping_29;
  entry stop_pumping_30;
  entry stop_pumping_31;
  entry stop_pumping_32;
  entry stop_pumping_33;
  entry stop_pumping_34;
  entry stop_pumping_35;
  entry stop_pumping_36;
  entry stop_pumping_37;
  entry stop_pumping_38;
  entry stop_pumping_39;
  entry stop_pumping_40;
  entry stop_pumping_41;
  entry stop_pumping_42;
  entry stop_pumping_43;
  entry stop_pumping_44;
  entry stop_pumping_45;
  entry stop_pumping_46;
  entry stop_pumping_47;
  entry stop_pumping_48;
  entry stop_pumping_49;
  entry stop_pumping_50;
  entry stop_pumping_51;
  entry stop_pumping_52;
  entry stop_pumping_53;
  entry stop_pumping_54;
  entry stop_pumping_55;
  entry stop_pumping_56;
  entry stop_pumping_57;
  entry stop_pumping_58;
  entry stop_pumping_59;
  entry stop_pumping_60;
  entry stop_pumping_61;
  entry stop_pumping_62;
  entry stop_pumping_63;
  entry stop_pumping_64;
  entry stop_pumping_65;
  entry stop_pumping_66;
  entry stop_pumping_67;
  entry stop_pumping_68;
  entry stop_pumping_69;
  entry stop_pumping_70;
  entry stop_pumping_71;
  entry stop_pumping_72;
  entry stop_pumping_73;
  entry stop_pumping_74;
  entry stop_pumping_75;
  entry stop_pumping_76;
  entry stop_pumping_77;
  entry stop_pumping_78;
  entry stop_pumping_79;
  entry stop_pumping_80;
  entry stop_pumping_81;
  entry stop_pumping_82;
  entry stop_pumping_83;
  entry stop_pumping_84;
  entry stop_pumping_85;
  entry stop_pumping_86;
  entry stop_pumping_87;
  entry stop_pumping_88;
  entry stop_pumping_89;
  entry stop_pumping_90;
  entry stop_pumping_91;
  entry stop_pumping_92;
  entry stop_pumping_93;
  entry stop_pumping_94;
  entry stop_pumping_95;
  entry stop_pumping_96;
  entry stop_pumping_97;
  entry stop_pumping_98;
  entry stop_pumping_99;
  entry stop_pumping_100;
  entry stop_pumping_101;
  entry stop_pumping_102;
  entry stop_pumping_103;
  entry stop_pumping_104;
  entry stop_pumping_105;
  entry stop_pumping_106;
  entry stop_pumping_107;
  entry stop_pumping_108;
  entry stop_pumping_109;
  entry stop_pumping_110;
end pump_1;


task pump_2 is
  entry activate;
  entry start_pumping;
  entry stop_pumping_1;
  entry stop_pumping_2;
  entry stop_pumping_3;
  entry stop_pumping_4;
  entry stop_pumping_5;
  entry stop_pumping_6;
  entry stop_pumping_7;
  entry stop_pumping_8;
  entry stop_pumping_9;
  entry stop_pumping_10;
  entry stop_pumping_11;
  entry stop_pumping_12;
  entry stop_pumping_13;
  entry stop_pumping_14;
  entry stop_pumping_15;
  entry stop_pumping_16;
  entry stop_pumping_17;
  entry stop_pumping_18;
  entry stop_pumping_19;
  entry stop_pumping_20;
  entry stop_pumping_21;
  entry stop_pumping_22;
  entry stop_pumping_23;
  entry stop_pumping_24;
  entry stop_pumping_25;
  entry stop_pumping_26;
  entry stop_pumping_27;
  entry stop_pumping_28;
  entry stop_pumping_29;
  entry stop_pumping_30;
  entry stop_pumping_31;
  entry stop_pumping_32;
  entry stop_pumping_33;
  entry stop_pumping_34;
  entry stop_pumping_35;
  entry stop_pumping_36;
  entry stop_pumping_37;
  entry stop_pumping_38;
  entry stop_pumping_39;
  entry stop_pumping_40;
  entry stop_pumping_41;
  entry stop_pumping_42;
  entry stop_pumping_43;
  entry stop_pumping_44;
  entry stop_pumping_45;
  entry stop_pumping_46;
  entry stop_pumping_47;
  entry stop_pumping_48;
  entry stop_pumping_49;
  entry stop_pumping_50;
  entry stop_pumping_51;
  entry stop_pumping_52;
  entry stop_pumping_53;
  entry stop_pumping_54;
  entry stop_pumping_55;
  entry stop_pumping_56;
  entry stop_pumping_57;
  entry stop_pumping_58;
  entry stop_pumping_59;
  entry stop_pumping_60;
  entry stop_pumping_61;
  entry stop_pumping_62;
  entry stop_pumping_63;
  entry stop_pumping_64;
  entry stop_pumping_65;
  entry stop_pumping_66;
  entry stop_pumping_67;
  entry stop_pumping_68;
  entry stop_pumping_69;
  entry stop_pumping_70;
  entry stop_pumping_71;
  entry stop_pumping_72;
  entry stop_pumping_73;
  entry stop_pumping_74;
  entry stop_pumping_75;
  entry stop_pumping_76;
  entry stop_pumping_77;
  entry stop_pumping_78;
  entry stop_pumping_79;
  entry stop_pumping_80;
  entry stop_pumping_81;
  entry stop_pumping_82;
  entry stop_pumping_83;
  entry stop_pumping_84;
  entry stop_pumping_85;
  entry stop_pumping_86;
  entry stop_pumping_87;
  entry stop_pumping_88;
  entry stop_pumping_89;
  entry stop_pumping_90;
  entry stop_pumping_91;
  entry stop_pumping_92;
  entry stop_pumping_93;
  entry stop_pumping_94;
  entry stop_pumping_95;
  entry stop_pumping_96;
  entry stop_pumping_97;
  entry stop_pumping_98;
  entry stop_pumping_99;
  entry stop_pumping_100;
  entry stop_pumping_101;
  entry stop_pumping_102;
  entry stop_pumping_103;
  entry stop_pumping_104;
  entry stop_pumping_105;
  entry stop_pumping_106;
  entry stop_pumping_107;
  entry stop_pumping_108;
  entry stop_pumping_109;
  entry stop_pumping_110;
end pump_2;


task customer_1 is
  entry change;
end customer_1;


task customer_2 is
  entry change;
end customer_2;


task customer_3 is
  entry change;
end customer_3;


task customer_4 is
  entry change;
end customer_4;


task customer_5 is
  entry change;
end customer_5;


task customer_6 is
  entry change;
end customer_6;


task customer_7 is
  entry change;
end customer_7;


task customer_8 is
  entry change;
end customer_8;


task customer_9 is
  entry change;
end customer_9;


task customer_10 is
  entry change;
end customer_10;


task customer_11 is
  entry change;
end customer_11;


task customer_12 is
  entry change;
end customer_12;


task customer_13 is
  entry change;
end customer_13;


task customer_14 is
  entry change;
end customer_14;


task customer_15 is
  entry change;
end customer_15;


task customer_16 is
  entry change;
end customer_16;


task customer_17 is
  entry change;
end customer_17;


task customer_18 is
  entry change;
end customer_18;


task customer_19 is
  entry change;
end customer_19;


task customer_20 is
  entry change;
end customer_20;


task customer_21 is
  entry change;
end customer_21;


task customer_22 is
  entry change;
end customer_22;


task customer_23 is
  entry change;
end customer_23;


task customer_24 is
  entry change;
end customer_24;


task customer_25 is
  entry change;
end customer_25;


task customer_26 is
  entry change;
end customer_26;


task customer_27 is
  entry change;
end customer_27;


task customer_28 is
  entry change;
end customer_28;


task customer_29 is
  entry change;
end customer_29;


task customer_30 is
  entry change;
end customer_30;


task customer_31 is
  entry change;
end customer_31;


task customer_32 is
  entry change;
end customer_32;


task customer_33 is
  entry change;
end customer_33;


task customer_34 is
  entry change;
end customer_34;


task customer_35 is
  entry change;
end customer_35;


task customer_36 is
  entry change;
end customer_36;


task customer_37 is
  entry change;
end customer_37;


task customer_38 is
  entry change;
end customer_38;


task customer_39 is
  entry change;
end customer_39;


task customer_40 is
  entry change;
end customer_40;


task customer_41 is
  entry change;
end customer_41;


task customer_42 is
  entry change;
end customer_42;


task customer_43 is
  entry change;
end customer_43;


task customer_44 is
  entry change;
end customer_44;


task customer_45 is
  entry change;
end customer_45;


task customer_46 is
  entry change;
end customer_46;


task customer_47 is
  entry change;
end customer_47;


task customer_48 is
  entry change;
end customer_48;


task customer_49 is
  entry change;
end customer_49;


task customer_50 is
  entry change;
end customer_50;


task customer_51 is
  entry change;
end customer_51;


task customer_52 is
  entry change;
end customer_52;


task customer_53 is
  entry change;
end customer_53;


task customer_54 is
  entry change;
end customer_54;


task customer_55 is
  entry change;
end customer_55;


task customer_56 is
  entry change;
end customer_56;


task customer_57 is
  entry change;
end customer_57;


task customer_58 is
  entry change;
end customer_58;


task customer_59 is
  entry change;
end customer_59;


task customer_60 is
  entry change;
end customer_60;


task customer_61 is
  entry change;
end customer_61;


task customer_62 is
  entry change;
end customer_62;


task customer_63 is
  entry change;
end customer_63;


task customer_64 is
  entry change;
end customer_64;


task customer_65 is
  entry change;
end customer_65;


task customer_66 is
  entry change;
end customer_66;


task customer_67 is
  entry change;
end customer_67;


task customer_68 is
  entry change;
end customer_68;


task customer_69 is
  entry change;
end customer_69;


task customer_70 is
  entry change;
end customer_70;


task customer_71 is
  entry change;
end customer_71;


task customer_72 is
  entry change;
end customer_72;


task customer_73 is
  entry change;
end customer_73;


task customer_74 is
  entry change;
end customer_74;


task customer_75 is
  entry change;
end customer_75;


task customer_76 is
  entry change;
end customer_76;


task customer_77 is
  entry change;
end customer_77;


task customer_78 is
  entry change;
end customer_78;


task customer_79 is
  entry change;
end customer_79;


task customer_80 is
  entry change;
end customer_80;


task customer_81 is
  entry change;
end customer_81;


task customer_82 is
  entry change;
end customer_82;


task customer_83 is
  entry change;
end customer_83;


task customer_84 is
  entry change;
end customer_84;


task customer_85 is
  entry change;
end customer_85;


task customer_86 is
  entry change;
end customer_86;


task customer_87 is
  entry change;
end customer_87;


task customer_88 is
  entry change;
end customer_88;


task customer_89 is
  entry change;
end customer_89;


task customer_90 is
  entry change;
end customer_90;


task customer_91 is
  entry change;
end customer_91;


task customer_92 is
  entry change;
end customer_92;


task customer_93 is
  entry change;
end customer_93;


task customer_94 is
  entry change;
end customer_94;


task customer_95 is
  entry change;
end customer_95;


task customer_96 is
  entry change;
end customer_96;


task customer_97 is
  entry change;
end customer_97;


task customer_98 is
  entry change;
end customer_98;


task customer_99 is
  entry change;
end customer_99;


task customer_100 is
  entry change;
end customer_100;


task customer_101 is
  entry change;
end customer_101;


task customer_102 is
  entry change;
end customer_102;


task customer_103 is
  entry change;
end customer_103;


task customer_104 is
  entry change;
end customer_104;


task customer_105 is
  entry change;
end customer_105;


task customer_106 is
  entry change;
end customer_106;


task customer_107 is
  entry change;
end customer_107;


task customer_108 is
  entry change;
end customer_108;


task customer_109 is
  entry change;
end customer_109;


task customer_110 is
  entry change;
end customer_110;


task body operator is
  Pump_1_ActiveCustomers : cust_range;
  Pump_2_ActiveCustomers : cust_range;
  done : boolean;
begin
  Pump_1_ActiveCustomers := 0; --event[{p1ac=0}]
  Pump_2_ActiveCustomers := 0; --event[{p2ac=0}]
  null;
  loop
  -- if there are no active customers, we can exit
    if ((Pump_1_ActiveCustomers = 0) and
        (Pump_2_ActiveCustomers = 0)) then
      null; --eventb[{p1acis=0}]
      null; --eventb[{p2acis=0}]
      null;
      exit when done;
    end if;

    select
      accept prepay_1_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_1_pump_1;

    or

      accept charge_1_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_1.change; --eventb[{cust_1_pump_1_change}]
      null;

    or

      accept prepay_2_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_2_pump_1;

    or

      accept charge_2_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_2.change; --eventb[{cust_2_pump_1_change}]
      null;

    or

      accept prepay_3_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_3_pump_1;

    or

      accept charge_3_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_3.change; --eventb[{cust_3_pump_1_change}]
      null;

    or

      accept prepay_4_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_4_pump_1;

    or

      accept charge_4_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_4.change; --eventb[{cust_4_pump_1_change}]
      null;

    or

      accept prepay_5_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_5_pump_1;

    or

      accept charge_5_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_5.change; --eventb[{cust_5_pump_1_change}]
      null;

    or

      accept prepay_6_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_6_pump_1;

    or

      accept charge_6_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_6.change; --eventb[{cust_6_pump_1_change}]
      null;

    or

      accept prepay_7_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_7_pump_1;

    or

      accept charge_7_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_7.change; --eventb[{cust_7_pump_1_change}]
      null;

    or

      accept prepay_8_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_8_pump_1;

    or

      accept charge_8_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_8.change; --eventb[{cust_8_pump_1_change}]
      null;

    or

      accept prepay_9_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_9_pump_1;

    or

      accept charge_9_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_9.change; --eventb[{cust_9_pump_1_change}]
      null;

    or

      accept prepay_10_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_10_pump_1;

    or

      accept charge_10_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_10.change; --eventb[{cust_10_pump_1_change}]
      null;

    or

      accept prepay_11_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_11_pump_1;

    or

      accept charge_11_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_11.change; --eventb[{cust_11_pump_1_change}]
      null;

    or

      accept prepay_12_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_12_pump_1;

    or

      accept charge_12_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_12.change; --eventb[{cust_12_pump_1_change}]
      null;

    or

      accept prepay_13_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_13_pump_1;

    or

      accept charge_13_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_13.change; --eventb[{cust_13_pump_1_change}]
      null;

    or

      accept prepay_14_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_14_pump_1;

    or

      accept charge_14_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_14.change; --eventb[{cust_14_pump_1_change}]
      null;

    or

      accept prepay_15_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_15_pump_1;

    or

      accept charge_15_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_15.change; --eventb[{cust_15_pump_1_change}]
      null;

    or

      accept prepay_16_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_16_pump_1;

    or

      accept charge_16_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_16.change; --eventb[{cust_16_pump_1_change}]
      null;

    or

      accept prepay_17_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_17_pump_1;

    or

      accept charge_17_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_17.change; --eventb[{cust_17_pump_1_change}]
      null;

    or

      accept prepay_18_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_18_pump_1;

    or

      accept charge_18_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_18.change; --eventb[{cust_18_pump_1_change}]
      null;

    or

      accept prepay_19_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_19_pump_1;

    or

      accept charge_19_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_19.change; --eventb[{cust_19_pump_1_change}]
      null;

    or

      accept prepay_20_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_20_pump_1;

    or

      accept charge_20_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_20.change; --eventb[{cust_20_pump_1_change}]
      null;

    or

      accept prepay_21_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_21_pump_1;

    or

      accept charge_21_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_21.change; --eventb[{cust_21_pump_1_change}]
      null;

    or

      accept prepay_22_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_22_pump_1;

    or

      accept charge_22_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_22.change; --eventb[{cust_22_pump_1_change}]
      null;

    or

      accept prepay_23_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_23_pump_1;

    or

      accept charge_23_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_23.change; --eventb[{cust_23_pump_1_change}]
      null;

    or

      accept prepay_24_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_24_pump_1;

    or

      accept charge_24_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_24.change; --eventb[{cust_24_pump_1_change}]
      null;

    or

      accept prepay_25_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_25_pump_1;

    or

      accept charge_25_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_25.change; --eventb[{cust_25_pump_1_change}]
      null;

    or

      accept prepay_26_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_26_pump_1;

    or

      accept charge_26_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_26.change; --eventb[{cust_26_pump_1_change}]
      null;

    or

      accept prepay_27_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_27_pump_1;

    or

      accept charge_27_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_27.change; --eventb[{cust_27_pump_1_change}]
      null;

    or

      accept prepay_28_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_28_pump_1;

    or

      accept charge_28_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_28.change; --eventb[{cust_28_pump_1_change}]
      null;

    or

      accept prepay_29_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_29_pump_1;

    or

      accept charge_29_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_29.change; --eventb[{cust_29_pump_1_change}]
      null;

    or

      accept prepay_30_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_30_pump_1;

    or

      accept charge_30_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_30.change; --eventb[{cust_30_pump_1_change}]
      null;

    or

      accept prepay_31_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_31_pump_1;

    or

      accept charge_31_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_31.change; --eventb[{cust_31_pump_1_change}]
      null;

    or

      accept prepay_32_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_32_pump_1;

    or

      accept charge_32_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_32.change; --eventb[{cust_32_pump_1_change}]
      null;

    or

      accept prepay_33_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_33_pump_1;

    or

      accept charge_33_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_33.change; --eventb[{cust_33_pump_1_change}]
      null;

    or

      accept prepay_34_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_34_pump_1;

    or

      accept charge_34_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_34.change; --eventb[{cust_34_pump_1_change}]
      null;

    or

      accept prepay_35_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_35_pump_1;

    or

      accept charge_35_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_35.change; --eventb[{cust_35_pump_1_change}]
      null;

    or

      accept prepay_36_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_36_pump_1;

    or

      accept charge_36_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_36.change; --eventb[{cust_36_pump_1_change}]
      null;

    or

      accept prepay_37_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_37_pump_1;

    or

      accept charge_37_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_37.change; --eventb[{cust_37_pump_1_change}]
      null;

    or

      accept prepay_38_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_38_pump_1;

    or

      accept charge_38_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_38.change; --eventb[{cust_38_pump_1_change}]
      null;

    or

      accept prepay_39_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_39_pump_1;

    or

      accept charge_39_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_39.change; --eventb[{cust_39_pump_1_change}]
      null;

    or

      accept prepay_40_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_40_pump_1;

    or

      accept charge_40_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_40.change; --eventb[{cust_40_pump_1_change}]
      null;

    or

      accept prepay_41_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_41_pump_1;

    or

      accept charge_41_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_41.change; --eventb[{cust_41_pump_1_change}]
      null;

    or

      accept prepay_42_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_42_pump_1;

    or

      accept charge_42_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_42.change; --eventb[{cust_42_pump_1_change}]
      null;

    or

      accept prepay_43_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_43_pump_1;

    or

      accept charge_43_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_43.change; --eventb[{cust_43_pump_1_change}]
      null;

    or

      accept prepay_44_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_44_pump_1;

    or

      accept charge_44_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_44.change; --eventb[{cust_44_pump_1_change}]
      null;

    or

      accept prepay_45_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_45_pump_1;

    or

      accept charge_45_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_45.change; --eventb[{cust_45_pump_1_change}]
      null;

    or

      accept prepay_46_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_46_pump_1;

    or

      accept charge_46_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_46.change; --eventb[{cust_46_pump_1_change}]
      null;

    or

      accept prepay_47_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_47_pump_1;

    or

      accept charge_47_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_47.change; --eventb[{cust_47_pump_1_change}]
      null;

    or

      accept prepay_48_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_48_pump_1;

    or

      accept charge_48_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_48.change; --eventb[{cust_48_pump_1_change}]
      null;

    or

      accept prepay_49_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_49_pump_1;

    or

      accept charge_49_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_49.change; --eventb[{cust_49_pump_1_change}]
      null;

    or

      accept prepay_50_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_50_pump_1;

    or

      accept charge_50_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_50.change; --eventb[{cust_50_pump_1_change}]
      null;

    or

      accept prepay_51_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_51_pump_1;

    or

      accept charge_51_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_51.change; --eventb[{cust_51_pump_1_change}]
      null;

    or

      accept prepay_52_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_52_pump_1;

    or

      accept charge_52_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_52.change; --eventb[{cust_52_pump_1_change}]
      null;

    or

      accept prepay_53_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_53_pump_1;

    or

      accept charge_53_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_53.change; --eventb[{cust_53_pump_1_change}]
      null;

    or

      accept prepay_54_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_54_pump_1;

    or

      accept charge_54_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_54.change; --eventb[{cust_54_pump_1_change}]
      null;

    or

      accept prepay_55_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_55_pump_1;

    or

      accept charge_55_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_55.change; --eventb[{cust_55_pump_1_change}]
      null;

    or

      accept prepay_56_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_56_pump_1;

    or

      accept charge_56_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_56.change; --eventb[{cust_56_pump_1_change}]
      null;

    or

      accept prepay_57_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_57_pump_1;

    or

      accept charge_57_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_57.change; --eventb[{cust_57_pump_1_change}]
      null;

    or

      accept prepay_58_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_58_pump_1;

    or

      accept charge_58_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_58.change; --eventb[{cust_58_pump_1_change}]
      null;

    or

      accept prepay_59_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_59_pump_1;

    or

      accept charge_59_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_59.change; --eventb[{cust_59_pump_1_change}]
      null;

    or

      accept prepay_60_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_60_pump_1;

    or

      accept charge_60_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_60.change; --eventb[{cust_60_pump_1_change}]
      null;

    or

      accept prepay_61_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_61_pump_1;

    or

      accept charge_61_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_61.change; --eventb[{cust_61_pump_1_change}]
      null;

    or

      accept prepay_62_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_62_pump_1;

    or

      accept charge_62_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_62.change; --eventb[{cust_62_pump_1_change}]
      null;

    or

      accept prepay_63_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_63_pump_1;

    or

      accept charge_63_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_63.change; --eventb[{cust_63_pump_1_change}]
      null;

    or

      accept prepay_64_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_64_pump_1;

    or

      accept charge_64_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_64.change; --eventb[{cust_64_pump_1_change}]
      null;

    or

      accept prepay_65_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_65_pump_1;

    or

      accept charge_65_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_65.change; --eventb[{cust_65_pump_1_change}]
      null;

    or

      accept prepay_66_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_66_pump_1;

    or

      accept charge_66_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_66.change; --eventb[{cust_66_pump_1_change}]
      null;

    or

      accept prepay_67_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_67_pump_1;

    or

      accept charge_67_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_67.change; --eventb[{cust_67_pump_1_change}]
      null;

    or

      accept prepay_68_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_68_pump_1;

    or

      accept charge_68_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_68.change; --eventb[{cust_68_pump_1_change}]
      null;

    or

      accept prepay_69_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_69_pump_1;

    or

      accept charge_69_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_69.change; --eventb[{cust_69_pump_1_change}]
      null;

    or

      accept prepay_70_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_70_pump_1;

    or

      accept charge_70_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_70.change; --eventb[{cust_70_pump_1_change}]
      null;

    or

      accept prepay_71_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_71_pump_1;

    or

      accept charge_71_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_71.change; --eventb[{cust_71_pump_1_change}]
      null;

    or

      accept prepay_72_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_72_pump_1;

    or

      accept charge_72_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_72.change; --eventb[{cust_72_pump_1_change}]
      null;

    or

      accept prepay_73_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_73_pump_1;

    or

      accept charge_73_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_73.change; --eventb[{cust_73_pump_1_change}]
      null;

    or

      accept prepay_74_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_74_pump_1;

    or

      accept charge_74_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_74.change; --eventb[{cust_74_pump_1_change}]
      null;

    or

      accept prepay_75_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_75_pump_1;

    or

      accept charge_75_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_75.change; --eventb[{cust_75_pump_1_change}]
      null;

    or

      accept prepay_76_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_76_pump_1;

    or

      accept charge_76_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_76.change; --eventb[{cust_76_pump_1_change}]
      null;

    or

      accept prepay_77_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_77_pump_1;

    or

      accept charge_77_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_77.change; --eventb[{cust_77_pump_1_change}]
      null;

    or

      accept prepay_78_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_78_pump_1;

    or

      accept charge_78_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_78.change; --eventb[{cust_78_pump_1_change}]
      null;

    or

      accept prepay_79_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_79_pump_1;

    or

      accept charge_79_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_79.change; --eventb[{cust_79_pump_1_change}]
      null;

    or

      accept prepay_80_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_80_pump_1;

    or

      accept charge_80_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_80.change; --eventb[{cust_80_pump_1_change}]
      null;

    or

      accept prepay_81_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_81_pump_1;

    or

      accept charge_81_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_81.change; --eventb[{cust_81_pump_1_change}]
      null;

    or

      accept prepay_82_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_82_pump_1;

    or

      accept charge_82_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_82.change; --eventb[{cust_82_pump_1_change}]
      null;

    or

      accept prepay_83_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_83_pump_1;

    or

      accept charge_83_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_83.change; --eventb[{cust_83_pump_1_change}]
      null;

    or

      accept prepay_84_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_84_pump_1;

    or

      accept charge_84_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_84.change; --eventb[{cust_84_pump_1_change}]
      null;

    or

      accept prepay_85_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_85_pump_1;

    or

      accept charge_85_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_85.change; --eventb[{cust_85_pump_1_change}]
      null;

    or

      accept prepay_86_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_86_pump_1;

    or

      accept charge_86_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_86.change; --eventb[{cust_86_pump_1_change}]
      null;

    or

      accept prepay_87_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_87_pump_1;

    or

      accept charge_87_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_87.change; --eventb[{cust_87_pump_1_change}]
      null;

    or

      accept prepay_88_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_88_pump_1;

    or

      accept charge_88_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_88.change; --eventb[{cust_88_pump_1_change}]
      null;

    or

      accept prepay_89_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_89_pump_1;

    or

      accept charge_89_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_89.change; --eventb[{cust_89_pump_1_change}]
      null;

    or

      accept prepay_90_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_90_pump_1;

    or

      accept charge_90_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_90.change; --eventb[{cust_90_pump_1_change}]
      null;

    or

      accept prepay_91_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_91_pump_1;

    or

      accept charge_91_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_91.change; --eventb[{cust_91_pump_1_change}]
      null;

    or

      accept prepay_92_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_92_pump_1;

    or

      accept charge_92_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_92.change; --eventb[{cust_92_pump_1_change}]
      null;

    or

      accept prepay_93_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_93_pump_1;

    or

      accept charge_93_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_93.change; --eventb[{cust_93_pump_1_change}]
      null;

    or

      accept prepay_94_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_94_pump_1;

    or

      accept charge_94_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_94.change; --eventb[{cust_94_pump_1_change}]
      null;

    or

      accept prepay_95_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_95_pump_1;

    or

      accept charge_95_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_95.change; --eventb[{cust_95_pump_1_change}]
      null;

    or

      accept prepay_96_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_96_pump_1;

    or

      accept charge_96_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_96.change; --eventb[{cust_96_pump_1_change}]
      null;

    or

      accept prepay_97_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_97_pump_1;

    or

      accept charge_97_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_97.change; --eventb[{cust_97_pump_1_change}]
      null;

    or

      accept prepay_98_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_98_pump_1;

    or

      accept charge_98_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_98.change; --eventb[{cust_98_pump_1_change}]
      null;

    or

      accept prepay_99_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_99_pump_1;

    or

      accept charge_99_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_99.change; --eventb[{cust_99_pump_1_change}]
      null;

    or

      accept prepay_100_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_100_pump_1;

    or

      accept charge_100_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_100.change; --eventb[{cust_100_pump_1_change}]
      null;

    or

      accept prepay_101_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_101_pump_1;

    or

      accept charge_101_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_101.change; --eventb[{cust_101_pump_1_change}]
      null;

    or

      accept prepay_102_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_102_pump_1;

    or

      accept charge_102_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_102.change; --eventb[{cust_102_pump_1_change}]
      null;

    or

      accept prepay_103_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_103_pump_1;

    or

      accept charge_103_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_103.change; --eventb[{cust_103_pump_1_change}]
      null;

    or

      accept prepay_104_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_104_pump_1;

    or

      accept charge_104_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_104.change; --eventb[{cust_104_pump_1_change}]
      null;

    or

      accept prepay_105_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_105_pump_1;

    or

      accept charge_105_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_105.change; --eventb[{cust_105_pump_1_change}]
      null;

    or

      accept prepay_106_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_106_pump_1;

    or

      accept charge_106_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_106.change; --eventb[{cust_106_pump_1_change}]
      null;

    or

      accept prepay_107_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_107_pump_1;

    or

      accept charge_107_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_107.change; --eventb[{cust_107_pump_1_change}]
      null;

    or

      accept prepay_108_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_108_pump_1;

    or

      accept charge_108_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_108.change; --eventb[{cust_108_pump_1_change}]
      null;

    or

      accept prepay_109_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_109_pump_1;

    or

      accept charge_109_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_109.change; --eventb[{cust_109_pump_1_change}]
      null;

    or

      accept prepay_110_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_110_pump_1;

    or

      accept charge_110_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_110.change; --eventb[{cust_110_pump_1_change}]
      null;

    or

      accept prepay_1_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_1_pump_2;

    or

      accept charge_1_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_1.change; --eventb[{cust_1_pump_2_change}]
      null;

    or

      accept prepay_2_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_2_pump_2;

    or

      accept charge_2_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_2.change; --eventb[{cust_2_pump_2_change}]
      null;

    or

      accept prepay_3_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_3_pump_2;

    or

      accept charge_3_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_3.change; --eventb[{cust_3_pump_2_change}]
      null;

    or

      accept prepay_4_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_4_pump_2;

    or

      accept charge_4_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_4.change; --eventb[{cust_4_pump_2_change}]
      null;

    or

      accept prepay_5_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_5_pump_2;

    or

      accept charge_5_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_5.change; --eventb[{cust_5_pump_2_change}]
      null;

    or

      accept prepay_6_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_6_pump_2;

    or

      accept charge_6_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_6.change; --eventb[{cust_6_pump_2_change}]
      null;

    or

      accept prepay_7_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_7_pump_2;

    or

      accept charge_7_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_7.change; --eventb[{cust_7_pump_2_change}]
      null;

    or

      accept prepay_8_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_8_pump_2;

    or

      accept charge_8_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_8.change; --eventb[{cust_8_pump_2_change}]
      null;

    or

      accept prepay_9_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_9_pump_2;

    or

      accept charge_9_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_9.change; --eventb[{cust_9_pump_2_change}]
      null;

    or

      accept prepay_10_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_10_pump_2;

    or

      accept charge_10_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_10.change; --eventb[{cust_10_pump_2_change}]
      null;

    or

      accept prepay_11_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_11_pump_2;

    or

      accept charge_11_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_11.change; --eventb[{cust_11_pump_2_change}]
      null;

    or

      accept prepay_12_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_12_pump_2;

    or

      accept charge_12_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_12.change; --eventb[{cust_12_pump_2_change}]
      null;

    or

      accept prepay_13_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_13_pump_2;

    or

      accept charge_13_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_13.change; --eventb[{cust_13_pump_2_change}]
      null;

    or

      accept prepay_14_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_14_pump_2;

    or

      accept charge_14_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_14.change; --eventb[{cust_14_pump_2_change}]
      null;

    or

      accept prepay_15_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_15_pump_2;

    or

      accept charge_15_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_15.change; --eventb[{cust_15_pump_2_change}]
      null;

    or

      accept prepay_16_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_16_pump_2;

    or

      accept charge_16_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_16.change; --eventb[{cust_16_pump_2_change}]
      null;

    or

      accept prepay_17_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_17_pump_2;

    or

      accept charge_17_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_17.change; --eventb[{cust_17_pump_2_change}]
      null;

    or

      accept prepay_18_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_18_pump_2;

    or

      accept charge_18_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_18.change; --eventb[{cust_18_pump_2_change}]
      null;

    or

      accept prepay_19_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_19_pump_2;

    or

      accept charge_19_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_19.change; --eventb[{cust_19_pump_2_change}]
      null;

    or

      accept prepay_20_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_20_pump_2;

    or

      accept charge_20_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_20.change; --eventb[{cust_20_pump_2_change}]
      null;

    or

      accept prepay_21_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_21_pump_2;

    or

      accept charge_21_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_21.change; --eventb[{cust_21_pump_2_change}]
      null;

    or

      accept prepay_22_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_22_pump_2;

    or

      accept charge_22_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_22.change; --eventb[{cust_22_pump_2_change}]
      null;

    or

      accept prepay_23_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_23_pump_2;

    or

      accept charge_23_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_23.change; --eventb[{cust_23_pump_2_change}]
      null;

    or

      accept prepay_24_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_24_pump_2;

    or

      accept charge_24_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_24.change; --eventb[{cust_24_pump_2_change}]
      null;

    or

      accept prepay_25_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_25_pump_2;

    or

      accept charge_25_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_25.change; --eventb[{cust_25_pump_2_change}]
      null;

    or

      accept prepay_26_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_26_pump_2;

    or

      accept charge_26_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_26.change; --eventb[{cust_26_pump_2_change}]
      null;

    or

      accept prepay_27_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_27_pump_2;

    or

      accept charge_27_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_27.change; --eventb[{cust_27_pump_2_change}]
      null;

    or

      accept prepay_28_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_28_pump_2;

    or

      accept charge_28_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_28.change; --eventb[{cust_28_pump_2_change}]
      null;

    or

      accept prepay_29_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_29_pump_2;

    or

      accept charge_29_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_29.change; --eventb[{cust_29_pump_2_change}]
      null;

    or

      accept prepay_30_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_30_pump_2;

    or

      accept charge_30_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_30.change; --eventb[{cust_30_pump_2_change}]
      null;

    or

      accept prepay_31_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_31_pump_2;

    or

      accept charge_31_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_31.change; --eventb[{cust_31_pump_2_change}]
      null;

    or

      accept prepay_32_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_32_pump_2;

    or

      accept charge_32_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_32.change; --eventb[{cust_32_pump_2_change}]
      null;

    or

      accept prepay_33_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_33_pump_2;

    or

      accept charge_33_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_33.change; --eventb[{cust_33_pump_2_change}]
      null;

    or

      accept prepay_34_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_34_pump_2;

    or

      accept charge_34_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_34.change; --eventb[{cust_34_pump_2_change}]
      null;

    or

      accept prepay_35_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_35_pump_2;

    or

      accept charge_35_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_35.change; --eventb[{cust_35_pump_2_change}]
      null;

    or

      accept prepay_36_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_36_pump_2;

    or

      accept charge_36_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_36.change; --eventb[{cust_36_pump_2_change}]
      null;

    or

      accept prepay_37_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_37_pump_2;

    or

      accept charge_37_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_37.change; --eventb[{cust_37_pump_2_change}]
      null;

    or

      accept prepay_38_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_38_pump_2;

    or

      accept charge_38_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_38.change; --eventb[{cust_38_pump_2_change}]
      null;

    or

      accept prepay_39_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_39_pump_2;

    or

      accept charge_39_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_39.change; --eventb[{cust_39_pump_2_change}]
      null;

    or

      accept prepay_40_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_40_pump_2;

    or

      accept charge_40_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_40.change; --eventb[{cust_40_pump_2_change}]
      null;

    or

      accept prepay_41_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_41_pump_2;

    or

      accept charge_41_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_41.change; --eventb[{cust_41_pump_2_change}]
      null;

    or

      accept prepay_42_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_42_pump_2;

    or

      accept charge_42_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_42.change; --eventb[{cust_42_pump_2_change}]
      null;

    or

      accept prepay_43_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_43_pump_2;

    or

      accept charge_43_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_43.change; --eventb[{cust_43_pump_2_change}]
      null;

    or

      accept prepay_44_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_44_pump_2;

    or

      accept charge_44_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_44.change; --eventb[{cust_44_pump_2_change}]
      null;

    or

      accept prepay_45_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_45_pump_2;

    or

      accept charge_45_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_45.change; --eventb[{cust_45_pump_2_change}]
      null;

    or

      accept prepay_46_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_46_pump_2;

    or

      accept charge_46_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_46.change; --eventb[{cust_46_pump_2_change}]
      null;

    or

      accept prepay_47_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_47_pump_2;

    or

      accept charge_47_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_47.change; --eventb[{cust_47_pump_2_change}]
      null;

    or

      accept prepay_48_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_48_pump_2;

    or

      accept charge_48_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_48.change; --eventb[{cust_48_pump_2_change}]
      null;

    or

      accept prepay_49_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_49_pump_2;

    or

      accept charge_49_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_49.change; --eventb[{cust_49_pump_2_change}]
      null;

    or

      accept prepay_50_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_50_pump_2;

    or

      accept charge_50_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_50.change; --eventb[{cust_50_pump_2_change}]
      null;

    or

      accept prepay_51_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_51_pump_2;

    or

      accept charge_51_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_51.change; --eventb[{cust_51_pump_2_change}]
      null;

    or

      accept prepay_52_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_52_pump_2;

    or

      accept charge_52_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_52.change; --eventb[{cust_52_pump_2_change}]
      null;

    or

      accept prepay_53_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_53_pump_2;

    or

      accept charge_53_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_53.change; --eventb[{cust_53_pump_2_change}]
      null;

    or

      accept prepay_54_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_54_pump_2;

    or

      accept charge_54_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_54.change; --eventb[{cust_54_pump_2_change}]
      null;

    or

      accept prepay_55_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_55_pump_2;

    or

      accept charge_55_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_55.change; --eventb[{cust_55_pump_2_change}]
      null;

    or

      accept prepay_56_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_56_pump_2;

    or

      accept charge_56_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_56.change; --eventb[{cust_56_pump_2_change}]
      null;

    or

      accept prepay_57_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_57_pump_2;

    or

      accept charge_57_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_57.change; --eventb[{cust_57_pump_2_change}]
      null;

    or

      accept prepay_58_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_58_pump_2;

    or

      accept charge_58_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_58.change; --eventb[{cust_58_pump_2_change}]
      null;

    or

      accept prepay_59_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_59_pump_2;

    or

      accept charge_59_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_59.change; --eventb[{cust_59_pump_2_change}]
      null;

    or

      accept prepay_60_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_60_pump_2;

    or

      accept charge_60_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_60.change; --eventb[{cust_60_pump_2_change}]
      null;

    or

      accept prepay_61_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_61_pump_2;

    or

      accept charge_61_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_61.change; --eventb[{cust_61_pump_2_change}]
      null;

    or

      accept prepay_62_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_62_pump_2;

    or

      accept charge_62_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_62.change; --eventb[{cust_62_pump_2_change}]
      null;

    or

      accept prepay_63_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_63_pump_2;

    or

      accept charge_63_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_63.change; --eventb[{cust_63_pump_2_change}]
      null;

    or

      accept prepay_64_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_64_pump_2;

    or

      accept charge_64_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_64.change; --eventb[{cust_64_pump_2_change}]
      null;

    or

      accept prepay_65_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_65_pump_2;

    or

      accept charge_65_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_65.change; --eventb[{cust_65_pump_2_change}]
      null;

    or

      accept prepay_66_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_66_pump_2;

    or

      accept charge_66_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_66.change; --eventb[{cust_66_pump_2_change}]
      null;

    or

      accept prepay_67_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_67_pump_2;

    or

      accept charge_67_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_67.change; --eventb[{cust_67_pump_2_change}]
      null;

    or

      accept prepay_68_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_68_pump_2;

    or

      accept charge_68_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_68.change; --eventb[{cust_68_pump_2_change}]
      null;

    or

      accept prepay_69_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_69_pump_2;

    or

      accept charge_69_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_69.change; --eventb[{cust_69_pump_2_change}]
      null;

    or

      accept prepay_70_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_70_pump_2;

    or

      accept charge_70_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_70.change; --eventb[{cust_70_pump_2_change}]
      null;

    or

      accept prepay_71_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_71_pump_2;

    or

      accept charge_71_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_71.change; --eventb[{cust_71_pump_2_change}]
      null;

    or

      accept prepay_72_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_72_pump_2;

    or

      accept charge_72_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_72.change; --eventb[{cust_72_pump_2_change}]
      null;

    or

      accept prepay_73_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_73_pump_2;

    or

      accept charge_73_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_73.change; --eventb[{cust_73_pump_2_change}]
      null;

    or

      accept prepay_74_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_74_pump_2;

    or

      accept charge_74_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_74.change; --eventb[{cust_74_pump_2_change}]
      null;

    or

      accept prepay_75_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_75_pump_2;

    or

      accept charge_75_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_75.change; --eventb[{cust_75_pump_2_change}]
      null;

    or

      accept prepay_76_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_76_pump_2;

    or

      accept charge_76_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_76.change; --eventb[{cust_76_pump_2_change}]
      null;

    or

      accept prepay_77_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_77_pump_2;

    or

      accept charge_77_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_77.change; --eventb[{cust_77_pump_2_change}]
      null;

    or

      accept prepay_78_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_78_pump_2;

    or

      accept charge_78_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_78.change; --eventb[{cust_78_pump_2_change}]
      null;

    or

      accept prepay_79_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_79_pump_2;

    or

      accept charge_79_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_79.change; --eventb[{cust_79_pump_2_change}]
      null;

    or

      accept prepay_80_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_80_pump_2;

    or

      accept charge_80_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_80.change; --eventb[{cust_80_pump_2_change}]
      null;

    or

      accept prepay_81_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_81_pump_2;

    or

      accept charge_81_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_81.change; --eventb[{cust_81_pump_2_change}]
      null;

    or

      accept prepay_82_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_82_pump_2;

    or

      accept charge_82_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_82.change; --eventb[{cust_82_pump_2_change}]
      null;

    or

      accept prepay_83_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_83_pump_2;

    or

      accept charge_83_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_83.change; --eventb[{cust_83_pump_2_change}]
      null;

    or

      accept prepay_84_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_84_pump_2;

    or

      accept charge_84_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_84.change; --eventb[{cust_84_pump_2_change}]
      null;

    or

      accept prepay_85_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_85_pump_2;

    or

      accept charge_85_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_85.change; --eventb[{cust_85_pump_2_change}]
      null;

    or

      accept prepay_86_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_86_pump_2;

    or

      accept charge_86_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_86.change; --eventb[{cust_86_pump_2_change}]
      null;

    or

      accept prepay_87_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_87_pump_2;

    or

      accept charge_87_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_87.change; --eventb[{cust_87_pump_2_change}]
      null;

    or

      accept prepay_88_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_88_pump_2;

    or

      accept charge_88_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_88.change; --eventb[{cust_88_pump_2_change}]
      null;

    or

      accept prepay_89_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_89_pump_2;

    or

      accept charge_89_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_89.change; --eventb[{cust_89_pump_2_change}]
      null;

    or

      accept prepay_90_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_90_pump_2;

    or

      accept charge_90_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_90.change; --eventb[{cust_90_pump_2_change}]
      null;

    or

      accept prepay_91_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_91_pump_2;

    or

      accept charge_91_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_91.change; --eventb[{cust_91_pump_2_change}]
      null;

    or

      accept prepay_92_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_92_pump_2;

    or

      accept charge_92_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_92.change; --eventb[{cust_92_pump_2_change}]
      null;

    or

      accept prepay_93_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_93_pump_2;

    or

      accept charge_93_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_93.change; --eventb[{cust_93_pump_2_change}]
      null;

    or

      accept prepay_94_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_94_pump_2;

    or

      accept charge_94_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_94.change; --eventb[{cust_94_pump_2_change}]
      null;

    or

      accept prepay_95_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_95_pump_2;

    or

      accept charge_95_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_95.change; --eventb[{cust_95_pump_2_change}]
      null;

    or

      accept prepay_96_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_96_pump_2;

    or

      accept charge_96_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_96.change; --eventb[{cust_96_pump_2_change}]
      null;

    or

      accept prepay_97_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_97_pump_2;

    or

      accept charge_97_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_97.change; --eventb[{cust_97_pump_2_change}]
      null;

    or

      accept prepay_98_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_98_pump_2;

    or

      accept charge_98_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_98.change; --eventb[{cust_98_pump_2_change}]
      null;

    or

      accept prepay_99_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_99_pump_2;

    or

      accept charge_99_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_99.change; --eventb[{cust_99_pump_2_change}]
      null;

    or

      accept prepay_100_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_100_pump_2;

    or

      accept charge_100_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_100.change; --eventb[{cust_100_pump_2_change}]
      null;

    or

      accept prepay_101_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_101_pump_2;

    or

      accept charge_101_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_101.change; --eventb[{cust_101_pump_2_change}]
      null;

    or

      accept prepay_102_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_102_pump_2;

    or

      accept charge_102_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_102.change; --eventb[{cust_102_pump_2_change}]
      null;

    or

      accept prepay_103_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_103_pump_2;

    or

      accept charge_103_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_103.change; --eventb[{cust_103_pump_2_change}]
      null;

    or

      accept prepay_104_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_104_pump_2;

    or

      accept charge_104_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_104.change; --eventb[{cust_104_pump_2_change}]
      null;

    or

      accept prepay_105_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_105_pump_2;

    or

      accept charge_105_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_105.change; --eventb[{cust_105_pump_2_change}]
      null;

    or

      accept prepay_106_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_106_pump_2;

    or

      accept charge_106_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_106.change; --eventb[{cust_106_pump_2_change}]
      null;

    or

      accept prepay_107_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_107_pump_2;

    or

      accept charge_107_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_107.change; --eventb[{cust_107_pump_2_change}]
      null;

    or

      accept prepay_108_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_108_pump_2;

    or

      accept charge_108_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_108.change; --eventb[{cust_108_pump_2_change}]
      null;

    or

      accept prepay_109_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_109_pump_2;

    or

      accept charge_109_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_109.change; --eventb[{cust_109_pump_2_change}]
      null;

    or

      accept prepay_110_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_110_pump_2;

    or

      accept charge_110_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_110.change; --eventb[{cust_110_pump_2_change}]
      null;
    end select;
  end loop;
end operator;


task body pump_1 is
  done : boolean;
begin
  loop
    exit when done;
    accept activate;
    accept start_pumping; --event[{pump_1_start}]
    null;

    select
      accept stop_pumping_1 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_1_pump_1;
      end stop_pumping_1;
    or
      accept stop_pumping_2 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_2_pump_1;
      end stop_pumping_2;
    or
      accept stop_pumping_3 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_3_pump_1;
      end stop_pumping_3;
    or
      accept stop_pumping_4 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_4_pump_1;
      end stop_pumping_4;
    or
      accept stop_pumping_5 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_5_pump_1;
      end stop_pumping_5;
    or
      accept stop_pumping_6 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_6_pump_1;
      end stop_pumping_6;
    or
      accept stop_pumping_7 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_7_pump_1;
      end stop_pumping_7;
    or
      accept stop_pumping_8 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_8_pump_1;
      end stop_pumping_8;
    or
      accept stop_pumping_9 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_9_pump_1;
      end stop_pumping_9;
    or
      accept stop_pumping_10 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_10_pump_1;
      end stop_pumping_10;
    or
      accept stop_pumping_11 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_11_pump_1;
      end stop_pumping_11;
    or
      accept stop_pumping_12 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_12_pump_1;
      end stop_pumping_12;
    or
      accept stop_pumping_13 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_13_pump_1;
      end stop_pumping_13;
    or
      accept stop_pumping_14 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_14_pump_1;
      end stop_pumping_14;
    or
      accept stop_pumping_15 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_15_pump_1;
      end stop_pumping_15;
    or
      accept stop_pumping_16 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_16_pump_1;
      end stop_pumping_16;
    or
      accept stop_pumping_17 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_17_pump_1;
      end stop_pumping_17;
    or
      accept stop_pumping_18 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_18_pump_1;
      end stop_pumping_18;
    or
      accept stop_pumping_19 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_19_pump_1;
      end stop_pumping_19;
    or
      accept stop_pumping_20 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_20_pump_1;
      end stop_pumping_20;
    or
      accept stop_pumping_21 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_21_pump_1;
      end stop_pumping_21;
    or
      accept stop_pumping_22 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_22_pump_1;
      end stop_pumping_22;
    or
      accept stop_pumping_23 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_23_pump_1;
      end stop_pumping_23;
    or
      accept stop_pumping_24 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_24_pump_1;
      end stop_pumping_24;
    or
      accept stop_pumping_25 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_25_pump_1;
      end stop_pumping_25;
    or
      accept stop_pumping_26 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_26_pump_1;
      end stop_pumping_26;
    or
      accept stop_pumping_27 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_27_pump_1;
      end stop_pumping_27;
    or
      accept stop_pumping_28 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_28_pump_1;
      end stop_pumping_28;
    or
      accept stop_pumping_29 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_29_pump_1;
      end stop_pumping_29;
    or
      accept stop_pumping_30 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_30_pump_1;
      end stop_pumping_30;
    or
      accept stop_pumping_31 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_31_pump_1;
      end stop_pumping_31;
    or
      accept stop_pumping_32 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_32_pump_1;
      end stop_pumping_32;
    or
      accept stop_pumping_33 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_33_pump_1;
      end stop_pumping_33;
    or
      accept stop_pumping_34 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_34_pump_1;
      end stop_pumping_34;
    or
      accept stop_pumping_35 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_35_pump_1;
      end stop_pumping_35;
    or
      accept stop_pumping_36 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_36_pump_1;
      end stop_pumping_36;
    or
      accept stop_pumping_37 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_37_pump_1;
      end stop_pumping_37;
    or
      accept stop_pumping_38 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_38_pump_1;
      end stop_pumping_38;
    or
      accept stop_pumping_39 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_39_pump_1;
      end stop_pumping_39;
    or
      accept stop_pumping_40 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_40_pump_1;
      end stop_pumping_40;
    or
      accept stop_pumping_41 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_41_pump_1;
      end stop_pumping_41;
    or
      accept stop_pumping_42 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_42_pump_1;
      end stop_pumping_42;
    or
      accept stop_pumping_43 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_43_pump_1;
      end stop_pumping_43;
    or
      accept stop_pumping_44 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_44_pump_1;
      end stop_pumping_44;
    or
      accept stop_pumping_45 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_45_pump_1;
      end stop_pumping_45;
    or
      accept stop_pumping_46 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_46_pump_1;
      end stop_pumping_46;
    or
      accept stop_pumping_47 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_47_pump_1;
      end stop_pumping_47;
    or
      accept stop_pumping_48 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_48_pump_1;
      end stop_pumping_48;
    or
      accept stop_pumping_49 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_49_pump_1;
      end stop_pumping_49;
    or
      accept stop_pumping_50 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_50_pump_1;
      end stop_pumping_50;
    or
      accept stop_pumping_51 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_51_pump_1;
      end stop_pumping_51;
    or
      accept stop_pumping_52 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_52_pump_1;
      end stop_pumping_52;
    or
      accept stop_pumping_53 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_53_pump_1;
      end stop_pumping_53;
    or
      accept stop_pumping_54 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_54_pump_1;
      end stop_pumping_54;
    or
      accept stop_pumping_55 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_55_pump_1;
      end stop_pumping_55;
    or
      accept stop_pumping_56 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_56_pump_1;
      end stop_pumping_56;
    or
      accept stop_pumping_57 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_57_pump_1;
      end stop_pumping_57;
    or
      accept stop_pumping_58 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_58_pump_1;
      end stop_pumping_58;
    or
      accept stop_pumping_59 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_59_pump_1;
      end stop_pumping_59;
    or
      accept stop_pumping_60 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_60_pump_1;
      end stop_pumping_60;
    or
      accept stop_pumping_61 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_61_pump_1;
      end stop_pumping_61;
    or
      accept stop_pumping_62 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_62_pump_1;
      end stop_pumping_62;
    or
      accept stop_pumping_63 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_63_pump_1;
      end stop_pumping_63;
    or
      accept stop_pumping_64 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_64_pump_1;
      end stop_pumping_64;
    or
      accept stop_pumping_65 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_65_pump_1;
      end stop_pumping_65;
    or
      accept stop_pumping_66 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_66_pump_1;
      end stop_pumping_66;
    or
      accept stop_pumping_67 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_67_pump_1;
      end stop_pumping_67;
    or
      accept stop_pumping_68 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_68_pump_1;
      end stop_pumping_68;
    or
      accept stop_pumping_69 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_69_pump_1;
      end stop_pumping_69;
    or
      accept stop_pumping_70 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_70_pump_1;
      end stop_pumping_70;
    or
      accept stop_pumping_71 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_71_pump_1;
      end stop_pumping_71;
    or
      accept stop_pumping_72 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_72_pump_1;
      end stop_pumping_72;
    or
      accept stop_pumping_73 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_73_pump_1;
      end stop_pumping_73;
    or
      accept stop_pumping_74 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_74_pump_1;
      end stop_pumping_74;
    or
      accept stop_pumping_75 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_75_pump_1;
      end stop_pumping_75;
    or
      accept stop_pumping_76 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_76_pump_1;
      end stop_pumping_76;
    or
      accept stop_pumping_77 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_77_pump_1;
      end stop_pumping_77;
    or
      accept stop_pumping_78 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_78_pump_1;
      end stop_pumping_78;
    or
      accept stop_pumping_79 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_79_pump_1;
      end stop_pumping_79;
    or
      accept stop_pumping_80 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_80_pump_1;
      end stop_pumping_80;
    or
      accept stop_pumping_81 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_81_pump_1;
      end stop_pumping_81;
    or
      accept stop_pumping_82 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_82_pump_1;
      end stop_pumping_82;
    or
      accept stop_pumping_83 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_83_pump_1;
      end stop_pumping_83;
    or
      accept stop_pumping_84 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_84_pump_1;
      end stop_pumping_84;
    or
      accept stop_pumping_85 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_85_pump_1;
      end stop_pumping_85;
    or
      accept stop_pumping_86 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_86_pump_1;
      end stop_pumping_86;
    or
      accept stop_pumping_87 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_87_pump_1;
      end stop_pumping_87;
    or
      accept stop_pumping_88 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_88_pump_1;
      end stop_pumping_88;
    or
      accept stop_pumping_89 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_89_pump_1;
      end stop_pumping_89;
    or
      accept stop_pumping_90 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_90_pump_1;
      end stop_pumping_90;
    or
      accept stop_pumping_91 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_91_pump_1;
      end stop_pumping_91;
    or
      accept stop_pumping_92 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_92_pump_1;
      end stop_pumping_92;
    or
      accept stop_pumping_93 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_93_pump_1;
      end stop_pumping_93;
    or
      accept stop_pumping_94 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_94_pump_1;
      end stop_pumping_94;
    or
      accept stop_pumping_95 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_95_pump_1;
      end stop_pumping_95;
    or
      accept stop_pumping_96 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_96_pump_1;
      end stop_pumping_96;
    or
      accept stop_pumping_97 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_97_pump_1;
      end stop_pumping_97;
    or
      accept stop_pumping_98 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_98_pump_1;
      end stop_pumping_98;
    or
      accept stop_pumping_99 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_99_pump_1;
      end stop_pumping_99;
    or
      accept stop_pumping_100 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_100_pump_1;
      end stop_pumping_100;
    or
      accept stop_pumping_101 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_101_pump_1;
      end stop_pumping_101;
    or
      accept stop_pumping_102 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_102_pump_1;
      end stop_pumping_102;
    or
      accept stop_pumping_103 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_103_pump_1;
      end stop_pumping_103;
    or
      accept stop_pumping_104 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_104_pump_1;
      end stop_pumping_104;
    or
      accept stop_pumping_105 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_105_pump_1;
      end stop_pumping_105;
    or
      accept stop_pumping_106 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_106_pump_1;
      end stop_pumping_106;
    or
      accept stop_pumping_107 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_107_pump_1;
      end stop_pumping_107;
    or
      accept stop_pumping_108 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_108_pump_1;
      end stop_pumping_108;
    or
      accept stop_pumping_109 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_109_pump_1;
      end stop_pumping_109;
    or
      accept stop_pumping_110 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_110_pump_1;
      end stop_pumping_110;
    end select;
  end loop;
end pump_1;


task body pump_2 is
  done : boolean;
begin
  loop
    exit when done;
    accept activate;
    accept start_pumping; --event[{pump_2_start}]
    null;

    select
      accept stop_pumping_1 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_1_pump_2;
      end stop_pumping_1;
    or
      accept stop_pumping_2 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_2_pump_2;
      end stop_pumping_2;
    or
      accept stop_pumping_3 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_3_pump_2;
      end stop_pumping_3;
    or
      accept stop_pumping_4 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_4_pump_2;
      end stop_pumping_4;
    or
      accept stop_pumping_5 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_5_pump_2;
      end stop_pumping_5;
    or
      accept stop_pumping_6 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_6_pump_2;
      end stop_pumping_6;
    or
      accept stop_pumping_7 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_7_pump_2;
      end stop_pumping_7;
    or
      accept stop_pumping_8 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_8_pump_2;
      end stop_pumping_8;
    or
      accept stop_pumping_9 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_9_pump_2;
      end stop_pumping_9;
    or
      accept stop_pumping_10 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_10_pump_2;
      end stop_pumping_10;
    or
      accept stop_pumping_11 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_11_pump_2;
      end stop_pumping_11;
    or
      accept stop_pumping_12 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_12_pump_2;
      end stop_pumping_12;
    or
      accept stop_pumping_13 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_13_pump_2;
      end stop_pumping_13;
    or
      accept stop_pumping_14 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_14_pump_2;
      end stop_pumping_14;
    or
      accept stop_pumping_15 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_15_pump_2;
      end stop_pumping_15;
    or
      accept stop_pumping_16 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_16_pump_2;
      end stop_pumping_16;
    or
      accept stop_pumping_17 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_17_pump_2;
      end stop_pumping_17;
    or
      accept stop_pumping_18 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_18_pump_2;
      end stop_pumping_18;
    or
      accept stop_pumping_19 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_19_pump_2;
      end stop_pumping_19;
    or
      accept stop_pumping_20 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_20_pump_2;
      end stop_pumping_20;
    or
      accept stop_pumping_21 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_21_pump_2;
      end stop_pumping_21;
    or
      accept stop_pumping_22 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_22_pump_2;
      end stop_pumping_22;
    or
      accept stop_pumping_23 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_23_pump_2;
      end stop_pumping_23;
    or
      accept stop_pumping_24 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_24_pump_2;
      end stop_pumping_24;
    or
      accept stop_pumping_25 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_25_pump_2;
      end stop_pumping_25;
    or
      accept stop_pumping_26 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_26_pump_2;
      end stop_pumping_26;
    or
      accept stop_pumping_27 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_27_pump_2;
      end stop_pumping_27;
    or
      accept stop_pumping_28 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_28_pump_2;
      end stop_pumping_28;
    or
      accept stop_pumping_29 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_29_pump_2;
      end stop_pumping_29;
    or
      accept stop_pumping_30 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_30_pump_2;
      end stop_pumping_30;
    or
      accept stop_pumping_31 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_31_pump_2;
      end stop_pumping_31;
    or
      accept stop_pumping_32 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_32_pump_2;
      end stop_pumping_32;
    or
      accept stop_pumping_33 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_33_pump_2;
      end stop_pumping_33;
    or
      accept stop_pumping_34 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_34_pump_2;
      end stop_pumping_34;
    or
      accept stop_pumping_35 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_35_pump_2;
      end stop_pumping_35;
    or
      accept stop_pumping_36 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_36_pump_2;
      end stop_pumping_36;
    or
      accept stop_pumping_37 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_37_pump_2;
      end stop_pumping_37;
    or
      accept stop_pumping_38 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_38_pump_2;
      end stop_pumping_38;
    or
      accept stop_pumping_39 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_39_pump_2;
      end stop_pumping_39;
    or
      accept stop_pumping_40 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_40_pump_2;
      end stop_pumping_40;
    or
      accept stop_pumping_41 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_41_pump_2;
      end stop_pumping_41;
    or
      accept stop_pumping_42 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_42_pump_2;
      end stop_pumping_42;
    or
      accept stop_pumping_43 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_43_pump_2;
      end stop_pumping_43;
    or
      accept stop_pumping_44 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_44_pump_2;
      end stop_pumping_44;
    or
      accept stop_pumping_45 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_45_pump_2;
      end stop_pumping_45;
    or
      accept stop_pumping_46 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_46_pump_2;
      end stop_pumping_46;
    or
      accept stop_pumping_47 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_47_pump_2;
      end stop_pumping_47;
    or
      accept stop_pumping_48 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_48_pump_2;
      end stop_pumping_48;
    or
      accept stop_pumping_49 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_49_pump_2;
      end stop_pumping_49;
    or
      accept stop_pumping_50 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_50_pump_2;
      end stop_pumping_50;
    or
      accept stop_pumping_51 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_51_pump_2;
      end stop_pumping_51;
    or
      accept stop_pumping_52 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_52_pump_2;
      end stop_pumping_52;
    or
      accept stop_pumping_53 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_53_pump_2;
      end stop_pumping_53;
    or
      accept stop_pumping_54 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_54_pump_2;
      end stop_pumping_54;
    or
      accept stop_pumping_55 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_55_pump_2;
      end stop_pumping_55;
    or
      accept stop_pumping_56 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_56_pump_2;
      end stop_pumping_56;
    or
      accept stop_pumping_57 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_57_pump_2;
      end stop_pumping_57;
    or
      accept stop_pumping_58 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_58_pump_2;
      end stop_pumping_58;
    or
      accept stop_pumping_59 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_59_pump_2;
      end stop_pumping_59;
    or
      accept stop_pumping_60 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_60_pump_2;
      end stop_pumping_60;
    or
      accept stop_pumping_61 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_61_pump_2;
      end stop_pumping_61;
    or
      accept stop_pumping_62 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_62_pump_2;
      end stop_pumping_62;
    or
      accept stop_pumping_63 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_63_pump_2;
      end stop_pumping_63;
    or
      accept stop_pumping_64 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_64_pump_2;
      end stop_pumping_64;
    or
      accept stop_pumping_65 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_65_pump_2;
      end stop_pumping_65;
    or
      accept stop_pumping_66 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_66_pump_2;
      end stop_pumping_66;
    or
      accept stop_pumping_67 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_67_pump_2;
      end stop_pumping_67;
    or
      accept stop_pumping_68 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_68_pump_2;
      end stop_pumping_68;
    or
      accept stop_pumping_69 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_69_pump_2;
      end stop_pumping_69;
    or
      accept stop_pumping_70 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_70_pump_2;
      end stop_pumping_70;
    or
      accept stop_pumping_71 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_71_pump_2;
      end stop_pumping_71;
    or
      accept stop_pumping_72 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_72_pump_2;
      end stop_pumping_72;
    or
      accept stop_pumping_73 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_73_pump_2;
      end stop_pumping_73;
    or
      accept stop_pumping_74 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_74_pump_2;
      end stop_pumping_74;
    or
      accept stop_pumping_75 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_75_pump_2;
      end stop_pumping_75;
    or
      accept stop_pumping_76 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_76_pump_2;
      end stop_pumping_76;
    or
      accept stop_pumping_77 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_77_pump_2;
      end stop_pumping_77;
    or
      accept stop_pumping_78 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_78_pump_2;
      end stop_pumping_78;
    or
      accept stop_pumping_79 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_79_pump_2;
      end stop_pumping_79;
    or
      accept stop_pumping_80 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_80_pump_2;
      end stop_pumping_80;
    or
      accept stop_pumping_81 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_81_pump_2;
      end stop_pumping_81;
    or
      accept stop_pumping_82 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_82_pump_2;
      end stop_pumping_82;
    or
      accept stop_pumping_83 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_83_pump_2;
      end stop_pumping_83;
    or
      accept stop_pumping_84 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_84_pump_2;
      end stop_pumping_84;
    or
      accept stop_pumping_85 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_85_pump_2;
      end stop_pumping_85;
    or
      accept stop_pumping_86 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_86_pump_2;
      end stop_pumping_86;
    or
      accept stop_pumping_87 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_87_pump_2;
      end stop_pumping_87;
    or
      accept stop_pumping_88 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_88_pump_2;
      end stop_pumping_88;
    or
      accept stop_pumping_89 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_89_pump_2;
      end stop_pumping_89;
    or
      accept stop_pumping_90 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_90_pump_2;
      end stop_pumping_90;
    or
      accept stop_pumping_91 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_91_pump_2;
      end stop_pumping_91;
    or
      accept stop_pumping_92 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_92_pump_2;
      end stop_pumping_92;
    or
      accept stop_pumping_93 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_93_pump_2;
      end stop_pumping_93;
    or
      accept stop_pumping_94 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_94_pump_2;
      end stop_pumping_94;
    or
      accept stop_pumping_95 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_95_pump_2;
      end stop_pumping_95;
    or
      accept stop_pumping_96 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_96_pump_2;
      end stop_pumping_96;
    or
      accept stop_pumping_97 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_97_pump_2;
      end stop_pumping_97;
    or
      accept stop_pumping_98 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_98_pump_2;
      end stop_pumping_98;
    or
      accept stop_pumping_99 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_99_pump_2;
      end stop_pumping_99;
    or
      accept stop_pumping_100 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_100_pump_2;
      end stop_pumping_100;
    or
      accept stop_pumping_101 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_101_pump_2;
      end stop_pumping_101;
    or
      accept stop_pumping_102 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_102_pump_2;
      end stop_pumping_102;
    or
      accept stop_pumping_103 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_103_pump_2;
      end stop_pumping_103;
    or
      accept stop_pumping_104 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_104_pump_2;
      end stop_pumping_104;
    or
      accept stop_pumping_105 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_105_pump_2;
      end stop_pumping_105;
    or
      accept stop_pumping_106 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_106_pump_2;
      end stop_pumping_106;
    or
      accept stop_pumping_107 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_107_pump_2;
      end stop_pumping_107;
    or
      accept stop_pumping_108 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_108_pump_2;
      end stop_pumping_108;
    or
      accept stop_pumping_109 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_109_pump_2;
      end stop_pumping_109;
    or
      accept stop_pumping_110 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_110_pump_2;
      end stop_pumping_110;
    end select;
  end loop;
end pump_2;


task body customer_1 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_1_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_1_start_pump_1},{cust_1_start_pump}]
        gas.pump_1.stop_pumping_1; --eventb[{cust_1_stop_pump_1},{cust_1_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_1_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_1_start_pump_2},{cust_1_start_pump}]
        gas.pump_2.stop_pumping_1; --eventb[{cust_1_stop_pump_2},{cust_1_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_1;


task body customer_2 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_2_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_2_start_pump_1},{cust_2_start_pump}]
        gas.pump_1.stop_pumping_2; --eventb[{cust_2_stop_pump_1},{cust_2_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_2_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_2_start_pump_2},{cust_2_start_pump}]
        gas.pump_2.stop_pumping_2; --eventb[{cust_2_stop_pump_2},{cust_2_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_2;


task body customer_3 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_3_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_3_start_pump_1},{cust_3_start_pump}]
        gas.pump_1.stop_pumping_3; --eventb[{cust_3_stop_pump_1},{cust_3_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_3_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_3_start_pump_2},{cust_3_start_pump}]
        gas.pump_2.stop_pumping_3; --eventb[{cust_3_stop_pump_2},{cust_3_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_3;


task body customer_4 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_4_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_4_start_pump_1},{cust_4_start_pump}]
        gas.pump_1.stop_pumping_4; --eventb[{cust_4_stop_pump_1},{cust_4_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_4_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_4_start_pump_2},{cust_4_start_pump}]
        gas.pump_2.stop_pumping_4; --eventb[{cust_4_stop_pump_2},{cust_4_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_4;


task body customer_5 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_5_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_5_start_pump_1},{cust_5_start_pump}]
        gas.pump_1.stop_pumping_5; --eventb[{cust_5_stop_pump_1},{cust_5_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_5_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_5_start_pump_2},{cust_5_start_pump}]
        gas.pump_2.stop_pumping_5; --eventb[{cust_5_stop_pump_2},{cust_5_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_5;


task body customer_6 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_6_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_6_start_pump_1},{cust_6_start_pump}]
        gas.pump_1.stop_pumping_6; --eventb[{cust_6_stop_pump_1},{cust_6_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_6_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_6_start_pump_2},{cust_6_start_pump}]
        gas.pump_2.stop_pumping_6; --eventb[{cust_6_stop_pump_2},{cust_6_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_6;


task body customer_7 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_7_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_7_start_pump_1},{cust_7_start_pump}]
        gas.pump_1.stop_pumping_7; --eventb[{cust_7_stop_pump_1},{cust_7_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_7_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_7_start_pump_2},{cust_7_start_pump}]
        gas.pump_2.stop_pumping_7; --eventb[{cust_7_stop_pump_2},{cust_7_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_7;


task body customer_8 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_8_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_8_start_pump_1},{cust_8_start_pump}]
        gas.pump_1.stop_pumping_8; --eventb[{cust_8_stop_pump_1},{cust_8_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_8_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_8_start_pump_2},{cust_8_start_pump}]
        gas.pump_2.stop_pumping_8; --eventb[{cust_8_stop_pump_2},{cust_8_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_8;


task body customer_9 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_9_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_9_start_pump_1},{cust_9_start_pump}]
        gas.pump_1.stop_pumping_9; --eventb[{cust_9_stop_pump_1},{cust_9_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_9_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_9_start_pump_2},{cust_9_start_pump}]
        gas.pump_2.stop_pumping_9; --eventb[{cust_9_stop_pump_2},{cust_9_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_9;


task body customer_10 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_10_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_10_start_pump_1},{cust_10_start_pump}]
        gas.pump_1.stop_pumping_10; --eventb[{cust_10_stop_pump_1},{cust_10_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_10_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_10_start_pump_2},{cust_10_start_pump}]
        gas.pump_2.stop_pumping_10; --eventb[{cust_10_stop_pump_2},{cust_10_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_10;


task body customer_11 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_11_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_11_start_pump_1},{cust_11_start_pump}]
        gas.pump_1.stop_pumping_11; --eventb[{cust_11_stop_pump_1},{cust_11_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_11_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_11_start_pump_2},{cust_11_start_pump}]
        gas.pump_2.stop_pumping_11; --eventb[{cust_11_stop_pump_2},{cust_11_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_11;


task body customer_12 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_12_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_12_start_pump_1},{cust_12_start_pump}]
        gas.pump_1.stop_pumping_12; --eventb[{cust_12_stop_pump_1},{cust_12_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_12_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_12_start_pump_2},{cust_12_start_pump}]
        gas.pump_2.stop_pumping_12; --eventb[{cust_12_stop_pump_2},{cust_12_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_12;


task body customer_13 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_13_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_13_start_pump_1},{cust_13_start_pump}]
        gas.pump_1.stop_pumping_13; --eventb[{cust_13_stop_pump_1},{cust_13_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_13_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_13_start_pump_2},{cust_13_start_pump}]
        gas.pump_2.stop_pumping_13; --eventb[{cust_13_stop_pump_2},{cust_13_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_13;


task body customer_14 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_14_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_14_start_pump_1},{cust_14_start_pump}]
        gas.pump_1.stop_pumping_14; --eventb[{cust_14_stop_pump_1},{cust_14_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_14_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_14_start_pump_2},{cust_14_start_pump}]
        gas.pump_2.stop_pumping_14; --eventb[{cust_14_stop_pump_2},{cust_14_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_14;


task body customer_15 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_15_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_15_start_pump_1},{cust_15_start_pump}]
        gas.pump_1.stop_pumping_15; --eventb[{cust_15_stop_pump_1},{cust_15_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_15_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_15_start_pump_2},{cust_15_start_pump}]
        gas.pump_2.stop_pumping_15; --eventb[{cust_15_stop_pump_2},{cust_15_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_15;


task body customer_16 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_16_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_16_start_pump_1},{cust_16_start_pump}]
        gas.pump_1.stop_pumping_16; --eventb[{cust_16_stop_pump_1},{cust_16_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_16_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_16_start_pump_2},{cust_16_start_pump}]
        gas.pump_2.stop_pumping_16; --eventb[{cust_16_stop_pump_2},{cust_16_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_16;


task body customer_17 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_17_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_17_start_pump_1},{cust_17_start_pump}]
        gas.pump_1.stop_pumping_17; --eventb[{cust_17_stop_pump_1},{cust_17_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_17_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_17_start_pump_2},{cust_17_start_pump}]
        gas.pump_2.stop_pumping_17; --eventb[{cust_17_stop_pump_2},{cust_17_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_17;


task body customer_18 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_18_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_18_start_pump_1},{cust_18_start_pump}]
        gas.pump_1.stop_pumping_18; --eventb[{cust_18_stop_pump_1},{cust_18_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_18_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_18_start_pump_2},{cust_18_start_pump}]
        gas.pump_2.stop_pumping_18; --eventb[{cust_18_stop_pump_2},{cust_18_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_18;


task body customer_19 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_19_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_19_start_pump_1},{cust_19_start_pump}]
        gas.pump_1.stop_pumping_19; --eventb[{cust_19_stop_pump_1},{cust_19_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_19_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_19_start_pump_2},{cust_19_start_pump}]
        gas.pump_2.stop_pumping_19; --eventb[{cust_19_stop_pump_2},{cust_19_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_19;


task body customer_20 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_20_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_20_start_pump_1},{cust_20_start_pump}]
        gas.pump_1.stop_pumping_20; --eventb[{cust_20_stop_pump_1},{cust_20_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_20_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_20_start_pump_2},{cust_20_start_pump}]
        gas.pump_2.stop_pumping_20; --eventb[{cust_20_stop_pump_2},{cust_20_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_20;


task body customer_21 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_21_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_21_start_pump_1},{cust_21_start_pump}]
        gas.pump_1.stop_pumping_21; --eventb[{cust_21_stop_pump_1},{cust_21_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_21_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_21_start_pump_2},{cust_21_start_pump}]
        gas.pump_2.stop_pumping_21; --eventb[{cust_21_stop_pump_2},{cust_21_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_21;


task body customer_22 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_22_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_22_start_pump_1},{cust_22_start_pump}]
        gas.pump_1.stop_pumping_22; --eventb[{cust_22_stop_pump_1},{cust_22_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_22_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_22_start_pump_2},{cust_22_start_pump}]
        gas.pump_2.stop_pumping_22; --eventb[{cust_22_stop_pump_2},{cust_22_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_22;


task body customer_23 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_23_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_23_start_pump_1},{cust_23_start_pump}]
        gas.pump_1.stop_pumping_23; --eventb[{cust_23_stop_pump_1},{cust_23_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_23_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_23_start_pump_2},{cust_23_start_pump}]
        gas.pump_2.stop_pumping_23; --eventb[{cust_23_stop_pump_2},{cust_23_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_23;


task body customer_24 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_24_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_24_start_pump_1},{cust_24_start_pump}]
        gas.pump_1.stop_pumping_24; --eventb[{cust_24_stop_pump_1},{cust_24_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_24_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_24_start_pump_2},{cust_24_start_pump}]
        gas.pump_2.stop_pumping_24; --eventb[{cust_24_stop_pump_2},{cust_24_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_24;


task body customer_25 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_25_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_25_start_pump_1},{cust_25_start_pump}]
        gas.pump_1.stop_pumping_25; --eventb[{cust_25_stop_pump_1},{cust_25_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_25_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_25_start_pump_2},{cust_25_start_pump}]
        gas.pump_2.stop_pumping_25; --eventb[{cust_25_stop_pump_2},{cust_25_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_25;


task body customer_26 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_26_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_26_start_pump_1},{cust_26_start_pump}]
        gas.pump_1.stop_pumping_26; --eventb[{cust_26_stop_pump_1},{cust_26_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_26_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_26_start_pump_2},{cust_26_start_pump}]
        gas.pump_2.stop_pumping_26; --eventb[{cust_26_stop_pump_2},{cust_26_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_26;


task body customer_27 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_27_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_27_start_pump_1},{cust_27_start_pump}]
        gas.pump_1.stop_pumping_27; --eventb[{cust_27_stop_pump_1},{cust_27_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_27_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_27_start_pump_2},{cust_27_start_pump}]
        gas.pump_2.stop_pumping_27; --eventb[{cust_27_stop_pump_2},{cust_27_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_27;


task body customer_28 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_28_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_28_start_pump_1},{cust_28_start_pump}]
        gas.pump_1.stop_pumping_28; --eventb[{cust_28_stop_pump_1},{cust_28_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_28_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_28_start_pump_2},{cust_28_start_pump}]
        gas.pump_2.stop_pumping_28; --eventb[{cust_28_stop_pump_2},{cust_28_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_28;


task body customer_29 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_29_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_29_start_pump_1},{cust_29_start_pump}]
        gas.pump_1.stop_pumping_29; --eventb[{cust_29_stop_pump_1},{cust_29_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_29_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_29_start_pump_2},{cust_29_start_pump}]
        gas.pump_2.stop_pumping_29; --eventb[{cust_29_stop_pump_2},{cust_29_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_29;


task body customer_30 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_30_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_30_start_pump_1},{cust_30_start_pump}]
        gas.pump_1.stop_pumping_30; --eventb[{cust_30_stop_pump_1},{cust_30_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_30_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_30_start_pump_2},{cust_30_start_pump}]
        gas.pump_2.stop_pumping_30; --eventb[{cust_30_stop_pump_2},{cust_30_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_30;


task body customer_31 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_31_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_31_start_pump_1},{cust_31_start_pump}]
        gas.pump_1.stop_pumping_31; --eventb[{cust_31_stop_pump_1},{cust_31_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_31_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_31_start_pump_2},{cust_31_start_pump}]
        gas.pump_2.stop_pumping_31; --eventb[{cust_31_stop_pump_2},{cust_31_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_31;


task body customer_32 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_32_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_32_start_pump_1},{cust_32_start_pump}]
        gas.pump_1.stop_pumping_32; --eventb[{cust_32_stop_pump_1},{cust_32_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_32_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_32_start_pump_2},{cust_32_start_pump}]
        gas.pump_2.stop_pumping_32; --eventb[{cust_32_stop_pump_2},{cust_32_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_32;


task body customer_33 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_33_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_33_start_pump_1},{cust_33_start_pump}]
        gas.pump_1.stop_pumping_33; --eventb[{cust_33_stop_pump_1},{cust_33_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_33_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_33_start_pump_2},{cust_33_start_pump}]
        gas.pump_2.stop_pumping_33; --eventb[{cust_33_stop_pump_2},{cust_33_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_33;


task body customer_34 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_34_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_34_start_pump_1},{cust_34_start_pump}]
        gas.pump_1.stop_pumping_34; --eventb[{cust_34_stop_pump_1},{cust_34_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_34_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_34_start_pump_2},{cust_34_start_pump}]
        gas.pump_2.stop_pumping_34; --eventb[{cust_34_stop_pump_2},{cust_34_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_34;


task body customer_35 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_35_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_35_start_pump_1},{cust_35_start_pump}]
        gas.pump_1.stop_pumping_35; --eventb[{cust_35_stop_pump_1},{cust_35_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_35_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_35_start_pump_2},{cust_35_start_pump}]
        gas.pump_2.stop_pumping_35; --eventb[{cust_35_stop_pump_2},{cust_35_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_35;


task body customer_36 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_36_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_36_start_pump_1},{cust_36_start_pump}]
        gas.pump_1.stop_pumping_36; --eventb[{cust_36_stop_pump_1},{cust_36_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_36_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_36_start_pump_2},{cust_36_start_pump}]
        gas.pump_2.stop_pumping_36; --eventb[{cust_36_stop_pump_2},{cust_36_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_36;


task body customer_37 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_37_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_37_start_pump_1},{cust_37_start_pump}]
        gas.pump_1.stop_pumping_37; --eventb[{cust_37_stop_pump_1},{cust_37_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_37_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_37_start_pump_2},{cust_37_start_pump}]
        gas.pump_2.stop_pumping_37; --eventb[{cust_37_stop_pump_2},{cust_37_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_37;


task body customer_38 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_38_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_38_start_pump_1},{cust_38_start_pump}]
        gas.pump_1.stop_pumping_38; --eventb[{cust_38_stop_pump_1},{cust_38_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_38_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_38_start_pump_2},{cust_38_start_pump}]
        gas.pump_2.stop_pumping_38; --eventb[{cust_38_stop_pump_2},{cust_38_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_38;


task body customer_39 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_39_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_39_start_pump_1},{cust_39_start_pump}]
        gas.pump_1.stop_pumping_39; --eventb[{cust_39_stop_pump_1},{cust_39_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_39_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_39_start_pump_2},{cust_39_start_pump}]
        gas.pump_2.stop_pumping_39; --eventb[{cust_39_stop_pump_2},{cust_39_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_39;


task body customer_40 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_40_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_40_start_pump_1},{cust_40_start_pump}]
        gas.pump_1.stop_pumping_40; --eventb[{cust_40_stop_pump_1},{cust_40_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_40_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_40_start_pump_2},{cust_40_start_pump}]
        gas.pump_2.stop_pumping_40; --eventb[{cust_40_stop_pump_2},{cust_40_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_40;


task body customer_41 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_41_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_41_start_pump_1},{cust_41_start_pump}]
        gas.pump_1.stop_pumping_41; --eventb[{cust_41_stop_pump_1},{cust_41_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_41_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_41_start_pump_2},{cust_41_start_pump}]
        gas.pump_2.stop_pumping_41; --eventb[{cust_41_stop_pump_2},{cust_41_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_41;


task body customer_42 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_42_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_42_start_pump_1},{cust_42_start_pump}]
        gas.pump_1.stop_pumping_42; --eventb[{cust_42_stop_pump_1},{cust_42_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_42_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_42_start_pump_2},{cust_42_start_pump}]
        gas.pump_2.stop_pumping_42; --eventb[{cust_42_stop_pump_2},{cust_42_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_42;


task body customer_43 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_43_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_43_start_pump_1},{cust_43_start_pump}]
        gas.pump_1.stop_pumping_43; --eventb[{cust_43_stop_pump_1},{cust_43_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_43_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_43_start_pump_2},{cust_43_start_pump}]
        gas.pump_2.stop_pumping_43; --eventb[{cust_43_stop_pump_2},{cust_43_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_43;


task body customer_44 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_44_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_44_start_pump_1},{cust_44_start_pump}]
        gas.pump_1.stop_pumping_44; --eventb[{cust_44_stop_pump_1},{cust_44_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_44_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_44_start_pump_2},{cust_44_start_pump}]
        gas.pump_2.stop_pumping_44; --eventb[{cust_44_stop_pump_2},{cust_44_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_44;


task body customer_45 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_45_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_45_start_pump_1},{cust_45_start_pump}]
        gas.pump_1.stop_pumping_45; --eventb[{cust_45_stop_pump_1},{cust_45_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_45_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_45_start_pump_2},{cust_45_start_pump}]
        gas.pump_2.stop_pumping_45; --eventb[{cust_45_stop_pump_2},{cust_45_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_45;


task body customer_46 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_46_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_46_start_pump_1},{cust_46_start_pump}]
        gas.pump_1.stop_pumping_46; --eventb[{cust_46_stop_pump_1},{cust_46_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_46_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_46_start_pump_2},{cust_46_start_pump}]
        gas.pump_2.stop_pumping_46; --eventb[{cust_46_stop_pump_2},{cust_46_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_46;


task body customer_47 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_47_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_47_start_pump_1},{cust_47_start_pump}]
        gas.pump_1.stop_pumping_47; --eventb[{cust_47_stop_pump_1},{cust_47_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_47_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_47_start_pump_2},{cust_47_start_pump}]
        gas.pump_2.stop_pumping_47; --eventb[{cust_47_stop_pump_2},{cust_47_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_47;


task body customer_48 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_48_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_48_start_pump_1},{cust_48_start_pump}]
        gas.pump_1.stop_pumping_48; --eventb[{cust_48_stop_pump_1},{cust_48_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_48_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_48_start_pump_2},{cust_48_start_pump}]
        gas.pump_2.stop_pumping_48; --eventb[{cust_48_stop_pump_2},{cust_48_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_48;


task body customer_49 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_49_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_49_start_pump_1},{cust_49_start_pump}]
        gas.pump_1.stop_pumping_49; --eventb[{cust_49_stop_pump_1},{cust_49_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_49_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_49_start_pump_2},{cust_49_start_pump}]
        gas.pump_2.stop_pumping_49; --eventb[{cust_49_stop_pump_2},{cust_49_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_49;


task body customer_50 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_50_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_50_start_pump_1},{cust_50_start_pump}]
        gas.pump_1.stop_pumping_50; --eventb[{cust_50_stop_pump_1},{cust_50_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_50_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_50_start_pump_2},{cust_50_start_pump}]
        gas.pump_2.stop_pumping_50; --eventb[{cust_50_stop_pump_2},{cust_50_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_50;


task body customer_51 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_51_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_51_start_pump_1},{cust_51_start_pump}]
        gas.pump_1.stop_pumping_51; --eventb[{cust_51_stop_pump_1},{cust_51_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_51_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_51_start_pump_2},{cust_51_start_pump}]
        gas.pump_2.stop_pumping_51; --eventb[{cust_51_stop_pump_2},{cust_51_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_51;


task body customer_52 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_52_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_52_start_pump_1},{cust_52_start_pump}]
        gas.pump_1.stop_pumping_52; --eventb[{cust_52_stop_pump_1},{cust_52_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_52_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_52_start_pump_2},{cust_52_start_pump}]
        gas.pump_2.stop_pumping_52; --eventb[{cust_52_stop_pump_2},{cust_52_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_52;


task body customer_53 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_53_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_53_start_pump_1},{cust_53_start_pump}]
        gas.pump_1.stop_pumping_53; --eventb[{cust_53_stop_pump_1},{cust_53_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_53_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_53_start_pump_2},{cust_53_start_pump}]
        gas.pump_2.stop_pumping_53; --eventb[{cust_53_stop_pump_2},{cust_53_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_53;


task body customer_54 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_54_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_54_start_pump_1},{cust_54_start_pump}]
        gas.pump_1.stop_pumping_54; --eventb[{cust_54_stop_pump_1},{cust_54_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_54_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_54_start_pump_2},{cust_54_start_pump}]
        gas.pump_2.stop_pumping_54; --eventb[{cust_54_stop_pump_2},{cust_54_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_54;


task body customer_55 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_55_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_55_start_pump_1},{cust_55_start_pump}]
        gas.pump_1.stop_pumping_55; --eventb[{cust_55_stop_pump_1},{cust_55_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_55_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_55_start_pump_2},{cust_55_start_pump}]
        gas.pump_2.stop_pumping_55; --eventb[{cust_55_stop_pump_2},{cust_55_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_55;


task body customer_56 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_56_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_56_start_pump_1},{cust_56_start_pump}]
        gas.pump_1.stop_pumping_56; --eventb[{cust_56_stop_pump_1},{cust_56_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_56_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_56_start_pump_2},{cust_56_start_pump}]
        gas.pump_2.stop_pumping_56; --eventb[{cust_56_stop_pump_2},{cust_56_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_56;


task body customer_57 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_57_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_57_start_pump_1},{cust_57_start_pump}]
        gas.pump_1.stop_pumping_57; --eventb[{cust_57_stop_pump_1},{cust_57_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_57_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_57_start_pump_2},{cust_57_start_pump}]
        gas.pump_2.stop_pumping_57; --eventb[{cust_57_stop_pump_2},{cust_57_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_57;


task body customer_58 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_58_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_58_start_pump_1},{cust_58_start_pump}]
        gas.pump_1.stop_pumping_58; --eventb[{cust_58_stop_pump_1},{cust_58_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_58_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_58_start_pump_2},{cust_58_start_pump}]
        gas.pump_2.stop_pumping_58; --eventb[{cust_58_stop_pump_2},{cust_58_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_58;


task body customer_59 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_59_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_59_start_pump_1},{cust_59_start_pump}]
        gas.pump_1.stop_pumping_59; --eventb[{cust_59_stop_pump_1},{cust_59_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_59_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_59_start_pump_2},{cust_59_start_pump}]
        gas.pump_2.stop_pumping_59; --eventb[{cust_59_stop_pump_2},{cust_59_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_59;


task body customer_60 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_60_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_60_start_pump_1},{cust_60_start_pump}]
        gas.pump_1.stop_pumping_60; --eventb[{cust_60_stop_pump_1},{cust_60_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_60_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_60_start_pump_2},{cust_60_start_pump}]
        gas.pump_2.stop_pumping_60; --eventb[{cust_60_stop_pump_2},{cust_60_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_60;


task body customer_61 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_61_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_61_start_pump_1},{cust_61_start_pump}]
        gas.pump_1.stop_pumping_61; --eventb[{cust_61_stop_pump_1},{cust_61_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_61_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_61_start_pump_2},{cust_61_start_pump}]
        gas.pump_2.stop_pumping_61; --eventb[{cust_61_stop_pump_2},{cust_61_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_61;


task body customer_62 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_62_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_62_start_pump_1},{cust_62_start_pump}]
        gas.pump_1.stop_pumping_62; --eventb[{cust_62_stop_pump_1},{cust_62_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_62_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_62_start_pump_2},{cust_62_start_pump}]
        gas.pump_2.stop_pumping_62; --eventb[{cust_62_stop_pump_2},{cust_62_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_62;


task body customer_63 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_63_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_63_start_pump_1},{cust_63_start_pump}]
        gas.pump_1.stop_pumping_63; --eventb[{cust_63_stop_pump_1},{cust_63_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_63_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_63_start_pump_2},{cust_63_start_pump}]
        gas.pump_2.stop_pumping_63; --eventb[{cust_63_stop_pump_2},{cust_63_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_63;


task body customer_64 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_64_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_64_start_pump_1},{cust_64_start_pump}]
        gas.pump_1.stop_pumping_64; --eventb[{cust_64_stop_pump_1},{cust_64_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_64_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_64_start_pump_2},{cust_64_start_pump}]
        gas.pump_2.stop_pumping_64; --eventb[{cust_64_stop_pump_2},{cust_64_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_64;


task body customer_65 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_65_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_65_start_pump_1},{cust_65_start_pump}]
        gas.pump_1.stop_pumping_65; --eventb[{cust_65_stop_pump_1},{cust_65_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_65_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_65_start_pump_2},{cust_65_start_pump}]
        gas.pump_2.stop_pumping_65; --eventb[{cust_65_stop_pump_2},{cust_65_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_65;


task body customer_66 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_66_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_66_start_pump_1},{cust_66_start_pump}]
        gas.pump_1.stop_pumping_66; --eventb[{cust_66_stop_pump_1},{cust_66_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_66_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_66_start_pump_2},{cust_66_start_pump}]
        gas.pump_2.stop_pumping_66; --eventb[{cust_66_stop_pump_2},{cust_66_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_66;


task body customer_67 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_67_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_67_start_pump_1},{cust_67_start_pump}]
        gas.pump_1.stop_pumping_67; --eventb[{cust_67_stop_pump_1},{cust_67_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_67_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_67_start_pump_2},{cust_67_start_pump}]
        gas.pump_2.stop_pumping_67; --eventb[{cust_67_stop_pump_2},{cust_67_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_67;


task body customer_68 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_68_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_68_start_pump_1},{cust_68_start_pump}]
        gas.pump_1.stop_pumping_68; --eventb[{cust_68_stop_pump_1},{cust_68_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_68_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_68_start_pump_2},{cust_68_start_pump}]
        gas.pump_2.stop_pumping_68; --eventb[{cust_68_stop_pump_2},{cust_68_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_68;


task body customer_69 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_69_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_69_start_pump_1},{cust_69_start_pump}]
        gas.pump_1.stop_pumping_69; --eventb[{cust_69_stop_pump_1},{cust_69_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_69_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_69_start_pump_2},{cust_69_start_pump}]
        gas.pump_2.stop_pumping_69; --eventb[{cust_69_stop_pump_2},{cust_69_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_69;


task body customer_70 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_70_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_70_start_pump_1},{cust_70_start_pump}]
        gas.pump_1.stop_pumping_70; --eventb[{cust_70_stop_pump_1},{cust_70_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_70_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_70_start_pump_2},{cust_70_start_pump}]
        gas.pump_2.stop_pumping_70; --eventb[{cust_70_stop_pump_2},{cust_70_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_70;


task body customer_71 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_71_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_71_start_pump_1},{cust_71_start_pump}]
        gas.pump_1.stop_pumping_71; --eventb[{cust_71_stop_pump_1},{cust_71_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_71_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_71_start_pump_2},{cust_71_start_pump}]
        gas.pump_2.stop_pumping_71; --eventb[{cust_71_stop_pump_2},{cust_71_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_71;


task body customer_72 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_72_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_72_start_pump_1},{cust_72_start_pump}]
        gas.pump_1.stop_pumping_72; --eventb[{cust_72_stop_pump_1},{cust_72_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_72_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_72_start_pump_2},{cust_72_start_pump}]
        gas.pump_2.stop_pumping_72; --eventb[{cust_72_stop_pump_2},{cust_72_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_72;


task body customer_73 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_73_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_73_start_pump_1},{cust_73_start_pump}]
        gas.pump_1.stop_pumping_73; --eventb[{cust_73_stop_pump_1},{cust_73_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_73_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_73_start_pump_2},{cust_73_start_pump}]
        gas.pump_2.stop_pumping_73; --eventb[{cust_73_stop_pump_2},{cust_73_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_73;


task body customer_74 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_74_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_74_start_pump_1},{cust_74_start_pump}]
        gas.pump_1.stop_pumping_74; --eventb[{cust_74_stop_pump_1},{cust_74_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_74_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_74_start_pump_2},{cust_74_start_pump}]
        gas.pump_2.stop_pumping_74; --eventb[{cust_74_stop_pump_2},{cust_74_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_74;


task body customer_75 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_75_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_75_start_pump_1},{cust_75_start_pump}]
        gas.pump_1.stop_pumping_75; --eventb[{cust_75_stop_pump_1},{cust_75_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_75_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_75_start_pump_2},{cust_75_start_pump}]
        gas.pump_2.stop_pumping_75; --eventb[{cust_75_stop_pump_2},{cust_75_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_75;


task body customer_76 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_76_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_76_start_pump_1},{cust_76_start_pump}]
        gas.pump_1.stop_pumping_76; --eventb[{cust_76_stop_pump_1},{cust_76_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_76_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_76_start_pump_2},{cust_76_start_pump}]
        gas.pump_2.stop_pumping_76; --eventb[{cust_76_stop_pump_2},{cust_76_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_76;


task body customer_77 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_77_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_77_start_pump_1},{cust_77_start_pump}]
        gas.pump_1.stop_pumping_77; --eventb[{cust_77_stop_pump_1},{cust_77_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_77_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_77_start_pump_2},{cust_77_start_pump}]
        gas.pump_2.stop_pumping_77; --eventb[{cust_77_stop_pump_2},{cust_77_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_77;


task body customer_78 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_78_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_78_start_pump_1},{cust_78_start_pump}]
        gas.pump_1.stop_pumping_78; --eventb[{cust_78_stop_pump_1},{cust_78_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_78_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_78_start_pump_2},{cust_78_start_pump}]
        gas.pump_2.stop_pumping_78; --eventb[{cust_78_stop_pump_2},{cust_78_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_78;


task body customer_79 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_79_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_79_start_pump_1},{cust_79_start_pump}]
        gas.pump_1.stop_pumping_79; --eventb[{cust_79_stop_pump_1},{cust_79_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_79_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_79_start_pump_2},{cust_79_start_pump}]
        gas.pump_2.stop_pumping_79; --eventb[{cust_79_stop_pump_2},{cust_79_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_79;


task body customer_80 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_80_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_80_start_pump_1},{cust_80_start_pump}]
        gas.pump_1.stop_pumping_80; --eventb[{cust_80_stop_pump_1},{cust_80_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_80_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_80_start_pump_2},{cust_80_start_pump}]
        gas.pump_2.stop_pumping_80; --eventb[{cust_80_stop_pump_2},{cust_80_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_80;


task body customer_81 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_81_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_81_start_pump_1},{cust_81_start_pump}]
        gas.pump_1.stop_pumping_81; --eventb[{cust_81_stop_pump_1},{cust_81_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_81_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_81_start_pump_2},{cust_81_start_pump}]
        gas.pump_2.stop_pumping_81; --eventb[{cust_81_stop_pump_2},{cust_81_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_81;


task body customer_82 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_82_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_82_start_pump_1},{cust_82_start_pump}]
        gas.pump_1.stop_pumping_82; --eventb[{cust_82_stop_pump_1},{cust_82_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_82_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_82_start_pump_2},{cust_82_start_pump}]
        gas.pump_2.stop_pumping_82; --eventb[{cust_82_stop_pump_2},{cust_82_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_82;


task body customer_83 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_83_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_83_start_pump_1},{cust_83_start_pump}]
        gas.pump_1.stop_pumping_83; --eventb[{cust_83_stop_pump_1},{cust_83_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_83_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_83_start_pump_2},{cust_83_start_pump}]
        gas.pump_2.stop_pumping_83; --eventb[{cust_83_stop_pump_2},{cust_83_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_83;


task body customer_84 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_84_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_84_start_pump_1},{cust_84_start_pump}]
        gas.pump_1.stop_pumping_84; --eventb[{cust_84_stop_pump_1},{cust_84_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_84_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_84_start_pump_2},{cust_84_start_pump}]
        gas.pump_2.stop_pumping_84; --eventb[{cust_84_stop_pump_2},{cust_84_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_84;


task body customer_85 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_85_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_85_start_pump_1},{cust_85_start_pump}]
        gas.pump_1.stop_pumping_85; --eventb[{cust_85_stop_pump_1},{cust_85_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_85_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_85_start_pump_2},{cust_85_start_pump}]
        gas.pump_2.stop_pumping_85; --eventb[{cust_85_stop_pump_2},{cust_85_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_85;


task body customer_86 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_86_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_86_start_pump_1},{cust_86_start_pump}]
        gas.pump_1.stop_pumping_86; --eventb[{cust_86_stop_pump_1},{cust_86_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_86_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_86_start_pump_2},{cust_86_start_pump}]
        gas.pump_2.stop_pumping_86; --eventb[{cust_86_stop_pump_2},{cust_86_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_86;


task body customer_87 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_87_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_87_start_pump_1},{cust_87_start_pump}]
        gas.pump_1.stop_pumping_87; --eventb[{cust_87_stop_pump_1},{cust_87_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_87_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_87_start_pump_2},{cust_87_start_pump}]
        gas.pump_2.stop_pumping_87; --eventb[{cust_87_stop_pump_2},{cust_87_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_87;


task body customer_88 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_88_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_88_start_pump_1},{cust_88_start_pump}]
        gas.pump_1.stop_pumping_88; --eventb[{cust_88_stop_pump_1},{cust_88_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_88_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_88_start_pump_2},{cust_88_start_pump}]
        gas.pump_2.stop_pumping_88; --eventb[{cust_88_stop_pump_2},{cust_88_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_88;


task body customer_89 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_89_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_89_start_pump_1},{cust_89_start_pump}]
        gas.pump_1.stop_pumping_89; --eventb[{cust_89_stop_pump_1},{cust_89_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_89_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_89_start_pump_2},{cust_89_start_pump}]
        gas.pump_2.stop_pumping_89; --eventb[{cust_89_stop_pump_2},{cust_89_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_89;


task body customer_90 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_90_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_90_start_pump_1},{cust_90_start_pump}]
        gas.pump_1.stop_pumping_90; --eventb[{cust_90_stop_pump_1},{cust_90_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_90_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_90_start_pump_2},{cust_90_start_pump}]
        gas.pump_2.stop_pumping_90; --eventb[{cust_90_stop_pump_2},{cust_90_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_90;


task body customer_91 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_91_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_91_start_pump_1},{cust_91_start_pump}]
        gas.pump_1.stop_pumping_91; --eventb[{cust_91_stop_pump_1},{cust_91_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_91_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_91_start_pump_2},{cust_91_start_pump}]
        gas.pump_2.stop_pumping_91; --eventb[{cust_91_stop_pump_2},{cust_91_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_91;


task body customer_92 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_92_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_92_start_pump_1},{cust_92_start_pump}]
        gas.pump_1.stop_pumping_92; --eventb[{cust_92_stop_pump_1},{cust_92_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_92_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_92_start_pump_2},{cust_92_start_pump}]
        gas.pump_2.stop_pumping_92; --eventb[{cust_92_stop_pump_2},{cust_92_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_92;


task body customer_93 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_93_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_93_start_pump_1},{cust_93_start_pump}]
        gas.pump_1.stop_pumping_93; --eventb[{cust_93_stop_pump_1},{cust_93_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_93_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_93_start_pump_2},{cust_93_start_pump}]
        gas.pump_2.stop_pumping_93; --eventb[{cust_93_stop_pump_2},{cust_93_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_93;


task body customer_94 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_94_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_94_start_pump_1},{cust_94_start_pump}]
        gas.pump_1.stop_pumping_94; --eventb[{cust_94_stop_pump_1},{cust_94_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_94_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_94_start_pump_2},{cust_94_start_pump}]
        gas.pump_2.stop_pumping_94; --eventb[{cust_94_stop_pump_2},{cust_94_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_94;


task body customer_95 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_95_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_95_start_pump_1},{cust_95_start_pump}]
        gas.pump_1.stop_pumping_95; --eventb[{cust_95_stop_pump_1},{cust_95_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_95_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_95_start_pump_2},{cust_95_start_pump}]
        gas.pump_2.stop_pumping_95; --eventb[{cust_95_stop_pump_2},{cust_95_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_95;


task body customer_96 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_96_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_96_start_pump_1},{cust_96_start_pump}]
        gas.pump_1.stop_pumping_96; --eventb[{cust_96_stop_pump_1},{cust_96_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_96_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_96_start_pump_2},{cust_96_start_pump}]
        gas.pump_2.stop_pumping_96; --eventb[{cust_96_stop_pump_2},{cust_96_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_96;


task body customer_97 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_97_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_97_start_pump_1},{cust_97_start_pump}]
        gas.pump_1.stop_pumping_97; --eventb[{cust_97_stop_pump_1},{cust_97_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_97_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_97_start_pump_2},{cust_97_start_pump}]
        gas.pump_2.stop_pumping_97; --eventb[{cust_97_stop_pump_2},{cust_97_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_97;


task body customer_98 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_98_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_98_start_pump_1},{cust_98_start_pump}]
        gas.pump_1.stop_pumping_98; --eventb[{cust_98_stop_pump_1},{cust_98_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_98_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_98_start_pump_2},{cust_98_start_pump}]
        gas.pump_2.stop_pumping_98; --eventb[{cust_98_stop_pump_2},{cust_98_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_98;


task body customer_99 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_99_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_99_start_pump_1},{cust_99_start_pump}]
        gas.pump_1.stop_pumping_99; --eventb[{cust_99_stop_pump_1},{cust_99_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_99_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_99_start_pump_2},{cust_99_start_pump}]
        gas.pump_2.stop_pumping_99; --eventb[{cust_99_stop_pump_2},{cust_99_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_99;


task body customer_100 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_100_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_100_start_pump_1},{cust_100_start_pump}]
        gas.pump_1.stop_pumping_100; --eventb[{cust_100_stop_pump_1},{cust_100_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_100_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_100_start_pump_2},{cust_100_start_pump}]
        gas.pump_2.stop_pumping_100; --eventb[{cust_100_stop_pump_2},{cust_100_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_100;


task body customer_101 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_101_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_101_start_pump_1},{cust_101_start_pump}]
        gas.pump_1.stop_pumping_101; --eventb[{cust_101_stop_pump_1},{cust_101_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_101_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_101_start_pump_2},{cust_101_start_pump}]
        gas.pump_2.stop_pumping_101; --eventb[{cust_101_stop_pump_2},{cust_101_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_101;


task body customer_102 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_102_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_102_start_pump_1},{cust_102_start_pump}]
        gas.pump_1.stop_pumping_102; --eventb[{cust_102_stop_pump_1},{cust_102_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_102_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_102_start_pump_2},{cust_102_start_pump}]
        gas.pump_2.stop_pumping_102; --eventb[{cust_102_stop_pump_2},{cust_102_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_102;


task body customer_103 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_103_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_103_start_pump_1},{cust_103_start_pump}]
        gas.pump_1.stop_pumping_103; --eventb[{cust_103_stop_pump_1},{cust_103_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_103_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_103_start_pump_2},{cust_103_start_pump}]
        gas.pump_2.stop_pumping_103; --eventb[{cust_103_stop_pump_2},{cust_103_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_103;


task body customer_104 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_104_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_104_start_pump_1},{cust_104_start_pump}]
        gas.pump_1.stop_pumping_104; --eventb[{cust_104_stop_pump_1},{cust_104_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_104_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_104_start_pump_2},{cust_104_start_pump}]
        gas.pump_2.stop_pumping_104; --eventb[{cust_104_stop_pump_2},{cust_104_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_104;


task body customer_105 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_105_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_105_start_pump_1},{cust_105_start_pump}]
        gas.pump_1.stop_pumping_105; --eventb[{cust_105_stop_pump_1},{cust_105_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_105_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_105_start_pump_2},{cust_105_start_pump}]
        gas.pump_2.stop_pumping_105; --eventb[{cust_105_stop_pump_2},{cust_105_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_105;


task body customer_106 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_106_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_106_start_pump_1},{cust_106_start_pump}]
        gas.pump_1.stop_pumping_106; --eventb[{cust_106_stop_pump_1},{cust_106_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_106_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_106_start_pump_2},{cust_106_start_pump}]
        gas.pump_2.stop_pumping_106; --eventb[{cust_106_stop_pump_2},{cust_106_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_106;


task body customer_107 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_107_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_107_start_pump_1},{cust_107_start_pump}]
        gas.pump_1.stop_pumping_107; --eventb[{cust_107_stop_pump_1},{cust_107_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_107_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_107_start_pump_2},{cust_107_start_pump}]
        gas.pump_2.stop_pumping_107; --eventb[{cust_107_stop_pump_2},{cust_107_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_107;


task body customer_108 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_108_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_108_start_pump_1},{cust_108_start_pump}]
        gas.pump_1.stop_pumping_108; --eventb[{cust_108_stop_pump_1},{cust_108_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_108_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_108_start_pump_2},{cust_108_start_pump}]
        gas.pump_2.stop_pumping_108; --eventb[{cust_108_stop_pump_2},{cust_108_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_108;


task body customer_109 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_109_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_109_start_pump_1},{cust_109_start_pump}]
        gas.pump_1.stop_pumping_109; --eventb[{cust_109_stop_pump_1},{cust_109_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_109_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_109_start_pump_2},{cust_109_start_pump}]
        gas.pump_2.stop_pumping_109; --eventb[{cust_109_stop_pump_2},{cust_109_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_109;


task body customer_110 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_110_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_110_start_pump_1},{cust_110_start_pump}]
        gas.pump_1.stop_pumping_110; --eventb[{cust_110_stop_pump_1},{cust_110_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_110_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_110_start_pump_2},{cust_110_start_pump}]
        gas.pump_2.stop_pumping_110; --eventb[{cust_110_stop_pump_2},{cust_110_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_110;


begin
  null;
end gas;

-- Generated on Sun Jul 30 13:28:24 2006
-- Pumps:     2
-- Customers: 7

procedure gas;


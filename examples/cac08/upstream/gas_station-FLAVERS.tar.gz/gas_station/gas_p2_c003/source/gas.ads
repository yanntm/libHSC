-- Generated on Tue Oct 12 13:59:09 2004
-- Pumps:     2
-- Customers: 3

procedure gas;


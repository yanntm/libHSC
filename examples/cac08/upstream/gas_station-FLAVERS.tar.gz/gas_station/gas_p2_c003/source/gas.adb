-- Generated on Tue Oct 12 13:59:09 2004
-- Pumps:     2
-- Customers: 3

procedure gas is

N : constant natural := 3;  -- number of customers
type cust_range is range 0 .. N;
type pump_range is range 1 .. 2;

task operator is
  entry prepay_1_pump_1;
  entry charge_1_pump_1;
  entry prepay_2_pump_1;
  entry charge_2_pump_1;
  entry prepay_3_pump_1;
  entry charge_3_pump_1;
  entry prepay_1_pump_2;
  entry charge_1_pump_2;
  entry prepay_2_pump_2;
  entry charge_2_pump_2;
  entry prepay_3_pump_2;
  entry charge_3_pump_2;
end operator;


task pump_1 is
  entry activate;
  entry start_pumping;
  entry stop_pumping_1;
  entry stop_pumping_2;
  entry stop_pumping_3;
end pump_1;


task pump_2 is
  entry activate;
  entry start_pumping;
  entry stop_pumping_1;
  entry stop_pumping_2;
  entry stop_pumping_3;
end pump_2;


task customer_1 is
  entry change;
end customer_1;


task customer_2 is
  entry change;
end customer_2;


task customer_3 is
  entry change;
end customer_3;


task body operator is
  Pump_1_ActiveCustomers : cust_range;
  Pump_2_ActiveCustomers : cust_range;
  done : boolean;
begin
  Pump_1_ActiveCustomers := 0; --event[{p1ac=0}]
  Pump_2_ActiveCustomers := 0; --event[{p2ac=0}]
  null;
  loop
  -- if there are no active customers, we can exit
    if ((Pump_1_ActiveCustomers = 0) and
        (Pump_2_ActiveCustomers = 0)) then
      null; --eventb[{p1acis=0}]
      null; --eventb[{p2acis=0}]
      null;
      exit when done;
    end if;

    select
      accept prepay_1_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_1_pump_1;

    or

      accept charge_1_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_1.change; --eventb[{cust_1_pump_1_change}]
      null;

    or

      accept prepay_2_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_2_pump_1;

    or

      accept charge_2_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_2.change; --eventb[{cust_2_pump_1_change}]
      null;

    or

      accept prepay_3_pump_1 do
        -- check for this as the first customers
        if Pump_1_ActiveCustomers = 0 then
          gas.pump_1.activate;  --eventb[{p1acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 1
        Pump_1_ActiveCustomers :=
           Pump_1_ActiveCustomers + 1; --event[{p1acinc}]
        null;
      end prepay_3_pump_1;

    or

      accept charge_3_pump_1;
      -- decrement number of active customers
      Pump_1_ActiveCustomers :=
         Pump_1_ActiveCustomers - 1; --event[{p1acdec}]
      null;

      -- check for more customers
      if Pump_1_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_1.activate; --eventb[{p1acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_3.change; --eventb[{cust_3_pump_1_change}]
      null;

    or

      accept prepay_1_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_1_pump_2;

    or

      accept charge_1_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_1.change; --eventb[{cust_1_pump_2_change}]
      null;

    or

      accept prepay_2_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_2_pump_2;

    or

      accept charge_2_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_2.change; --eventb[{cust_2_pump_2_change}]
      null;

    or

      accept prepay_3_pump_2 do
        -- check for this as the first customers
        if Pump_2_ActiveCustomers = 0 then
          gas.pump_2.activate;  --eventb[{p2acis=0}]
          null;
        end if;
        -- increment the number of active customers on pump 2
        Pump_2_ActiveCustomers :=
           Pump_2_ActiveCustomers + 1; --event[{p2acinc}]
        null;
      end prepay_3_pump_2;

    or

      accept charge_3_pump_2;
      -- decrement number of active customers
      Pump_2_ActiveCustomers :=
         Pump_2_ActiveCustomers - 1; --event[{p2acdec}]
      null;

      -- check for more customers
      if Pump_2_ActiveCustomers > 0 then
        -- more customers, so activate pump again
        gas.pump_2.activate; --eventb[{p2acis>0}]
        null;
      end if;

      -- give change to customer
      gas.customer_3.change; --eventb[{cust_3_pump_2_change}]
      null;
    end select;
  end loop;
end operator;


task body pump_1 is
  done : boolean;
begin
  loop
    exit when done;
    accept activate;
    accept start_pumping; --event[{pump_1_start}]
    null;

    select
      accept stop_pumping_1 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_1_pump_1;
      end stop_pumping_1;
    or
      accept stop_pumping_2 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_2_pump_1;
      end stop_pumping_2;
    or
      accept stop_pumping_3 do
        null; --eventb[{pump_1_stop}]
        null;
        gas.operator.charge_3_pump_1;
      end stop_pumping_3;
    end select;
  end loop;
end pump_1;


task body pump_2 is
  done : boolean;
begin
  loop
    exit when done;
    accept activate;
    accept start_pumping; --event[{pump_2_start}]
    null;

    select
      accept stop_pumping_1 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_1_pump_2;
      end stop_pumping_1;
    or
      accept stop_pumping_2 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_2_pump_2;
      end stop_pumping_2;
    or
      accept stop_pumping_3 do
        null; --eventb[{pump_2_stop}]
        null;
        gas.operator.charge_3_pump_2;
      end stop_pumping_3;
    end select;
  end loop;
end pump_2;


task body customer_1 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_1_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_1_start_pump_1},{cust_1_start_pump}]
        gas.pump_1.stop_pumping_1; --eventb[{cust_1_stop_pump_1},{cust_1_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_1_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_1_start_pump_2},{cust_1_start_pump}]
        gas.pump_2.stop_pumping_1; --eventb[{cust_1_stop_pump_2},{cust_1_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_1;


task body customer_2 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_2_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_2_start_pump_1},{cust_2_start_pump}]
        gas.pump_1.stop_pumping_2; --eventb[{cust_2_stop_pump_1},{cust_2_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_2_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_2_start_pump_2},{cust_2_start_pump}]
        gas.pump_2.stop_pumping_2; --eventb[{cust_2_stop_pump_2},{cust_2_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_2;


task body customer_3 is
  done : boolean;
  random : integer;
begin
  loop
    exit when done;
    case random is
      when 1 =>
        gas.operator.prepay_3_pump_1;
        gas.pump_1.start_pumping;   --event[{cust_3_start_pump_1},{cust_3_start_pump}]
        gas.pump_1.stop_pumping_3; --eventb[{cust_3_stop_pump_1},{cust_3_stop_pump}]
        null;

      when 2 =>
        gas.operator.prepay_3_pump_2;
        gas.pump_2.start_pumping;   --event[{cust_3_start_pump_2},{cust_3_start_pump}]
        gas.pump_2.stop_pumping_3; --eventb[{cust_3_stop_pump_2},{cust_3_stop_pump}]
        null;

    end case;
    accept change;
  end loop;
end customer_3;


begin
  null;
end gas;

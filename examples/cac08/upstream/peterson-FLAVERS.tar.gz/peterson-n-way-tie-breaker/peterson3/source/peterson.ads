-- Generated on Tue Jan 11 16:21:18 2005
-- Processes:  3

package peterson is

  N : constant integer := 3;

  subtype process_ids is natural range 1..N;

  subtype levels is natural range 1..(N-1);

  subtype in_values is natural range 0..N;

  subtype last_values is natural range 0..N;

  task process_1 is
    entry start;
  end process_1;

  task process_2 is
    entry start;
  end process_2;

  task process_3 is
    entry start;
  end process_3;

end peterson;

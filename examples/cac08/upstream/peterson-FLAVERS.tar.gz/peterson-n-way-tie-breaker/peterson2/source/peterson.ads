-- Generated on Tue Jan 11 16:21:15 2005
-- Processes:  2

package peterson is

  N : constant integer := 2;

  subtype process_ids is natural range 1..N;

  subtype levels is natural range 1..(N-1);

  subtype in_values is natural range 0..N;

  subtype last_values is natural range 0..N;

  task process_1 is
    entry start;
  end process_1;

  task process_2 is
    entry start;
  end process_2;

end peterson;

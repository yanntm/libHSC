-- Generated on Tue Jan 11 16:21:15 2005
-- Processes:  2

-- Implementation of Peterson's n-way tie breaking algorithm
-- for mutual exclusion.  For process i, the psuedo code is:
--   *** entry protocol 
--   for [ j=1 to n-1 ] {
--     /* process i is in stage j and is the last process */ 
--     in_stage [i] = j; 
--     last_process [j] = i;
--
--     /* for each process k other than i */
--     for [ k=1 to n except k==i ] { 
--       /* wait while process k is in a higher-numbered stage
--          than process i and process i was the last to enter
--          stage j */
--       while ( in_stage [k] >= j and
--               last_process [j] == i ) { ** };
--     }
--   }
--
--   critical section
--
--   /* exit protocol */
--   in_stage [i] = 0;
--
--   noncritical section
--
-- ** We can put an exit when done in the ada translation here
--    because every task will eventually and continually reach
--    this point.

package body peterson is
  in_stage : array(process_ids) of in_values;
  last_process : array(process_ids) of last_values;



  task body process_1 is
    done : boolean;
    choose : boolean;
  begin
    accept start;

    MAIN_LOOP:  loop
      -- for j loop:  j = 1
      in_stage(1) := 1;  --event[{in_stage_1=1}]
      last_process(1) := 1;  --event[{last_process_1=1}]
        -- for k loop: k = 1
        -- k = i, do nothing

        -- for k loop: k = 2
        while((in_stage(2) >= 1) and
              (last_process(1) = 1)) loop
          exit MAIN_LOOP when done;

          null; --event[{in_stage_2is>=1}]
          null; --event[{last_process_1is=1}]
          null;
        end loop;
        if choose then
          null; --event[{in_stage_2is<1}]
          null;
        else
          null; --event[{last_process_1is/=1}]
          null;
        end if;


      null; --event[{enter_critical}]
      null; --event[{exit_critical}]

      -- exit protocol
      in_stage(1) := 0; --event[{in_stage_1=0}]

      null;
    end loop;
  end process_1;



  task body process_2 is
    done : boolean;
    choose : boolean;
  begin
    accept start;

    MAIN_LOOP:  loop
      -- for j loop:  j = 1
      in_stage(2) := 1;  --event[{in_stage_2=1}]
      last_process(1) := 2;  --event[{last_process_1=2}]
        -- for k loop: k = 1
        while((in_stage(1) >= 1) and
              (last_process(1) = 2)) loop
          exit MAIN_LOOP when done;

          null; --event[{in_stage_1is>=1}]
          null; --event[{last_process_1is=2}]
          null;
        end loop;
        if choose then
          null; --event[{in_stage_1is<1}]
          null;
        else
          null; --event[{last_process_1is/=2}]
          null;
        end if;

        -- for k loop: k = 2
        -- k = i, do nothing


      null; --event[{enter_critical}]
      null; --event[{exit_critical}]

      -- exit protocol
      in_stage(2) := 0; --event[{in_stage_2=0}]

      null;
    end loop;
  end process_2;




begin
  -- First initialize in_stage and last_process
  in_stage(1) := 0; --event[{in_stage_1=0}]
  in_stage(2) := 0; --event[{in_stage_2=0}]

  last_process(1) := 0; --event[{last_process_1=0}]
  last_process(2) := 0; --event[{last_process_2=0}]
  null;

  -- Now start the processes
  process_1.start;
  process_2.start;
end peterson;
